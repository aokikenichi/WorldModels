# 第5章 実装前の原稿照合

2026-09-08。参照した唯一の本文基準は `source_docs/世界モデル入門_v0.2-edit1_SOL-master.docx`。読み取りだけを行い、原稿ファイルは変更していない。以下の `SOL_Pxxxx` / `SOL_Txxx` は `word/document.xml` の実在する `w:bookmarkStart/@w:name` を取得して確認した識別子で、ページ番号ではない。別紙自体にはブックマークがないため、別紙のQ/E見出しと本文への参照を使う。

## 参照資料と読み取り時のSHA-256

ファイル名は読みやすくUnicode NFCで表記している。macOS上の実ファイル名では濁点が分解表現になっているものがある。

| ファイル | SHA-256 |
|---|---|
| 世界モデル入門_v0.2-edit1_SOL-master.docx | `4c27a5571efa4286f010e79e89cb97a389d090db6704bacbad97f31e5c463237` |
| 世界モデル入門_v0.2-edit1_SOL-master_別紙_編集確認事項.docx | `ec1cb0fdc010ccca0d566c6d5a9cc31a56b6639ec8e1ae8a42e4ee111a0f4e4b` |
| 世界モデル入門_v0.2-edit1_変更記録.md | `5a2539de6065e0dbbd12e46578156f14ef4a14a6b32d0cd2500a01bc5c4ccefd` |
| Astro→SOL-master 移植候補 事実確認レポート.md | `962ab3f96ebeaa824ce317a8ed0e450866b7563b70780e3b35e09fb9f2fa56cb` |

## 章の狙いと採用済み事項

- 5.1見出しは **SOL_P0263**。**SOL_P0265** は、一歩予測を回帰として学び、予測を次入力に使い、複数の行動列を試して一歩だけ現実で実行することを核とする。
- **SOL_P0266** の原文は「Dreamerを再実装するのではありません。表現学習、確率モデル、方策勾配などをいったん外し、『学習済みモデルの中で考えてから動く』という核だけを取り出します。」
- **SOL_T019**（EM-02）には、現状が参考骨格・未実行であり、完全実装、seed固定テスト、学習曲線、図5-3の生成が必要とある。
- **SOL_T031**（EM-03）には「障害物なしのBasic版と障害物ありのChallenge版を分けます。成功結果に合わせて環境を後付けで調整せず、失敗も教材として残します。」とある。
- **SOL_P0337** の「random actionよりmodel planningの目標到達率が高いこと」、**SOL_P0338** の「学習分布外の開始位置で性能低下を観察」は未検証の旧受け入れ目標。今回のユーザー指示は結果誘導を禁じ、仕様どおり再現可能に測定することを合格条件とするため、この2項目は検証する仮説へ修正する対象になる。

## 節と実在アンカーの対応

| 節 | 見出し | 実装・編集に直接関係する箇所 |
|---|---|---|
| 5.1 | SOL_P0263 | P0264〜P0266、T019：目的・実装ステータス |
| 5.2 | SOL_P0268 | P0269〜P0271：環境仕様、P0272〜P0275/T020：API、T021：図5-1 |
| 5.3 | SOL_P0277 | P0278/T022：収集、P0280：被覆と分布、P0281：split比較 |
| 5.4 | SOL_P0282 | P0283/T023：MLP、P0285/T024：delta・MSE、P0287：省略、T025：図5-2 |
| 5.5 | SOL_P0289 | P0290〜P0292：one-step、T026：図5-3 |
| 5.6 | SOL_P0294 | P0295〜P0299/T027：model-only rollout、P0301：真値比較、T028：図5-4 |
| 5.7 | SOL_P0303 | P0304/T029：score、P0306：一手実行、P0307：random shooting・探索規模 |
| 5.8 | SOL_P0308 | P0309：再観測・更新の説明、P0310〜P0317：閉ループ |
| 5.9 | SOL_P0318 | P0319〜P0326：省略事項、P0327/T030/P0329：表5-1 |
| 5.10 | SOL_P0330 | P0331〜P0340：受け入れ条件、T031：Basic/Challengeと失敗保存 |
| 付録F/F.1 | SOL_P0614/SOL_P0615 | P0616：全コード実行、P0617：複数seed、P0618：図5-3/5-4実測版 |
| 付録F.2 | SOL_P0623 | AS15の追記候補参照位置。現行の箇条書きにOracle MPCは存在しない |

`Pxxxx` / `Txxx` の省略記法はこの表内ではそれぞれ `SOL_Pxxxx` / `SOL_Txxx` を指す。後の編集ガイドでは完全名を使う。

## 環境の確定済み部分と未確定部分

**SOL_P0269**：位置 `(x,y)`、空間 `[0,1]^2`、4方向、一行動0.05、境界で止まる。

**SOL_P0270**：goal `(0.9,0.9)`、中央長方形障害物、侵入時は元位置に留まる。原文の報酬は「目標への距離が縮むほど高く、障害物へ衝突すると罰を与える単純なものにします。」であり、厳密式はまだない。

**SOL_P0271**：実際の移動量への小ノイズ、同じ状態と行動でも結果は一致しない。決定論的NNは平均的な次状態を学ぶ説明。

**SOL_P0275**：`0: UP, 1: DOWN, 2: LEFT, 3: RIGHT`。状態2＋行動one-hot4＝入力6、次状態出力2。

原稿から数値が確定しないもの：障害物の4座標、ノイズの分布/scale/順序、reset分布、最大episode長、goal半径、終了条件、reward式、seed/RNGの所有、真値比較時ノイズ。これらは今回SPECで実験前に固定する必要がある。

**SOL_T020 原コード**（改行を保持して抽出）：

```python
class ToyWorld:
    def reset(self, seed=None) -> np.ndarray:
        """初期状態 [x, y] を返す。"""

    def step(self, action: int):
        """next_state, reward, terminated, info を返す。"""

    def transition(self, state, action, noise=True):
        """任意stateに対する真の遷移。データ生成と評価に使う。"""
```

`step` は4要素の独自API。Gymnasiumの5要素に変更しない。時間切れとgoal到達の区別は `info` に保存する実装が本文と両立する。

## Datasetとモデル

**SOL_P0278 / SOL_T022**：random policyで `(state, action, next_state)` を保存し、`terminated` 後にresetする。`rng`、`seed`、`num_steps` は骨格では定義されていない。

**SOL_P0281 原文**：「データはtrain、validation、testへ分けます。隣り合う時系列をランダムに混ぜて分割すると非常に似た点が両方へ入るため、軌跡単位で分ける版も用意します。【v0.2バックログ】v0.2では、ランダム分割と軌跡分割の差を確認します。」

**SOL_T023 原コード**：

```python
class DynamicsModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(6, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, 2),
        )

    def forward(self, state, action_onehot):
        x = torch.cat([state, action_onehot], dim=-1)
        delta = self.net(x)
        return state + delta
```

**SOL_P0285 / SOL_T024** はnext-state MSE：

```python
pred_next = model(state_batch, action_onehot_batch)
loss = F.mse_loss(pred_next, next_state_batch)
```

**SOL_P0287** は位置状態を直接使い画像encoderなしと明示。構造を複雑化する根拠はない。

## One-stepとrollout

**SOL_P0290**：test set、next x/y真値対予測散布図、空間的な誤差の色分け。

**SOL_P0291**：障害物境界で進む/止まるの切り替えをMLPが平均化し、内部へ侵入する予測を出す可能性を説明している。実験結果とはまだ述べていない。

**SOL_P0292**：「毎回0.005ずつ右へずれるモデルは、一歩では正確に見えても20ステップ後には0.1ずれます」は仮想的な一定バイアスの例であり、実測値に流用しない。

**SOL_P0295〜SOL_P0299**：初期状態以外はモデル自身の予測を再帰入力することを明確にしている。

**SOL_T027 原コード**：

```python
def rollout_model(model, start_state, action_sequence):
    imagined = [start_state]
    state = start_state
    for action in action_sequence:
        with torch.no_grad():
            state = model(state, one_hot(action))
        imagined.append(state)
    return torch.stack(imagined)
```

**SOL_P0301**：同じ初期状態・行動列を真の `ToyWorld.transition` に与え、stepと位置誤差を図示。一度の衝突判定の誤りで軌跡全体が分岐しうる。ノイズ設定は未指定。

## ScoreとMPCの不一致

**SOL_P0304 原文**：「現在状態から長さHの行動列を多数サンプリングします。それぞれをモデル内でrolloutし、最終状態の目標距離、途中の障害物接近、移動コストからscoreを計算します。」

**SOL_T029 原コード**：

```python
def score_trajectory(states, goal):
    final_distance = torch.linalg.vector_norm(states[-1] - goal)
    smoothness_cost = torch.linalg.vector_norm(states[1:] - states[:-1], dim=1).sum()
    return -final_distance - 0.01 * smoothness_cost

best_score = -float("inf")
best_actions = None
for actions in candidate_sequences:
    imagined_states = rollout_model(model, current_state, actions)
    score = score_trajectory(imagined_states, goal)
    if score > best_score:
        best_score = score
        best_actions = actions
```

本文の障害物接近項が存在せず、変位ノルム和をsmoothnessと呼んでいる。`path_length_cost` が計算内容に合う。係数0.01は移動コストについて元から記載されているが、追加項の係数や集計法はSPECで新規固定が必要。

**SOL_P0306**：最良列の最初の一手だけを実行し、新観測で再計画するreceding horizon。**SOL_P0307**：uniform random候補、H=10の全行動列は4^10=1,048,576、CEM等は発展版。今回もrandom shootingを主実験にする根拠。

**SOL_P0309** はreplayへの追加と一定間隔の再学習に言及する。主比較を固定学習済みモデルで行う場合、オンライン再学習は今回の実装範囲に含めていないことを編集ガイドに明記し、「一定間隔で再学習すれば」は発展課題として残す。無言で実装済みと扱わない。

**SOL_P0322 / SOL_P0323**：手作りscore、reward modelもpolicy/value学習もない。Oracleに真の障害物幾何を使う場合だけでなくLearned MPCのscoreにも同じ既知幾何を使うため、完全に学習した環境知識による計画ではないという制約を説明できる。

## 図の指定

| 図 | 実在アンカー | 原稿の要求 |
|---|---|---|
| 図5-1 | SOL_T021 | 単位正方形、左下の開始点、右上goal、中央障害物、四方向矢印、実線/破線凡例 |
| 図5-2 | SOL_T025 | state2＋one-hot4→MLP→delta2→state加算→next state |
| 図5-3 | SOL_T026 | next x/y真値対予測散布図、空間error map、障害物境界。平均と局所失敗を分ける |
| 図5-4 | SOL_T028 | 初期状態のみ実環境接続、以降model-onlyで再入力。実測経路重ね描きを生成 |

実測図のタイトル/キャプションにBasic/Challenge、seed、split、サンプル数、ノイズ設定を付けると、その後の本文編集で模式図と混同しない。失敗を強制生成しないという今回の指示を優先する。

## 現行5.10と付録Fの受け入れ条件

| 実在アンカー | 現行条件 | 今回の扱い |
|---|---|---|
| SOL_P0332 | Python 3.11前後、PyTorch、NumPy、Matplotlib | 実際のversion記録とCPU実行 |
| SOL_P0333 | CPUのみ、無料Colabでも数分以内目安 | 実測時間を示す。未実行のColab所要時間を断定しない |
| SOL_P0334 | seed固定、training lossとtest one-step表示 | 複数seed実測・図/CSV |
| SOL_P0335 | horizon 1/5/10/20比較 | model-only比較 |
| SOL_P0336 | 障害物境界失敗例を最低一つ可視化 | 存在する場合に保存。今回指示では無理に作らない |
| SOL_P0337 | Learned planningがrandomより高い到達率 | 結果を要求しない比較仮説へ変更 |
| SOL_P0338 | OOD開始位置で性能低下を観察 | 事前定義OODで差を測る仮説へ変更 |
| SOL_P0339 | notebookと.pyを同じロジックから生成 | 共通moduleをimport |
| SOL_P0340 | 教育用で安全重要用途に使用しない旨 | READMEへ記載 |
| SOL_P0616 | 全コード実行確認 | scripts、tests、notebook実行確認 |
| SOL_P0617 | 複数seedでone/multi-step誤差と到達率 | seed別結果と集約 |
| SOL_P0618 | 図5-3/5-4実測版 | 保存して編集ガイドから対応付け |

付録A（範囲外の本文編集はしない）の補助確認：**SOL_P0536〜SOL_P0541** はPython3.10〜3.12、PyTorch2.x、NumPy、Matplotlib、Jupyter/Colab、GPU非必須、versionをlockする方針。**SOL_T040** がディレクトリ例。付録B **SOL_P0545〜SOL_P0553 / SOL_T041** はGitHub/Colab公開導線と未決定URLを記すが、今回ユーザーは公開作業を要求していないためURLを捏造しない。

## 別紙Q09〜Q12とE02/E06

| 別紙項目 | 別紙記載の本文アンカー | 確認した問題・判断待ち |
|---|---|---|
| Q09 scoreの説明とコード骨格の不一致 | SOL_P0270、SOL_P0304、SOL_T029 | 本文には障害物接近、コードには最終距離と移動量しかない。今回採用式を確定する |
| Q10 smoothness_costの名称と計算 | SOL_T029 | 通常の滑らかさとは異なる変位ノルム和。目的に合う名称へ変更 |
| Q11 Toy Worldの未確定仕様 | SOL_P0270、SOL_P0271、SOL_P0301、SOL_P0306、SOL_T020 | 座標、ノイズ、終了、reward、比較時ノイズ、4要素APIを固定 |
| Q12 コード骨格・受け入れ条件の未検証 | SOL_T027、SOL_P0337、SOL_P0333 | one_hot/rng/candidates/shape未定義、高到達率/数分は目標で実測なし |
| E02 第5章の実装仕様と実測 | SOL_P0262、SOL_P0330、SOL_P0616 | Q09〜Q12と5.10/F.1を検証、成功に合わせた環境変更禁止 |
| E06 既存の加筆案の採否［AS15保留維持］ | SOL_P0304〜SOL_P0307、SOL_P0337、SOL_P0623 | 真モデルMPC baselineの仕様・実装・実測は未決定、本文未反映 |

Q11の別紙原文：「stepの4要素返却は記載された独自APIです。」Q12の別紙原文：「『random actionより高い到達率』『CPUで数分以内』は受け入れ目標で、達成済みの結果ではありません。」

## AS15の前工程状態

変更記録は冒頭で「AS15は保留」「第5章本文・コードは未変更」と明記し、AS15行も「保留・未反映」「なし（本文・表とも未変更）」「第5章への追加を実施せず、Codex実装工程で採否を決める」「比較条件・仕様・実装・実測は未決定」と記す。

背景レポートもAS15を第5章実装工程へ送り、真の環境モデルを使うMPC baselineを実装仕様・評価設計の問題と位置づける。前工程の研究調査で採用されたという説明は誤り。今回のユーザー指示により初めて **採用** が確定する。

今工程での反映案は、同一horizon/候補生成器/候補数/score/receding-horizonのLearnedとOracleを比較し、planningの効果と学習モデルによる差を診断すること。OracleはToy World内の参照baselineであり、有限random shootingと固定scoreに制約されるため、数学的な最適上界とは限らない。真の実世界モデルがAIに利用可能だという主張にも使わない。
