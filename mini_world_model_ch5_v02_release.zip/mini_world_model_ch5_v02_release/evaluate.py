"""Evaluate saved models with one-step tests and recursive rollout probes."""
from experiment import main

if __name__ == "__main__":
    main(stages=("evaluate",))
