# License status

2026-09-11時点で、この配布物自身に適用するlicenseは選択されていません。既存成果物にも`LICENSE`はありませんでした。権利者の明示的な判断なしにMIT、Apache-2.0、GPL等を付与していません。

## 公開前に分けて判断する対象

| 対象 | 現在の状態 | 公開前の判断 |
|---|---|---|
| `*.py`、Notebook、README等の自作コード・文書 | repository license未選択 | 権利者がlicenseとcopyright表記を決定 |
| `figures/`の実測図 | この実装と保存結果から生成。外部画像の転載なし | コードと同じlicenseに含めるか、図版用条件を別に指定 |
| `data/`、`results/`、`checkpoints/` | Toy Worldで自動生成。外部dataset不使用 | 生成データ・model weightsの再利用条件を決定 |
| 書籍本文・canonical・書籍の全23図 | release repositoryには収録しない | 書籍側の権利処理をrepositoryと分離 |
| 引用論文・外部資料 | 本配布物へ本文・図を転載していない | 引用情報と第三者著作物を自作物licenseの対象にしない |
| Python package | 配布物へvendorせず、利用者が`pip`で取得 | 各package固有licenseに従う |

第三者packageのlicenseは`THIRD_PARTY_DEPENDENCIES.md`に整理しています。それらのlicenseを、このrepository自身のlicenseとして扱わないでください。

## 現在の公開判定

コード・生成物の技術的な公開準備は完了していますが、一般公開・再配布条件は未確定です。GitHub repositoryを公開する前に、少なくともrepository licenseの選択と権利者表示を確定してください。
