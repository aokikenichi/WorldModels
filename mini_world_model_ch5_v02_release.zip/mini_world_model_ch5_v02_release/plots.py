"""Figures derived only from saved measurements; no simulation or fitting here."""
from __future__ import annotations

import argparse
import csv
import json
import os
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).parent / ".mplconfig"))
os.environ.setdefault("XDG_CACHE_HOME", str(Path(__file__).parent / ".cache"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle
import numpy as np

from mini_world_model import load_config

COLORS = {"Random": "#778899", "Learned": "#ca6b2b", "Oracle": "#177e89",
          "Basic": "#177e89", "Challenge": "#ca6b2b", "true": "#176d96", "imagined": "#d46529"}


def rows(path):
    with Path(path).open(newline="") as f:
        return list(csv.DictReader(f))


def numeric(row, *names):
    for name in names:
        if name in row:
            if row[name] in ("True", "False"):
                return float(row[name] == "True")
            return float(row[name]) if row[name] not in ("", "None", "null") else np.nan
    raise KeyError(names)


def world_axes(ax, variant, cfg, show_regions=False):
    w = cfg["world"]
    ax.add_patch(Rectangle((0, 0), 1, 1, facecolor="#f6f8fa", edgecolor="#667788", zorder=0))
    if variant == "Challenge":
        xmin, xmax, ymin, ymax = w["obstacle"]
        ax.add_patch(Rectangle((xmin, ymin), xmax-xmin, ymax-ymin,
                               facecolor="#bec4cb", edgecolor="#59646f", hatch="///", zorder=1))
    if show_regions:
        for low, high, color, label in [(w["reset_low"], w["reset_high"], "#358a75", "IID starts"),
                (cfg["evaluation"]["ood_low"], cfg["evaluation"]["ood_high"], "#9164b3", "OOD starts")]:
            ax.add_patch(Rectangle(low, high[0]-low[0], high[1]-low[1],
                                   facecolor=color, edgecolor=color, alpha=.23, label=label))
    ax.add_patch(Circle(w["goal"], w["goal_radius"], facecolor="#ead46b", edgecolor="#b99b32", alpha=.6))
    ax.scatter(*w["goal"], marker="*", s=95, c="#92720b", zorder=6, label="Goal")
    ax.set(xlim=(-.025, 1.025), ylim=(-.025, 1.025), xlabel="x", ylabel="y", aspect="equal")
    ax.set_xticks(np.linspace(0, 1, 6)); ax.set_yticks(np.linspace(0, 1, 6))


def save(fig, output, name):
    fig.savefig(output / name, dpi=180, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def inside(states, cfg):
    xmin, xmax, ymin, ymax = cfg["world"]["obstacle"]
    return ((states[..., 0] >= np.float32(xmin)) & (states[..., 0] <= np.float32(xmax)) &
            (states[..., 1] >= np.float32(ymin)) & (states[..., 1] <= np.float32(ymax)))


def create_figures(root="."):
    root = Path(root).resolve()
    cfg_path = root / "config.json"
    cfg = load_config(cfg_path if cfg_path.exists() else None)
    output = root / "figures"
    output.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "axes.titlesize": 12, "figure.constrained_layout.use": True})
    variants = ["Basic", "Challenge"]
    # Fixed specification figure. This panel is a diagram, not measured data.
    fig, axs = plt.subplots(1, 2, figsize=(10.4, 4.7))
    for ax, v in zip(axs, variants):
        world_axes(ax, v, cfg, True)
        ax.set_title(v + (": deterministic" if v == "Basic" else ": Gaussian noise, SD = 0.003"))
        for label, offset in [("UP", (0, .09)), ("DOWN", (0, -.09)), ("LEFT", (-.09, 0)), ("RIGHT", (.09, 0))]:
            ax.annotate("", xy=(.79+offset[0], .25+offset[1]), xytext=(.79, .25),
                        arrowprops={"arrowstyle": "->", "color": "#536475"})
        ax.text(.79, .11, "Action step = 0.05", ha="center", fontsize=9)
        ax.legend(loc="upper center", bbox_to_anchor=(.5, -.16), ncol=3, fontsize=8)
    fig.suptitle("Toy World specification | start regions fixed before experiments")
    save(fig, output, "toy_world.png")

    fig, ax = plt.subplots(figsize=(12, 2.9))
    ax.axis("off")
    boxes = [(0.02, "state (x, y)\n+ one-hot action\n6 inputs"),
             (.275, "Linear 6 → 64\nReLU\nLinear 64 → 64, ReLU"),
             (.54, "Linear 64 → 2\nPredicted delta\nΔx, Δy"),
             (.795, "state + delta\nPredicted next state\n2 outputs")]
    for x, label in boxes:
        ax.text(x+.09, .55, label, ha="center", va="center", transform=ax.transAxes,
                bbox={"boxstyle": "round,pad=.65", "facecolor": "#eef4f7", "edgecolor": "#9cb5c3"})
    for x in [.205, .468, .723]:
        ax.annotate("", xy=(x+.055, .55), xytext=(x, .55), xycoords="axes fraction",
                    arrowprops={"arrowstyle": "->", "lw": 1.6})
    ax.text(.5, .09, "Training: next-state MSE  |  Rollout: feed the predicted state back into the same model",
            transform=ax.transAxes, ha="center")
    ax.set_title("The same residual MLP in Basic and Challenge (architecture diagram)")
    save(fig, output, "dynamics_architecture.png")

    # Histories: every main seed, no test-based model selection.
    fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.1))
    for ax, v in zip(axs, variants):
        histories = sorted((root / "checkpoints" / v).glob("seed_*/history_trajectory.csv"))
        for i, f in enumerate(histories):
            rr = rows(f)
            epoch = [numeric(r, "epoch") for r in rr]
            ax.plot(epoch, [numeric(r, "train_mse") for r in rr], color=COLORS["true"], alpha=.45,
                    label="Train (each seed)" if i == 0 else None)
            ax.plot(epoch, [numeric(r, "val_mse") for r in rr], color=COLORS["imagined"], alpha=.5,
                    label="Validation (each seed)" if i == 0 else None)
        ax.set(title=f"{v} | {len(histories)} seeds", xlabel="Epoch", ylabel="Next-state MSE", yscale="log")
        ax.grid(alpha=.16); ax.legend()
    fig.suptitle("Training loss | trajectory split | validation selects the checkpoint")
    save(fig, output, "training_loss.png")

    tests = {}
    for v in variants:
        ff = sorted((root / "results/test_predictions").glob(f"{v}_seed*_trajectory.npz"))
        loaded = [dict(np.load(f, allow_pickle=False)) for f in ff]
        tests[v] = {key: np.concatenate([a[key] for a in loaded]) for key in loaded[0]}
    fig, axs = plt.subplots(2, 2, figsize=(8.8, 8))
    for j, v in enumerate(variants):
        d = tests[v]
        for k in (0, 1):
            ax = axs[j, k]
            ax.scatter(d["true"][:, k], d["predicted"][:, k], s=2, alpha=.13, color=COLORS[v], rasterized=True)
            ax.plot([0, 1], [0, 1], "--", color="#647180", lw=1)
            ax.set(xlabel=f"True next {'xy'[k]}", ylabel=f"Predicted next {'xy'[k]}",
                   title=f"{v}, n = {len(d['true']):,}", aspect="equal")
    fig.suptitle("One-step prediction | all held-out trajectory transitions")
    save(fig, output, "one_step_prediction.png")

    fig, axs = plt.subplots(1, 2, figsize=(11, 4.8))
    errors = {v: np.linalg.norm(tests[v]["predicted"]-tests[v]["true"], axis=1) for v in variants}
    vmax = max(np.max(e) for e in errors.values())
    for ax, v in zip(axs, variants):
        world_axes(ax, v, cfg)
        s = tests[v]["state"]
        artist = ax.hexbin(s[:, 0], s[:, 1], C=errors[v], reduce_C_function=np.mean,
                          gridsize=25, extent=(0, 1, 0, 1), mincnt=1,
                          cmap="magma", vmin=0, vmax=vmax, zorder=3)
        ax.set_title(f"{v} | mean error = {errors[v].mean():.4f}")
    fig.colorbar(artist, ax=axs, label="Euclidean error (mean within occupied hexagon)", shrink=.85)
    fig.suptitle("One-step error map | held-out states | blank cells have no measurements")
    save(fig, output, "one_step_error_map.png")

    probes = {}
    for v in variants:
        for dist in ["IID", "OOD"]:
            probes[v, dist] = [dict(np.load(f, allow_pickle=False), file=str(f))
                for f in sorted((root / "results/probes").glob(f"{v}_seed*_{dist}.npz"))]
    fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.2))
    for ax, v in zip(axs, variants):
        for dist, color in [("IID", "#177e89"), ("OOD", "#9164b3")]:
            means = np.array([p["error"].mean(axis=0) for p in probes[v, dist]])
            mean = means.mean(axis=0); sd = means.std(axis=0, ddof=1) if len(means)>1 else np.zeros_like(mean)
            ax.plot(range(21), mean, color=color, label=dist)
            ax.fill_between(range(21), np.maximum(0, mean-sd), mean+sd, color=color, alpha=.13)
            h = cfg["evaluation"]["horizons"]
            ax.scatter(h, mean[h], color=color, s=22)
        ax.set(title=v, xlabel="Model-only horizon", ylabel="Mean Euclidean position error", xticks=[0, 1, 5, 10, 20])
        ax.legend(); ax.grid(alpha=.16)
    fig.suptitle("Recursive rollout error | same start and actions | band = seed SD")
    save(fig, output, "rollout_error_by_horizon.png")

    fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.8))
    for ax, v in zip(axs, variants):
        p = probes[v, "IID"][0]
        world_axes(ax, v, cfg)
        for key, label, color, ls in [("true", "True environment", COLORS["true"], "-"),
                                      ("imagined", "Model only", COLORS["imagined"], "--")]:
            xy = p[key][0]
            ax.plot(xy[:, 0], xy[:, 1], ls, color=color, marker=".", markersize=4, label=label, zorder=4)
        ax.scatter(*p["starts"][0], marker="o", facecolors="white", edgecolors="black", s=45, zorder=6, label="Shared start")
        ax.set_title(f"{v} | fixed seed 11, IID probe 0\nH1={p['error'][0,1]:.4f}, H20={p['error'][0,20]:.4f}")
        ax.legend(loc="upper left", fontsize=8)
    fig.suptitle("True vs imagined rollout | illustrative index fixed independently of error")
    save(fig, output, "true_vs_imagined_rollout.png")

    planning = rows(root / "results/planning_episodes.csv")
    policy_values = sorted(set(r["policy"] for r in planning))
    def policy_kind(p):
        p = p.lower()
        return "Random" if "random" in p else "Oracle" if "oracle" in p else "Learned"
    policies = sorted(policy_values, key=lambda p: ["Random", "Learned", "Oracle"].index(policy_kind(p)))
    plot_metrics = [("success", "Goal success rate", (0, 1.12)),
                    ("steps_to_goal", "Steps to goal (success only)", None),
                    ("cumulative_reward", "Cumulative reward", None),
                    ("collision_count", "Blocked actions / episode", None),
                    ("final_distance", "Final distance to goal", None)]
    aliases = {"success": ("success",), "steps_to_goal": ("steps_to_goal", "steps"),
               "cumulative_reward": ("cumulative_reward",), "collision_count": ("collision_count", "collisions", "blocked_count"),
               "final_distance": ("final_distance", "final_distance_to_goal")}
    fig, axs = plt.subplots(2, 5, figsize=(16, 6.5))
    for row_idx, v in enumerate(variants):
        for col, (metric, label, lim) in enumerate(plot_metrics):
            ax = axs[row_idx, col]
            for i, policy in enumerate(policies):
                rr = [r for r in planning if r["variant"]==v and r["distribution"]=="IID" and r["policy"]==policy]
                if metric == "steps_to_goal":
                    rr = [r for r in rr if numeric(r,"success")==1]
                vals = np.array([numeric(r, *aliases[metric]) for r in rr], float)
                val = np.nanmean(vals) if len(vals) else np.nan
                if np.isfinite(val):
                    ax.bar(i, val, color=COLORS[policy_kind(policy)], width=.63)
                    ax.text(i, val, f"{val:.2f}", ha="center", va="bottom", fontsize=9)
                else:
                    ax.text(i, .06, "NA\n0 success", ha="center", va="bottom", fontsize=8,
                            transform=ax.get_xaxis_transform())
            ax.set_xticks(range(3), ["Random", "Learned", "Oracle"], rotation=25, fontsize=8)
            ax.set_xlim(-.5, 2.5)
            ax.set_title(f"{v}\n{label}", fontsize=10)
            if lim: ax.set_ylim(*lim)
            ax.grid(axis="y", alpha=.15)
    fig.suptitle("Planning comparison | IID starts | all episodes, 5 per seed and policy")
    save(fig, output, "planning_comparison.png")

    fig, axs = plt.subplots(2, 3, figsize=(12, 7.5))
    for row_idx, v in enumerate(variants):
        for i, dist in enumerate(["IID", "OOD"]):
            all_e = np.concatenate([p["error"] for p in probes[v, dist]])
            for col, h in [(0, 1), (1, 20)]:
                val = all_e[:, h].mean()
                axs[row_idx, col].bar(i, val, color=["#177e89", "#9164b3"][i], width=.6)
                axs[row_idx, col].text(i, val, f"{val:.4f}", ha="center", va="bottom")
        for col, title in [(0, "One-step probe position error"), (1, "H20 rollout position error")]:
            axs[row_idx, col].set(title=f"{v} | {title}", xticks=[0, 1], xticklabels=["IID", "OOD"], ylabel="Mean Euclidean error")
        ax = axs[row_idx, 2]
        for j, policy in enumerate(policies):
            values = []
            for dist in ["IID", "OOD"]:
                rr = [r for r in planning if r["variant"]==v and r["distribution"]==dist and r["policy"]==policy]
                values.append(np.mean([numeric(r, "success") for r in rr]))
            ax.bar(np.arange(2)+(j-1)*.24, values, width=.22, color=COLORS[policy_kind(policy)], label=policy_kind(policy))
        ax.set(title=f"{v} | Planning goal success", xticks=[0, 1], xticklabels=["IID", "OOD"], ylim=(0, 1.13))
        ax.legend(fontsize=8, loc="upper center", bbox_to_anchor=(.5, -.12), ncol=3)
    fig.suptitle("Predefined start-distribution shift | lower error or higher success is also a valid result")
    save(fig, output, "ood_comparison.png")

    # Failure search is bounded by the frozen probe set, never an environment change.
    cases = []
    all_cases = []
    for dist in ["IID", "OOD"]:
        for p in probes["Challenge", dist]:
            seed = int(Path(p["file"]).stem.split("_seed")[1].split("_")[0])
            # true collision at t, while imagined s_(t+1) is inside the obstacle.
            mistaken = p["collision"].astype(bool) & inside(p["imagined"][:, 1:], cfg)
            qualify = (p["error"][:, 1] <= .015) & (p["error"][:, 20] >= .10) & mistaken.any(axis=1)
            for index in range(len(p["starts"])):
                c = {"seed": seed, "distribution": dist, "index": index,
                     "h1_error": float(p["error"][index, 1]), "h20_error": float(p["error"][index, 20]),
                     "source": str(Path(p["file"]).relative_to(root)), "qualifies": bool(qualify[index])}
                all_cases.append((c, p))
                if qualify[index]: cases.append((c, p))
    candidates = cases or all_cases
    candidates.sort(key=lambda x: (-x[0]["h20_error"], x[0]["seed"], x[0]["distribution"], x[0]["index"]))
    c, p = candidates[0]
    idx = c["index"]
    failure_meta = {"qualifying_count": len(cases), "total_fixed_probes": len(all_cases), "selected": c,
                    "criterion": "h1<=0.015 and h20>=0.10 and true collision with imagined next inside obstacle",
                    "selection": "max h20 then seed/distribution/index", "all_qualifying": [q[0] for q in cases]}
    (root / "results/failure_cases.json").write_text(json.dumps(failure_meta, indent=2)+"\n")
    np.savez_compressed(root / "results/selected_challenge_rollout.npz", starts=p["starts"][idx],
                        actions=p["actions"][idx], true=p["true"][idx], imagined=p["imagined"][idx],
                        error=p["error"][idx], collision=p["collision"][idx])
    fig, axs = plt.subplots(1, 2, figsize=(11, 4.8))
    world_axes(axs[0], "Challenge", cfg)
    for key, label, color, ls in [("true", "True environment", COLORS["true"], "-"),
                                  ("imagined", "Model only", COLORS["imagined"], "--")]:
        xy = p[key][idx]
        axs[0].plot(xy[:, 0], xy[:, 1], ls, marker=".", color=color, label=label, zorder=4)
        axs[0].annotate("H20", xy[-1], color=color, fontsize=9)
    axs[0].scatter(*p["starts"][idx], s=55, facecolor="white", edgecolor="black", zorder=7, label="Start")
    axs[0].legend(loc="upper left", fontsize=8)
    axs[0].set_title(f"seed {c['seed']}, {c['distribution']}, probe {idx}")
    axs[1].plot(np.arange(21), p["error"][idx], marker="o", markersize=3, color=COLORS["imagined"])
    hits = np.flatnonzero(p["collision"][idx])+1
    axs[1].scatter(hits, p["error"][idx, hits], marker="x", s=50, color="black", label="True blocked action")
    axs[1].set(xlabel="Model-only horizon", ylabel="Euclidean position error",
               title=f"H1={c['h1_error']:.4f} → H20={c['h20_error']:.4f}")
    axs[1].legend(); axs[1].grid(alpha=.2)
    title = "Challenge failure meeting the preregistered criterion" if cases else "Challenge maximum-error example | no probe met the failure criterion"
    fig.suptitle(title)
    save(fig, output, "challenge_failure_example.png" if cases else "challenge_max_error_example.png")

    failure_rows = []
    for f in sorted((root / "results/test_predictions").glob("Challenge_seed*_trajectory.npz")):
        d = dict(np.load(f, allow_pickle=False))
        mask = d["collision"].astype(bool) & inside(d["predicted"], cfg)
        for i in np.flatnonzero(mask):
            failure_rows.append({"file": f.name, "test_index": int(i), "x": float(d["state"][i, 0]),
                "y": float(d["state"][i, 1]), "action": int(d["action"][i]),
                "true_x": float(d["true"][i, 0]), "true_y": float(d["true"][i, 1]),
                "predicted_x": float(d["predicted"][i, 0]), "predicted_y": float(d["predicted"][i, 1]),
                "euclidean_error": float(np.linalg.norm(d["predicted"][i]-d["true"][i]))})
    with (root / "results/challenge_one_step_failures.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["file", "test_index", "x", "y", "action", "true_x", "true_y", "predicted_x", "predicted_y", "euclidean_error"])
        writer.writeheader(); writer.writerows(failure_rows)
    failure_meta["one_step_collision_intrusion_count"] = len(failure_rows)
    (root / "results/failure_cases.json").write_text(json.dumps(failure_meta, indent=2)+"\n")
    if failure_rows:
        example = max(failure_rows, key=lambda r: r["euclidean_error"])
        fig, ax = plt.subplots(figsize=(6, 5.3))
        world_axes(ax, "Challenge", cfg)
        ax.scatter(example["x"], example["y"], s=95, marker="o", facecolors="white", edgecolors=COLORS["true"], linewidths=2, label="State = true blocked next", zorder=5)
        ax.scatter(example["predicted_x"], example["predicted_y"], s=75, marker="x", color=COLORS["imagined"], label="Predicted next inside obstacle", zorder=6)
        ax.annotate("", xy=(example["predicted_x"], example["predicted_y"]), xytext=(example["x"], example["y"]),
                    arrowprops={"arrowstyle": "->", "color": COLORS["imagined"]})
        ax.set_xlim(.30, .70); ax.set_ylim(.25, .75)
        handles, labels = ax.get_legend_handles_labels()
        ax.legend(handles[1:], labels[1:], loc="lower left", fontsize=8)
        ax.set_title(f"One-step collision failure | error = {example['euclidean_error']:.4f}\n{example['file']}, test index {example['test_index']}", fontsize=10)
        save(fig, output, "challenge_one_step_failure.png")
    return failure_meta


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    print(json.dumps(create_figures(args.root), indent=2))
