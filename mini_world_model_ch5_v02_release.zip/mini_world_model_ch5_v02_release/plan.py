"""Run paired Random, Learned MPC and Oracle MPC from saved models."""
from experiment import main

if __name__ == "__main__":
    main(stages=("plan",))
