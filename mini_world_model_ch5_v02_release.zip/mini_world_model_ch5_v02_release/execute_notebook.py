"""Execute every notebook cell in a fresh kernel using this Python executable."""
import argparse
import json
from pathlib import Path
import shutil
import sys
import tempfile
import time

import nbformat
from nbclient import NotebookClient
from jupyter_client import KernelManager
from jupyter_client.kernelspec import KernelSpecManager


def execute(*, clean_output=False, executed_notebook=None):
    root = Path(__file__).resolve().parent
    path = root / "mini_world_model.ipynb"
    run_dir = root / "notebook_run"
    if clean_output and run_dir.exists():
        shutil.rmtree(run_dir)
    nb = nbformat.read(path, as_version=4)
    start = time.perf_counter()
    with tempfile.TemporaryDirectory(prefix="mini-world-kernel-") as temporary:
        spec_dir = Path(temporary) / "mini-world"
        spec_dir.mkdir()
        (spec_dir / "kernel.json").write_text(json.dumps({
            "argv": [sys.executable, "-m", "ipykernel_launcher", "-f", "{connection_file}"],
            "display_name": "Mini World CPU", "language": "python"}))
        manager = KernelManager(kernel_name="mini-world", kernel_spec_manager=KernelSpecManager(kernel_dirs=[temporary]))
        client = NotebookClient(nb, km=manager, timeout=900, resources={"metadata": {"path": str(root)}},
                                allow_errors=False, record_timing=True)
        client.execute()
    destination = Path(executed_notebook) if executed_notebook else path
    if not destination.is_absolute():
        destination = root / destination
    nbformat.write(nb, destination)
    timing = {"wall_seconds": time.perf_counter()-start, "python": sys.version,
              "executed_code_cells": sum(c.cell_type == "code" for c in nb.cells),
              "error_outputs": sum(o.output_type == "error" for c in nb.cells if c.cell_type == "code" for o in c.outputs),
              "seeds": [11], "fresh_kernel": True, "clean_output_directory": bool(clean_output),
              "output_directory": "notebook_run", "executed_notebook": destination.name}
    (root / "results/notebook_execution.json").write_text(json.dumps(timing, indent=2)+"\n")
    print(json.dumps(timing, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--clean-output", action="store_true",
                        help="remove only the generated notebook_run directory before execution")
    parser.add_argument("--executed-notebook", default=None,
                        help="optional output notebook name; default overwrites mini_world_model.ipynb")
    execute(**vars(parser.parse_args()))
