# Basic Oracle MPC 独立監査

結果を受けた診断であり、環境・seed・候補・score・終了判定は変更していない。新たなpolicy試行は行わず、保存済み候補と状態の再計算を行った。

保存済み50 episodesの全2894 step、370432 candidate trajectoriesを確認した。

- NumPyによる直接の加算・clipとscore式で、保存済みargmax・先頭action・score各項・選択trajectoryを再計算した。
- 真環境のstate・reward・doneを同じstart/action列で照合した。
- ToyWorldを参照しないexact Basic torch forwardをlearned側の同じrollout/selection経路へ渡し、各保存state/candidateで照合した。

上記の不一致はすべて0。保存score最大絶対差=0、exact torch全候補score最大絶対差=0、保存Oracle予測nextと実状態の最大位置誤差=0。

## 観測できた挙動

境界clipは534 step、完全な無移動は480 step。無移動を選びながら、選択した想像軌跡では後の時点にgoalへ入るstepが461件あった。

候補の先頭actionで即時成功できるstepは106件。そのうちscore argmaxが即時成功actionを選ばなかったstepは76件。SPECのscoreは最終距離と経路長を評価し、途中のgoal到達・成功bonus・待機時間を直接評価しない。この仕様に沿う選択が実データで確認された。

| 開始分布 | 成功/25 | 失敗 | 失敗中の境界clipあり | 失敗中の最小距離が(.05,.050001] |
|---|---:|---:|---:|---:|
| IID | 13 | 12 | 12 | 6 |
| OOD | 17 | 8 | 8 | 5 |

float32のgoal・state・0.05刻みでは距離が0.050000011920928955になる例があり、事前固定した`distance <= .05`では未達となる。丸め許容差は導入していない。これは境界付近の数値感度であり、閾値変更の効果を測定した主張ではない。

## 結論と限界

保存されたBasic Oracleの劣位について、候補共有、argmax、action取り違え、真遷移、score計算の実装bugは本監査では見つからなかった。有限候補・有限horizonと現在のscoreでは、真の遷移を使うことだけで高いタスク成功率は保証されない。

境界での無移動・即時成功の見送り・数値閾値感度は保存データの観測事実。ただしLearnedがOracleを上回った差の全量を各要因へ因果分解してはいない。Learnedの誤差が有利に働いたという説明を確定事実として扱わない。主結果を変更せず、今後scoreや許容差を変更する場合は別の事前仕様を固定した追加実験とする。

詳細なepisode別数値、具体例、入力hashは`results/basic_oracle_independent_audit.json`。再監査は`python diagnostics/audit_basic_oracle.py`。
