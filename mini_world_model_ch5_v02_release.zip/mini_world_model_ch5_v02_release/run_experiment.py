"""Run the complete frozen experiment from a clean output directory."""
from experiment import main

if __name__ == "__main__":
    main()
