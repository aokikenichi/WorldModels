"""Collect the frozen datasets and train all prespecified models."""
from experiment import main

if __name__ == "__main__":
    main(stages=("train",))
