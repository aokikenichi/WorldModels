"""Reproducible experiment orchestration shared by every CLI and notebook.

The frozen experiment settings live in SPEC.md/config.json. This module records
all observations, including failed episodes; it never retunes the specification.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import json
import math
import os
import platform
import subprocess
import sys
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch

from mini_world_model import (
    DynamicsModel, ToyWorld, choose_action, learned_rollout, load_config,
    position_metrics, region_labels, in_obstacle, generate_candidates,
)

SOURCE_ROOT = Path(__file__).resolve().parent
METRIC_FIELDS = ["stage", "variant", "seed", "split", "distribution", "policy",
                 "horizon", "region", "metric", "value", "n"]
GROUP_FIELDS = [k for k in METRIC_FIELDS if k not in {"seed", "value", "n"}]


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_spec_lock():
    """Fail before experiment work if either preregistered file changed."""
    for line in (SOURCE_ROOT / "SPEC_LOCK.sha256").read_text().splitlines():
        expected, filename = line.split(maxsplit=1)
        actual = _sha(SOURCE_ROOT / filename.strip())
        if actual != expected:
            raise RuntimeError(f"Frozen specification checksum mismatch: {filename}")


def _json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _csv(path, rows, fields=None):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = list(rows)
    fields = fields or (list(rows[0]) if rows else [])
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _npz(path, **arrays):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(path, **arrays)


def _record(rows, *, stage, variant, seed, metric, value, n=1,
            split="trajectory", distribution="", policy="", horizon="", region="all"):
    if isinstance(value, np.generic):
        value = value.item()
    rows.append(dict(stage=stage, variant=variant, seed=int(seed), split=split,
                     distribution=distribution, policy=policy, horizon=horizon,
                     region=region, metric=metric, value=value, n=int(n)))


def _metrics(rows, metrics, **keys):
    count = int(metrics.get("count", keys.pop("n", 1)))
    for name, value in metrics.items():
        if name != "count":
            _record(rows, metric=name, value=float(value) if count else None, n=count, **keys)


def _save_part(root, stage, variant, seed, rows):
    _json(root / "results" / "metric_parts" / f"{stage}_{variant}_seed{seed}.json", rows)


def configure_runtime(config):
    torch.set_num_threads(config["training"]["threads"])
    torch.use_deterministic_algorithms(True)


def runtime_manifest(root, config, seeds, variants):
    packages = {}
    for package in ["torch", "numpy", "matplotlib", "pytest", "nbformat", "nbclient"]:
        try:
            packages[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            packages[package] = None
    sources = sorted(SOURCE_ROOT.glob("*.py")) + [SOURCE_ROOT / "SPEC.md", SOURCE_ROOT / "config.json"]
    cpu_description = platform.processor()
    if sys.platform == "darwin":
        try:
            cpu_description = subprocess.check_output(["sysctl", "-n", "machdep.cpu.brand_string"], text=True).strip()
        except (OSError, subprocess.CalledProcessError):
            pass
    # Keep the interpreter identity useful for reproducibility without publishing
    # a contributor's home directory or virtual-environment path.
    manifest = dict(python=sys.version, executable=Path(sys.executable).name, packages=packages,
                    platform=platform.platform(), machine=platform.machine(),
                    processor=cpu_description, logical_cpu_count=os.cpu_count(),
                    torch_num_threads=torch.get_num_threads(),
                    deterministic_algorithms=torch.are_deterministic_algorithms_enabled(),
                    device="cpu", seeds=list(seeds), variants=list(variants), config=config,
                    source_sha256={p.name: _sha(p) for p in sources},
                    timestamp_local=time.strftime("%Y-%m-%dT%H:%M:%S%z"))
    _json(root / "results" / "runtime_manifest.json", manifest)
    return manifest


def collect_dataset(config, variant, seed, root):
    """A trajectory is split as a unit; the 60-step collector cutoff is explicit."""
    env = ToyWorld(variant=variant, config=config)
    action_rng = np.random.default_rng(seed + 1000)
    keys = ["state", "action", "next_state", "reward", "terminated", "collision",
            "boundary_clipped", "trajectory_id", "time", "collector_cutoff"]
    data = {key: [] for key in keys}
    for trajectory in range(config["dataset"]["trajectories"]):
        state = env.reset(seed=seed * 100000 + trajectory)
        for t in range(config["dataset"]["trajectory_steps"]):
            action = int(action_rng.integers(4))
            next_state, reward, done, info = env.step(action)
            observation = dict(state=state, action=action, next_state=next_state,
                               reward=reward, terminated=info["terminated"],
                               collision=info["collision"], boundary_clipped=info["boundary_clipped"],
                               trajectory_id=trajectory, time=t,
                               collector_cutoff=(t + 1 == config["dataset"]["trajectory_steps"] and not done))
            for key in keys:
                data[key].append(observation[key])
            state = next_state
            if done:
                break
    float_fields = {"state", "next_state", "reward"}
    bool_fields = {"terminated", "collision", "boundary_clipped", "collector_cutoff"}
    data = {k: np.asarray(v, dtype=np.float32 if k in float_fields else bool if k in bool_fields else np.int64)
            for k, v in data.items()}
    directory = root / "data" / variant / f"seed_{seed}"
    _npz(directory / "transitions.npz", **data)
    split_rng = np.random.default_rng(seed + 2000)
    order = split_rng.permutation(config["dataset"]["trajectories"])
    n_train = config["dataset"]["train_trajectories"]
    n_val = config["dataset"]["val_trajectories"]
    trajectory_groups = dict(train=order[:n_train], val=order[n_train:n_train+n_val], test=order[n_train+n_val:])
    splits = {"trajectory": {k: np.flatnonzero(np.isin(data["trajectory_id"], ids)) for k, ids in trajectory_groups.items()}}
    _npz(directory / "trajectory_groups.npz", **trajectory_groups)
    if seed == config["dataset"]["split_comparison_seed"]:
        order = np.random.default_rng(seed + 2000).permutation(len(data["action"]))
        n_train, n_val = int(len(order) * .70), int(len(order) * .15)
        splits["transition"] = dict(train=order[:n_train], val=order[n_train:n_train+n_val], test=order[n_train+n_val:])
    for kind, indices in splits.items():
        _npz(directory / f"split_{kind}.npz", **indices)
    return data, splits


def _load_data(root, variant, seed):
    directory = root / "data" / variant / f"seed_{seed}"
    with np.load(directory / "transitions.npz") as z:
        data = dict(z)
    splits = {}
    for path in sorted(directory.glob("split_*.npz")):
        with np.load(path) as z:
            splits[path.stem.removeprefix("split_")] = dict(z)
    return data, splits


def train_model(config, variant, seed, root, data, indices, split="trajectory"):
    torch.manual_seed(seed)
    model = DynamicsModel().cpu()
    optimizer = torch.optim.Adam(model.parameters(), lr=config["training"]["learning_rate"], weight_decay=0)
    generator = torch.Generator(device="cpu").manual_seed(seed + 3000)
    state = torch.from_numpy(data["state"])
    action = torch.from_numpy(data["action"])
    target = torch.from_numpy(data["next_state"])
    train_indices = torch.as_tensor(indices["train"], dtype=torch.long)
    val_indices = torch.as_tensor(indices["val"], dtype=torch.long)
    best_val, best_epoch, best_state = math.inf, None, None
    history = []
    for epoch in range(1, config["training"]["epochs"] + 1):
        model.train()
        order = train_indices[torch.randperm(len(train_indices), generator=generator)]
        loss_sum = 0.
        for batch in order.split(config["training"]["batch_size"]):
            optimizer.zero_grad(set_to_none=True)
            prediction = model(state[batch], action[batch])
            loss = torch.mean((prediction - target[batch]) ** 2)
            loss.backward()
            optimizer.step()
            loss_sum += loss.item() * len(batch)
        model.eval()
        with torch.no_grad():
            val_mse = torch.mean((model(state[val_indices], action[val_indices]) - target[val_indices]) ** 2).item()
        improved = val_mse < best_val
        if improved:
            best_val, best_epoch = val_mse, epoch
            best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
        history.append(dict(epoch=epoch, train_mse=loss_sum / len(order), val_mse=val_mse, best=improved))
    model.load_state_dict(best_state)
    model.eval()
    directory = root / "checkpoints" / variant / f"seed_{seed}"
    directory.mkdir(parents=True, exist_ok=True)
    torch.save(dict(state_dict=best_state, best_epoch=best_epoch, best_validation_mse=best_val,
                    seed=seed, variant=variant, split=split, config_sha256=_sha(SOURCE_ROOT / "config.json")),
               directory / f"{split}.pt")
    _csv(directory / f"history_{split}.csv", history)
    return model, best_epoch, best_val


def load_trained_model(root, variant, seed, split="trajectory"):
    model = DynamicsModel().cpu()
    checkpoint = torch.load(Path(root) / "checkpoints" / variant / f"seed_{seed}" / f"{split}.pt",
                            map_location="cpu", weights_only=True)
    model.load_state_dict(checkpoint["state_dict"])
    model.eval()
    return model


def _nearest_same_action(data, train, test):
    """Exact Euclidean nearest neighbor, with bounded temporary arrays."""
    result = np.full(len(test), np.inf, dtype=np.float64)
    for action in range(4):
        train_states = data["state"][train[data["action"][train] == action]].astype(np.float64)
        positions = np.flatnonzero(data["action"][test] == action)
        for chunk in np.array_split(positions, max(1, math.ceil(len(positions) / 128))):
            if len(chunk) and len(train_states):
                delta = data["state"][test[chunk], None].astype(np.float64) - train_states[None]
                result[chunk] = np.sqrt(np.min(np.sum(delta * delta, axis=-1), axis=1))
    return result


def dataset_diagnostics(config, data, indices, variant, seed, split, root):
    rows = []
    for partition in ["train", "val", "test"]:
        _record(rows, stage="dataset", variant=variant, seed=seed, split=split, distribution=partition,
                metric="transitions", value=len(indices[partition]), n=len(indices[partition]))
    test_ids = np.unique(data["trajectory_id"][indices["test"]])
    train_ids = np.unique(data["trajectory_id"][indices["train"]])
    overlap = np.isin(test_ids, train_ids).mean()
    _record(rows, stage="split_audit", variant=variant, seed=seed, split=split,
            metric="test_trajectory_overlap_fraction", value=float(overlap), n=len(test_ids))
    if seed == config["dataset"]["split_comparison_seed"]:
        nn = _nearest_same_action(data, indices["train"], indices["test"])
        _npz(root / "results" / "split_audit" / f"{variant}_seed{seed}_{split}.npz",
             nearest_same_action_distance=nn, test_indices=indices["test"])
        for metric, value in [("nearest_same_action_mean_distance", nn.mean()), ("nearest_same_action_median_distance", np.median(nn))]:
            _record(rows, stage="split_audit", variant=variant, seed=seed, split=split,
                    metric=metric, value=float(value), n=len(nn))
    low, high = np.asarray(config["evaluation"]["ood_low"]), np.asarray(config["evaluation"]["ood_high"])
    train_state = data["state"][indices["train"]]
    visits = np.all((train_state >= low) & (train_state <= high), axis=-1)
    _record(rows, stage="dataset", variant=variant, seed=seed, split=split, distribution="OOD_region",
            metric="training_state_visits", value=int(visits.sum()), n=len(train_state))
    return rows


def train_stage(config, variant, seed, root):
    data, splits = collect_dataset(config, variant, seed, root)
    rows = []
    for split, indices in splits.items():
        _, best_epoch, best_val = train_model(config, variant, seed, root, data, indices, split)
        rows += dataset_diagnostics(config, data, indices, variant, seed, split, root)
        _record(rows, stage="training", variant=variant, seed=seed, split=split,
                metric="best_epoch", value=best_epoch)
        _record(rows, stage="training", variant=variant, seed=seed, split=split,
                metric="best_validation_mse", value=best_val, n=len(indices["val"]))
    _save_part(root, "training", variant, seed, rows)
    return rows


def evaluate_stage(config, variant, seed, root):
    data, splits = _load_data(root, variant, seed)
    rows = []
    for split, indices in splits.items():
        model = load_trained_model(root, variant, seed, split)
        ix = indices["test"]
        state, action, true = data["state"][ix], data["action"][ix], data["next_state"][ix]
        with torch.no_grad():
            predicted = model(torch.from_numpy(state), torch.from_numpy(action)).cpu().numpy()
        env = ToyWorld(variant=variant, config=config)
        region = region_labels(state, env, config["evaluation"]["near_threshold"])
        violation = data["collision"][ix] & in_obstacle(predicted, env)
        _npz(root / "results" / "test_predictions" / f"{variant}_seed{seed}_{split}.npz",
             state=state, action=action, true=true, predicted=predicted, region=region,
             collision=data["collision"][ix], source_index=ix, obstacle_violation=violation)
        for name in ["all", "obstacle", "boundary", "other"]:
            mask = np.ones(len(ix), bool) if name == "all" else region == name
            metrics = position_metrics(predicted[mask], true[mask]) if mask.any() else dict(mse=None, rmse=None, mean_euclidean_error=None, median_euclidean_error=None, count=0)
            _metrics(rows, metrics, stage="one_step", variant=variant, seed=seed,
                     split=split, distribution="test", region=name)
        _record(rows, stage="one_step", variant=variant, seed=seed, split=split,
                distribution="test", metric="true_collision_predicted_inside_count", value=int(violation.sum()), n=len(ix))
    model = load_trained_model(root, variant, seed)
    for distribution_index, distribution in enumerate(["IID", "OOD"]):
        rng = np.random.default_rng(seed + (4000 if distribution == "IID" else 5000))
        if distribution == "IID":
            low, high = config["world"]["reset_low"], config["world"]["reset_high"]
        else:
            low, high = config["evaluation"]["ood_low"], config["evaluation"]["ood_high"]
        count = config["evaluation"]["probe_count"]
        starts = rng.uniform(low, high, size=(count, 2)).astype(np.float32)
        actions = rng.integers(0, 4, size=(count, max(config["evaluation"]["horizons"])), dtype=np.int64)
        env = ToyWorld(variant=variant, config=config)
        env.reset(seed=seed + (6000 if distribution == "IID" else 7000))
        true = np.empty((count, actions.shape[1] + 1, 2), dtype=np.float32)
        true[:, 0] = starts
        collision = np.zeros(actions.shape, dtype=bool)
        boundary_clipped = np.zeros(actions.shape, dtype=bool)
        for t in range(actions.shape[1]):
            true[:, t + 1], collision[:, t], boundary_clipped[:, t] = env._transition_details(
                true[:, t], actions[:, t], noise=True)
        imagined = learned_rollout(model, starts, actions)
        if isinstance(true, torch.Tensor):
            true = true.cpu().numpy()
        if isinstance(imagined, torch.Tensor):
            imagined = imagined.cpu().numpy()
        errors = np.linalg.norm(imagined.astype(np.float64) - true.astype(np.float64), axis=-1)
        violation = collision & in_obstacle(imagined[:, 1:], env)
        qualifying = (errors[:, 1] <= .015) & (errors[:, 20] >= .10) & violation.any(axis=1)
        _npz(root / "results" / "probes" / f"{variant}_seed{seed}_{distribution}.npz",
             starts=starts, actions=actions, true=true, imagined=imagined, error=errors,
             collision=collision, boundary_clipped=boundary_clipped,
             obstacle_violation=violation, failure_qualifies=qualifying)
        _metrics(rows, position_metrics(imagined[:, 1], true[:, 1]), stage="one_step",
                 variant=variant, seed=seed, distribution=distribution, horizon=1)
        for horizon in config["evaluation"]["horizons"]:
            for metric, value in [("mean_euclidean_error", errors[:, horizon].mean()),
                                  ("median_euclidean_error", np.median(errors[:, horizon])),
                                  ("euclidean_rmse", np.sqrt(np.mean(errors[:, horizon] ** 2)))]:
                _record(rows, stage="rollout", variant=variant, seed=seed, distribution=distribution,
                        horizon=horizon, metric=metric, value=float(value), n=count)
        _record(rows, stage="failure_search", variant=variant, seed=seed, distribution=distribution,
                metric="qualifying_probe_count", value=int(qualifying.sum()), n=count)
    _save_part(root, "evaluation", variant, seed, rows)
    return rows


def _episode_metrics(episode_rows):
    successes = [r for r in episode_rows if r["success"]]
    return {
        "success_rate": (float(np.mean([r["success"] for r in episode_rows])), len(episode_rows)),
        "steps_to_goal": (float(np.mean([r["steps"] for r in successes])) if successes else None, len(successes)),
        "cumulative_reward": (float(np.mean([r["cumulative_reward"] for r in episode_rows])), len(episode_rows)),
        "collision_count": (float(np.mean([r["collision_count"] for r in episode_rows])), len(episode_rows)),
        "blocked_action_count": (float(np.mean([r["blocked_action_count"] for r in episode_rows])), len(episode_rows)),
        "boundary_clipped_count": (float(np.mean([r["boundary_clipped_count"] for r in episode_rows])), len(episode_rows)),
        "final_distance": (float(np.mean([r["final_distance"] for r in episode_rows])), len(episode_rows)),
    }


def planning_stage(config, variant, seed, root):
    """Paired random shooting, identical bank per step, separate real environments."""
    model = load_trained_model(root, variant, seed)
    planner = config["planner"]
    rows, episodes = [], []
    term_names = ["final_goal_distance", "path_length_cost", "obstacle_proximity_cost", "invalid_region_cost"]
    for distribution_index, distribution in enumerate(["IID", "OOD"]):
        for episode in range(planner["episodes_per_seed"]):
            noise_seed = seed * 100000 + 20000 + distribution_index * 1000 + episode
            bank_seed = seed * 100000 + 40000 + distribution_index * 1000 + episode
            candidate_rng = np.random.default_rng(bank_seed)
            bank = np.stack([generate_candidates(candidate_rng, planner["horizon"], planner["candidates"])
                             for _ in range(config["world"]["max_steps"])])
            # Canonical int64 little-endian bytes; the same bank is used by both MPC policies.
            bank_hash = hashlib.sha256(bank.astype("<i8").tobytes()).hexdigest()
            start_env = ToyWorld(variant=variant, config=config)
            start = start_env.reset(seed=noise_seed)
            if distribution == "OOD":
                # Dedicated sampler uses the prespecified episode seed, independent
                # of the environment's future transition-noise generator.
                start = np.random.default_rng(noise_seed).uniform(
                    config["evaluation"]["ood_low"], config["evaluation"]["ood_high"]).astype(np.float32)
            _npz(root / "results" / "candidate_banks" / f"{variant}_seed{seed}_{distribution}_ep{episode}.npz",
                 candidates=bank, start=start, bank_seed=np.asarray(bank_seed),
                 noise_seed=np.asarray(noise_seed), bank_hash=np.asarray(bank_hash))
            for policy in ["Random", "Learned", "Oracle"]:
                env = ToyWorld(variant=variant, config=config)
                env.reset(seed=noise_seed)
                env.state = start.copy()
                random_rng = np.random.default_rng(bank_seed + 10000)
                trace = {k: [] for k in ["actions", "rewards", "collision", "boundary_clipped",
                                         "predicted_next", "score", "best_index", "best_trajectory"] + term_names}
                states = [start.copy()]
                for t in range(config["world"]["max_steps"]):
                    if policy == "Random":
                        action = int(random_rng.integers(4))
                        selection = dict(predicted_next=np.full(2, np.nan, np.float32),
                                         score=np.nan, best_index=-1,
                                         best_trajectory=np.full((planner["horizon"] + 1, 2), np.nan, np.float32),
                                         score_terms={name: np.nan for name in term_names})
                    else:
                        action, selection = choose_action(
                            model if policy == "Learned" else None, env, states[-1],
                            bank[t], planner, oracle=(policy == "Oracle"))
                    next_state, reward, done, info = env.step(action)
                    states.append(next_state)
                    for name, value in dict(actions=action, rewards=reward, collision=info["collision"],
                                            boundary_clipped=info["boundary_clipped"],
                                            predicted_next=selection["predicted_next"], score=selection["score"],
                                            best_index=selection["best_index"], best_trajectory=selection["best_trajectory"],
                                            **selection["score_terms"]).items():
                        trace[name].append(value)
                    if done:
                        break
                trace = {k: np.asarray(v) for k, v in trace.items()}
                states = np.asarray(states, dtype=np.float32)
                _npz(root / "results" / "planning" / f"{variant}_seed{seed}_{distribution}_ep{episode}_{policy}.npz",
                     states=states, **trace, bank_hash=np.asarray(bank_hash),
                     noise_seed=np.asarray(noise_seed), bank_seed=np.asarray(bank_seed),
                     prediction_error=np.linalg.norm(trace["predicted_next"] - states[1:], axis=-1),
                     success=np.asarray(info["terminated"]))
                episodes.append(dict(variant=variant, seed=int(seed), distribution=distribution,
                                     episode=int(episode), policy=policy, start_x=float(start[0]), start_y=float(start[1]),
                                     noise_seed=int(noise_seed), bank_seed=int(bank_seed), bank_hash=bank_hash,
                                     success=bool(info["terminated"]), steps=len(trace["actions"]),
                                     steps_to_goal=len(trace["actions"]) if info["terminated"] else None,
                                     cumulative_reward=float(trace["rewards"].sum()),
                                     collision_count=int(trace["collision"].sum()), blocked_action_count=int(trace["collision"].sum()),
                                     boundary_clipped_count=int(trace["boundary_clipped"].sum()),
                                     final_distance=float(np.linalg.norm(states[-1] - env.goal))))
        for policy in ["Random", "Learned", "Oracle"]:
            selected = [r for r in episodes if r["distribution"] == distribution and r["policy"] == policy]
            for metric, (value, n) in _episode_metrics(selected).items():
                _record(rows, stage="planning", variant=variant, seed=seed, distribution=distribution,
                        policy=policy, metric=metric, value=value, n=n)
    _json(root / "results" / "episode_parts" / f"{variant}_seed{seed}.json", episodes)
    _save_part(root, "planning", variant, seed, rows)
    return rows


def aggregate_results(output_dir=SOURCE_ROOT):
    """Aggregate saved records without filtering unsuccessful seeds or episodes."""
    root = Path(output_dir).resolve()
    rows = []
    for path in sorted((root / "results" / "metric_parts").glob("*.json")):
        rows.extend(json.loads(path.read_text()))
    rows.sort(key=lambda r: tuple(str(r[k]) for k in METRIC_FIELDS if k not in {"value", "n"}))
    _csv(root / "results" / "metrics.csv", rows, METRIC_FIELDS)
    for seed in sorted({r["seed"] for r in rows}):
        _csv(root / "results" / "by_seed" / f"seed_{seed}.csv",
             [r for r in rows if r["seed"] == seed], METRIC_FIELDS)
    groups = defaultdict(list)
    for row in rows:
        groups[tuple(row[k] for k in GROUP_FIELDS)].append(row)
    summaries = []
    for key, records in groups.items():
        values = [r["value"] for r in records if r["value"] is not None]
        summary = dict(zip(GROUP_FIELDS, key))
        summary.update(mean=float(np.mean(values)) if values else None,
                       sd=float(np.std(values, ddof=1)) if len(values) > 1 else None,
                       n_seeds=len(values), n_seeds_total=len(records), n_observations=sum(r["n"] for r in records))
        summaries.append(summary)
    _csv(root / "results" / "metrics_summary.csv", summaries,
         GROUP_FIELDS + ["mean", "sd", "n_seeds", "n_seeds_total", "n_observations"])
    episodes = []
    for path in sorted((root / "results" / "episode_parts").glob("*.json")):
        episodes.extend(json.loads(path.read_text()))
    pooled, paired = [], []
    if episodes:
        episodes.sort(key=lambda r: (r["variant"], r["seed"], r["distribution"], r["episode"], r["policy"]))
        _csv(root / "results" / "planning_episodes.csv", episodes)
        episode_groups = defaultdict(list)
        pairing_groups = defaultdict(dict)
        for row in episodes:
            episode_groups[(row["variant"], row["distribution"], row["policy"])].append(row)
            pairing_groups[(row["variant"], row["seed"], row["distribution"], row["episode"])][row["policy"]] = row
        for (variant, distribution, policy), records in sorted(episode_groups.items()):
            result = dict(variant=variant, distribution=distribution, policy=policy,
                          episodes=len(records), successes=sum(r["success"] for r in records))
            result.update({k: v[0] for k, v in _episode_metrics(records).items()})
            pooled.append(result)
        _csv(root / "results" / "planning_pooled.csv", pooled)
        for key, policies in sorted(pairing_groups.items()):
            for left, right in [("Learned", "Random"), ("Oracle", "Random"), ("Learned", "Oracle")]:
                if left not in policies or right not in policies:
                    continue
                a, b = policies[left], policies[right]
                if (a["bank_hash"] != b["bank_hash"] or a["noise_seed"] != b["noise_seed"]
                        or (a["start_x"], a["start_y"]) != (b["start_x"], b["start_y"])):
                    raise AssertionError("MPC episode pairing violated")
                result = dict(zip(["variant", "seed", "distribution", "episode"], key))
                result.update(comparison=f"{left}_minus_{right}", bank_hash=a["bank_hash"])
                for metric in ["success", "cumulative_reward", "collision_count", "blocked_action_count",
                               "boundary_clipped_count", "final_distance"]:
                    result[metric + "_difference"] = float(a[metric]) - float(b[metric])
                result["steps_to_goal_difference_both_successful"] = a["steps"] - b["steps"] if a["success"] and b["success"] else None
                paired.append(result)
        _csv(root / "results" / "planning_paired_differences.csv", paired)
    result = dict(aggregation="Unweighted mean and sample SD across all available prespecified seeds; pooled planning is episode-weighted. NA is preserved for zero successful episodes.",
                  per_seed_summary=summaries, planning_pooled=pooled)
    _json(root / "results" / "metrics_summary.json", result)
    return result


def run_pipeline(output_dir=SOURCE_ROOT, seeds=None, variants=None, stages=("train", "evaluate", "plan")):
    """Run shared experiment logic; a subset is for documented reproducibility runs.

    No hyperparameter overrides are provided: config.json is checksum-locked.
    Independent output directories keep demonstration/reproduction runs separate.
    """
    verify_spec_lock()
    config = load_config()
    configure_runtime(config)
    seeds = config["seeds"] if seeds is None else list(seeds)
    variants = ["Basic", "Challenge"] if variants is None else list(variants)
    if not seeds or any(seed not in config["seeds"] for seed in seeds) or len(set(seeds)) != len(seeds):
        raise ValueError("seeds must be a nonempty unique subset of the frozen seeds")
    if not variants or any(variant not in ["Basic", "Challenge"] for variant in variants) or len(set(variants)) != len(variants):
        raise ValueError("variants must be Basic and/or Challenge without duplicates")
    if any(stage not in ["train", "evaluate", "plan"] for stage in stages):
        raise ValueError("unknown experiment stage")
    root = Path(output_dir).resolve()
    root.mkdir(parents=True, exist_ok=True)
    runtime_manifest(root, config, seeds, variants)
    timings_path = root / "results" / "phase_timings.json"
    timings = json.loads(timings_path.read_text()) if timings_path.exists() else []
    phase_functions = dict(train=train_stage, evaluate=evaluate_stage, plan=planning_stage)
    total_wall, total_cpu = time.perf_counter(), time.process_time()
    for variant in variants:
        for seed in seeds:
            for stage in stages:
                print(f"{variant} seed={seed} {stage}: running", flush=True)
                wall, cpu = time.perf_counter(), time.process_time()
                phase_functions[stage](config, variant, seed, root)
                record = dict(variant=variant, seed=seed, stage=stage,
                              wall_seconds=time.perf_counter()-wall, cpu_process_seconds=time.process_time()-cpu)
                timings = [r for r in timings if (r["variant"], r["seed"], r["stage"]) != (variant, seed, stage)] + [record]
                _json(timings_path, timings)
                print(f"{variant} seed={seed} {stage}: {record['wall_seconds']:.2f} s", flush=True)
    summary = aggregate_results(root)
    _json(root / "results" / "last_run_timing.json", dict(
        stages=list(stages), seeds=seeds, variants=variants,
        wall_seconds=time.perf_counter()-total_wall, cpu_process_seconds=time.process_time()-total_cpu))
    return summary


run_experiment = run_pipeline


def main(stages=("train", "evaluate", "plan")):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", "--root", type=Path, default=SOURCE_ROOT)
    parser.add_argument("--seeds", type=int, nargs="+", default=None,
                        help="Prespecified subset for a separately labelled reproduction run; default all five")
    parser.add_argument("--variants", choices=["Basic", "Challenge"], nargs="+", default=None)
    args = parser.parse_args()
    run_pipeline(args.output_dir, args.seeds, args.variants, stages)


if __name__ == "__main__":
    main()
