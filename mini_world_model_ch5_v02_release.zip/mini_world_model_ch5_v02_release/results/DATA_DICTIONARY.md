# 実測データの読み方

`metrics.csv` はseed別のtidyデータです。`stage` はdataset/training/one_step/rollout/planning/split_audit/failure_search、`variant` はBasic/Challenge、`split` はtrajectory（主評価）/transition（seed11のみの比較）、`distribution` はtest/IID/OOD等を表します。horizon・policyなどの非該当欄は空欄です。`n` はその指標の観測件数で、成功時stepsでは成功episode数です。未定義値を0で代用しません。

`metrics_summary.csv` は同じ条件をseed間で集約します。meanはseed内指標の等重み平均、sdはsample SD（ddof=1）、n_seedsは定義できたseed数、n_seeds_totalは元seed数、n_observationsは観測件数の合計。成功0のseedをsteps平均に0として混ぜず、定義できたseedを明示します。これは成功episode全体をpoolしたsteps平均とは一致しない場合があります。中央値やRMSEのseed平均もpooled値と区別します。

`planning_pooled.csv` はepisodeをpoolした表。各条件25episode、success_rate=successes/episodes、steps_to_goalは成功episodeだけの平均、その他は全episode平均。`planning_episodes.csv` は300行の全成否、`planning_paired_differences.csv` は同じ環境/seed/開始分布/episodeを対応させた差分です。

`test_predictions/*.npz` はstate/action/true/predicted/region/collision/source_index。`source_index` は元の保存datasetでのindex、CSVのfailure `test_index` はtest配列内index（0始まり）です。`probes/*.npz` はstarts(N,2)、actions(N,20)、true/imagined(N,21,2)、error(N,21)、collision/boundary_clipped(N,20)。state配列の0は初期状態です。

`planning/*.npz` はstates(T+1,2)、actions/rewards/collision/boundary_clipped(T)、predicted_next(T,2)、best_trajectory(T,11,2)、best_index(T)、scoreと4項内訳。Randomには予測/scoreがないため、その欄の配列はNaN、best_index=-1です。これは失敗値や欠損episodeではありません。

`candidate_banks/*.npz` は(80,128,10)の候補全体とstart、bank_seed、noise_seed、hashを含みます。hashはcandidateのlittle-endian int64配列bytesのSHA-256。same step bankの共有は現在stateの共有を意味しません。各policyのactionによって実状態は分岐します。

`failure_cases.json` は固定probeからの教材選択基準と全該当ID。`selected_challenge_rollout.npz` はその1例の完全な配列です。表示例の選別を、主評価からのseed/episode除外として解釈しないでください。

`runtime_manifest.json` と `last_run_timing.json` は主実行時の環境・コードhash・時間。図ラベルの修正や文書作成は実験後に行っているため、最終ファイル群のhashは別のfinal artifact manifestに記録します。core、runner、SPEC、configの実験後不変を別途照合します。
