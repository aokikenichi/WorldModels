# 第5章 実測反映用の改訂ガイド

このファイルは「世界モデル入門_v0.2-edit1_SOL-master.docx」の第5章と付録Fに対する変更案です。canonical masterは変更していません。実験仕様は事前固定した `SPEC.md` / `config.json` を基準とし、本文の識別子は原稿内の実在Wordブックマークで確認しました。確認記録は `source_audit.md` にあります。

実測値は保存結果から転記済みです。以下の推奨コードは本文への掲載案であり、検証済みの実行入口は共通module・CLI・実行済みNotebookです。下記のAPIは共通実装 `mini_world_model.py` と照合済みです。最終掲載時は共通Python実装の関数を抜粋し、notebook用に別ロジックを作らないでください。図は `figures/` に保存します。

## 変更01 5.1を実装済み教材の導入へ更新

- **対象節・アンカー**：5.1、`SOL_P0264`、`SOL_P0265`、`SOL_P0266`、`SOL_T019`（EM-02）。
- **現行文章・コードの問題**：`SOL_T019` は「まだ実行確認しておらず、『動作確認済み』ではありません」と記す。未実装状態のままでは今回の成果物へ案内できない。一歩予測、rollout、planningの役割は本文にあるが、独立した評価として結果を並べていない。
- **実装で確定した事実**：状態を直接入力するMLPで、データ収集→学習→一歩予測→model-only rollout→候補比較→一手実行→再観測/再計画を共通ロジックで実行する。BasicとChallengeの2環境、5学習seedを事前固定した。実行確認結果は 39テスト合格、新規kernelコード7セル完走、1294配列/24tensor/256指標行が再実行で完全一致。
- **推奨する修正文**：「本章では、学習モデルを用いた一歩予測、モデルだけによる長期展開、予測を使った閉ループ制御を順に実測します。この三つは同じ評価ではありません。一歩先が正確でも、予測を再入力する長期展開や、その予測で行動を選ぶタスクの成功を保証しません。障害物のないBasic版と、障害物・小さなノイズを含むChallenge版を同じモデルと計画手順で比較します。Dreamerの再実装は行いません。」
- **推奨するコード**：冒頭は `mini_world_model.ipynb` とCLIの同一実装へのリンクを置く。`SOL_T019` は実行方法、実行日、実行環境、実装レポートへの参照へ差し替える。新しいアルゴリズムのコードをこの導入に重複掲載しない。
- **推奨する図**：図5-1のBasic/Challenge並列表現。全体フローは Environment→Dataset→Learned Dynamics→One-step→Model-only Rollout→Planning→Action→Re-observation/Replanning。
- **実測値**：39テスト合格、新規kernelコード7セル完走、1294配列/24tensor/256指標行が再実行で完全一致（テスト数、notebook全セル実行、再現性照合）。参照：`results/metrics.csv`、`IMPLEMENTATION_REPORT.md`。
- **Q09/Q10/Q11/Q12**：Q12の実行確認部分を反映。Q09〜Q11の内容は変更02/07で明示する。実装の判定は完了。Colab現地確認はQ12の残件。
- **AS15**：導入ではOracleをToy World内の診断用参照条件として予告し、詳細は変更08へ。

## 変更02 5.2の環境仕様と独自APIを完全に記述

- **対象節・アンカー**：5.2、`SOL_P0269`、`SOL_P0270`、`SOL_P0271`、`SOL_P0272`、`SOL_P0273`、`SOL_P0275`、`SOL_T020`、`SOL_T021`。
- **現行文章・コードの問題**：障害物4座標、ノイズ分布/scale/順序、reset、終了、reward式、真値比較のノイズ設定がない。`SOL_T020` は4要素返却を `terminated` と呼ぶだけで時間切れとの区別がない。
- **実装で確定した事実**：以下の全パラメータを実験前に固定した。仕様準拠テスト結果は 自動テスト全39件合格。環境処理順・境界・collision・reset/transition RNGの検査を含む。

| 要素 | 確定した仕様 |
|---|---|
| state / action | state=(x,y)∈[0,1]²、float32。0=UP、1=DOWN、2=LEFT、3=RIGHT |
| 基本移動量 | 0.05、UPはy増加、RIGHTはx増加 |
| goal / 判定 | (0.9,0.9)、移動後Euclidean distance≤0.05 |
| reset | x,y独立Uniform(0.05,0.35)。非終端位置 |
| 終了 | goal成功または80step。成功と時間切れが同時なら成功優先 |
| reward | d(s,goal)−d(s′,goal)−0.01−0.10I(collision)+1.0I(success) |
| Basic | 障害物なし、ノイズなし、移動後[0,1]へclip |
| Challenge障害物 | 閉長方形[0.4,0.6]×[0.35,0.65] |
| Challengeノイズ | 2次元独立Gaussian N(0,0.003²) |
| Challenge処理順 | 基本移動→ノイズ加算→境界clip→終点が閉障害物内なら全移動取消し |
| collision | 終点判定。線分との交差判定ではない |
| blocked | 障害物による取消し。境界clipの件数とは区別 |
| reset(seed) | 整数で専用NumPy Generatorを再初期化。Noneはstream継続 |
| transition | state/counterを変えない。Challengeかつnoise=Trueの場合のみ専用RNGを消費。Basicまたはnoise=Falseでは消費しない |

- **推奨する修正文**：「Basic版は境界で止まる決定論的な正方形空間です。Challenge版では中央の閉長方形[0.4,0.6]×[0.35,0.65]を障害物とします。基本移動に標準偏差0.003の独立Gaussianノイズを加え、境界でclipした後、終点が障害物内なら元位置へ戻します。ノイズを含む実環境と、ノイズを加えないOracleの計画を区別します。成功条件と報酬、終了条件は表に示した定義を使用します。」
- **推奨するコード**：`SOL_T020` のAPI説明を以下へ更新し、完全な処理順は共通実装の `ToyWorld` を参照する。

```python
state = env.reset(seed=11)  # stateのcopy、専用RNGを初期化
next_state, reward, done, info = env.step(action)
# done = 成功または時間切れ
# info["terminated"]: goal成功
# info["truncated"]: 時間切れ
# info["collision"], info["boundary_clipped"], info["blocked"]

next_state = env.transition(state, action, noise=True)
# env.stateやstep counterを変更しない真の遷移
```

- **推奨する図**：図5-1（`SOL_T021`）をBasic/Challengeの2面にし、障害物4座標、goal半径、IID reset長方形を表示。OOD領域は別色の輪郭と凡例で示す。
- **実測値**：自動テスト全39件合格。環境処理順・境界・collision・reset/transition RNGの検査を含む（boundary/collision/reset/transition RNGの自動テスト）。環境の数値は実測から推定した値ではなく事前固定パラメータ。
- **Q09/Q10/Q11/Q12**：Q11の未確定パラメータを全て解消する仕様。テストを確認し、実装では解消と判定した。Q12のAPI/shape検査にも対応。Q09のrewardとplanner scoreは異なる目的であると明記。Q10は変更07。
- **AS15**：Oracleは `transition(noise=False)` を使う。Challengeの実際のstepはnoise=True。将来の実ノイズを知る条件ではない。

## 変更03 5.3のデータ分割と被覆を実測へ置換

- **対象節・アンカー**：5.3、`SOL_P0278`、`SOL_P0280`、`SOL_P0281`、`SOL_T022`。
- **現行文章・コードの問題**：`rng`、seed、件数、trajectory識別子が未定義。「ランダム分割と軌跡分割の差を確認」はバックログのまま。
- **実装で確定した事実**：主seed=[11,22,33,44,55]、環境/seedごと200trajectory、各最大60遷移、成功時早期終了。主splitは140 train /30 val /30 test trajectory。収集60step打切りは環境80step終了と異なる。比較はseed11のみ、transitionランダム70/15/15%。診断用reward/termination/collision/boundaryとtrajectory/timeを保存する。
- **推奨する修正文**：「主評価では軌跡単位でtrain、validation、testを分けます。同じ軌跡に属する近接時刻の遷移をtrainとtestへ分配しません。別実験ではseed11のデータを遷移単位で混ぜ、同じモデルと学習条件で比較します。この比較ではtest集合自体も変わるため、誤差の差を漏洩だけによる因果効果とは断定できません。trajectory重複率と同じ行動の最近傍状態距離も確認します。」
- **推奨するコード**：`SOL_T022` に `trajectory_id` と `time` を保存する導線を追加。読者用コードは共通 `experiment.collect_dataset(config, variant, seed, root)` を呼び出し、seed式はSPECへ集約する。split生成もこの共通収集実装を使う。実行結果にtrain/val/testの件数と重複検査結果を表示。
- **推奨する図**：training dataの状態被覆図、split比較表。図5-3と同じ座標系でOOD長方形を表示すれば被覆を読みやすい。
- **実測値**：全環境/seedで12,000遷移、主split=8,400/1,800/1,800、140/30/30軌跡、trajectory重複0（seed別遷移数とsplit件数）、Basic seed11 trajectory/transition MSE=4.7086e-07/1.15408e-06、最近傍median=0.00524241/0.0030113、軌跡重複率0/1; Challenge seed11 trajectory/transition MSE=1.81025e-05/1.50287e-05、最近傍median=0.00504693/0.00489366、軌跡重複率0/1（両splitのMSE/RMSE、trajectory重複率、同一action最近傍距離）、seed11/22/33/44/55順、Basic=[3, 25, 6, 18, 7]、Challenge=[1, 24, 5, 23, 9]（各8,400 train state）（学習状態のOOD長方形訪問件数）。参照：`results/metrics.csv`、`results/metrics_summary.csv`、保存dataset/split index。
- **Q09/Q10/Q11/Q12**：Q12の未定義rng/seedを解消し、5.3バックログへ対応。Q09/Q10は該当なし。Q11のreset/RNGと整合する。
- **AS15**：全policyが同じ学習済みモデル条件/開始seedで比較される基盤。Oracleのために学習データを変えない。

## 変更04 5.4の単純MLPと学習条件を完全化

- **対象節・アンカー**：5.4、`SOL_P0283`、`SOL_P0285`、`SOL_P0287`、`SOL_T023`、`SOL_T024`、`SOL_T025`。
- **現行文章・コードの問題**：MLPの構造は明確だが、import、one-hot shape、optimizer、batch、epochs、checkpoint選択がない。「小さなMLPで十分」はone-step/rollout/planningのすべてに十分という誤読がありうる。
- **実装で確定した事実**：6→64→64→2、ReLU、delta残差の構造を維持。CPU float32、1 thread、60epochs、batch256、Adam lr0.001、weight decay0。validation MSE最小epoch、同値なら先のepoch。testで選択しない。予測stateへの真のclip/collision補正なし。
- **推奨する修正文**：「本実習では構造を固定した小さなMLPを使います。出力は移動量deltaであり、現在位置へ足して次状態を予測します。Challenge版が難しくてもモデルを複雑化せず、同じ構造の予測能力と限界を評価します。60epoch学習し、validationの次状態MSEが最小の重みを採用します。testは最終評価にだけ使います。」
- **推奨するコード**：`SOL_T023` のMLP構造は維持し、`forward` の第2引数を共通実装に合わせて整数actionsへ更新する。`forward` 内で `action_one_hot(actions)` を呼ぶ。one-hotは末尾次元4、stateは末尾次元2、連結入力は末尾次元6。`SOL_T024` は `pred_next = model(state_batch, action_batch)` としMSE式は維持する。具体例は末尾「掲載用コード抜粋」。全training loopを本文とnotebookで別実装しない。
- **推奨する図**：図5-2（`SOL_T025`）を6次元入力→MLP→delta2→加算の図へ確定。training lossはtrain/validationを分け、Basic/Challengeのseed間幅とbest epochを示す。
- **実測値**：Basic best epochs=[60, 58, 57, 60, 60]、best val MSE平均=5.25757e-07; Challenge best epochs=[50, 53, 60, 45, 59]、best val MSE平均=1.56465e-05（seed別best epoch、train/val loss、学習時間）。参照：training history、checkpoint、`results/metrics.csv`。
- **Q09/Q10/Q11/Q12**：Q12のshape/学習未実装へ対応。その他はモデル学習条件と整合することを確認する。
- **AS15**：Oracle比較のために学習済みMLPを変更しない。学習モデルの不足をOracleとの差として評価する。

## 変更05 5.5をone-step実測値と局所誤差へ置換

- **対象節・アンカー**：5.5、`SOL_P0290`、`SOL_P0291`、`SOL_P0292`、`SOL_T026`。
- **現行文章・コードの問題**：誤差測定と障害物侵入は提案/可能性で実測がない。`SOL_P0292` の0.005×20=0.1は仮想的な一定バイアス例であり、今回の測定値と混同できない。
- **実装で確定した事実**：主trajectory test全件で次状態MSE、RMSE、mean/median Euclidean position errorを計算。MSEは2座標を含む要素平均、Euclidean errorは各遷移の2次元距離。障害物近傍0.075、境界近傍0.075、otherの排他的分類（障害物優先）も保存する。
- **推奨する修正文**：「平均誤差と、場所ごとの誤差を分けて確認します。MSEは座標成分ごとの二乗誤差を平均した量、Euclidean errorは予測位置と真の位置の距離です。Basic版のtest平均位置誤差は0.00052503、Challenge版は0.00437960でした。Challenge障害物近傍の平均誤差は0.00949886で、otherの0.00406685より大きくなりました。一歩予測の精度だけから、長期展開やタスク達成を判断しません。」
- **推奨するコード**：共通 `position_metrics(pred, true)` で `mse = mean((pred-true)**2)`、`rmse = sqrt(mse)`、`position_error = norm(pred-true, axis=-1)` を計算。本文へ掲載する式の定義をCSV列と一致させる。
- **推奨する図**：図5-3（`SOL_T026`）にtrue next x/y対predicted next x/y、Toy World上の誤差mapを配置。近傍サンプル件数を明記。Challengeの真collisionかつ予測が障害物内に入る一歩例は存在する場合に保存して図示。
- **実測値**：Basic test MSE/RMSE/mean位置/median位置=1.07565e-06/0.000919815/0.000525027/0.00034713（5 seed内指標の平均、各test n=1,800）; Challenge test MSE/RMSE/mean位置/median位置=1.85118e-05/0.0042601/0.0043796/0.00368494（5 seed内指標の平均、各test n=1,800）（Basic/Challenge、test四指標、seed間SD）、Challenge obstacle/boundary/other mean位置誤差=0.00949886/0.00376152/0.00406685、全seed n=641/3,308/5,051。Basic obstacle n=0/NA（各領域nと誤差）、真collisionかつ予測障害物内のtest例65件を全保存。参照：`results/metrics.csv`、`results/metrics_summary.csv`、one-step failure保存データ。
- **Q09/Q10/Q11/Q12**：Q12のtest評価・図生成へ対応。Q11の真値ノイズはBasicなし/Challengeあり。Q09/Q10は該当なし。
- **AS15**：この節の精度指標と後のOracleとの差を混同しない。

## 変更06 5.6のmodel-only rolloutとfailureを実測へ置換

- **対象節・アンカー**：5.6、`SOL_P0295`、`SOL_P0296`、`SOL_P0297`、`SOL_P0298`、`SOL_P0299`、`SOL_P0301`、`SOL_T027`、`SOL_T028`。
- **現行文章・コードの問題**：再帰入力の説明は正しいが、`one_hot` とshape、真値側ノイズ、horizon別測定、衝突分岐例が未確定。
- **実装で確定した事実**：各seed/環境/IID・OOD条件で256start、一様random action20step。同じstart/action列で真環境 `transition(noise=True)` とlearned model-only rolloutを比較。horizon1/5/10/20のendpoint Euclidean mean/median/RMSE。start以外のtrue stateをモデルへ入れず、予測にclip/collision補正をしない。
- **推奨する修正文**：「真の軌跡と想像軌跡には、同じ初期位置と同じ20行動を与えます。真のChallenge遷移にはノイズを含めますが、MLPは一つの予測位置を返します。想像軌跡の2歩目以降は、直前の予測位置を入力します。IIDの平均位置誤差はBasicで1歩0.00031853から20歩0.00277204、Challengeで0.00391333から0.02172736へ増えました。誤差は常に単調に増えるとは限りません。実測した軌跡に即して、どの時点で分岐したかを確認します。」
- **推奨するコード**：`SOL_T027` は共通 `learned_rollout(model, starts, actions)` を抜粋。starts=(N,2)、actions=(N,H)、出力=(N,H+1,2)であり、環境objectを受け取らない。具体例は末尾「掲載用コード抜粋」。自動テストで途中の `env.step` 呼び出しとteacher forcingの混入を検出する。図生成は保存済みtrue/imagined配列を読み取る。
- **推奨する図**：図5-4（`SOL_T028`）の同じ平面にtrue実線/imagined破線を重ね、horizon別誤差曲線を併置する。Challenge教材例の事前条件はh1≤0.015、h20≥0.10、true collision時にimagined nextが障害物内。該当例がある場合はh20最大、同値はseed/分布/index順。該当なしなら明記し、最大誤差例と別ラベルにする。
- **実測値**：Basic IID H1/5/10/20 mean位置誤差=0.000318535/0.00096725/0.00161509/0.00277204; Basic OOD H1/5/10/20 mean位置誤差=0.00261348/0.0102338/0.0214103/0.043216; Challenge IID H1/5/10/20 mean位置誤差=0.00391333/0.00944145/0.0142327/0.0217274; Challenge OOD H1/5/10/20 mean位置誤差=0.00558866/0.0171058/0.0312014/0.058252（1/5/10/20、環境/分布別）、事前条件に11/2560例が該当。表示例seed11/IID/probe189、H1=0.003708353、H20=0.368967138、collision時刻=[3, 5, 6, 7, 10, 14, 16, 18]（存在有無、seed、分布、probe index、h1/h20、collision時刻）。参照：`results/metrics.csv`、`results/metrics_summary.csv`、保存probe配列。
- **Q09/Q10/Q11/Q12**：Q12のrollout実装・horizon評価・failure可視化、Q11の真値ノイズを解消する対象。Q09/Q10は該当なし。
- **AS15**：Oracleのrolloutも同じaction候補を使うが、ここでの評価真値はnoise=True、Oracle計画はnoise=Falseであることを区別する。

## 変更07 5.7のscoreとsmoothness名称を統一

- **対象節・アンカー**：5.7、`SOL_P0304`、`SOL_T029`。報酬との区別は5.2 `SOL_P0270`。
- **現行文章・コードの問題**：本文はgoal距離/障害物接近/移動コスト、コードは最終距離と `smoothness_cost` のみ。計算は連続位置の変位ノルム和であり、滑らかさではなく軌跡長。旧移動係数0.01も今回事前固定値0.02へ変更する。
- **実装で確定した事実**：以下のscoreを全seed/環境/Learned・Oracleで固定する。既知のgoal・障害物幾何をscoreに使うが、learned予測の位置を真のcollision処理で修正しない。

```text
score = -1.0 * final_goal_distance
        -0.02 * path_length_cost
        -0.05 * obstacle_proximity_cost
        -1.0 * invalid_region_cost

final_goal_distance = ||s_H - goal||₂
path_length_cost = Σ(t=1..H) ||s_t - s_(t-1)||₂
obstacle_proximity_cost = mean(t=1..H) max(0, 1 - distance(s_t, rectangle)/0.05)
invalid_region_cost = mean(t=1..H) [I(s_t∈closed obstacle) + I(s_t outside [0,1]²)]
```

Basicは障害物接近/障害物内部の項が0。障害物内部のrectangle distanceは0。invalidの境界外判定は厳密に座標<0または>1。planner scoreはreal step rewardとは異なる。

- **推奨する修正文**：「行動列のscoreは、最終位置のgoal距離、途中の障害物接近、軌跡長、無効領域への侵入を別々に計算します。軌跡長は隣接位置の変位ノルムの合計で、滑らかさの評価ではありません。本章では `path_length_cost` と呼びます。係数は実験前に固定し、結果に合わせて調整していません。」
- **推奨するコード**：`SOL_T029` の `smoothness_cost` を `path_length_cost` へ変更し、共通 `score_terms(trajectories, env, planner_config)` と `score(...)` を抜粋する。本文の式、実装変数、保存score内訳を一致させる。入力shape=(N,H+1,2)、候補batch軸0、time軸1と明示する。
- **推奨する図**：goal距離、proximity、path length、invalidの意味を一つのToy World軌跡に注記。必要ならplanning比較の補図としてscore内訳を示す。
- **実測値**：係数は事前固定パラメータ。4項scoreの手計算一致、Basic障害物項0、invalid penaltyをpytestで確認（手計算との一致、Basic障害物項0、無効位置罰）、両MPCの全200episodeに4項内訳と選択候補/予測nextを保存（episode保存内訳の確認）。参照：tests、planning trace。
- **Q09/Q10/Q11/Q12**：Q09は本文/コードを4項へ統一することで解消。Q10は名称と計算の一致により解消。共通実装とテストを確認し、両項目とも実装では解消と判定した。Q11はreward式との区別、Q12はscore自動テストへ対応。
- **AS15**：Learned/Oracleが同じscoreを利用する。幾何知識の差をpolicy間へ持ち込まない。

## 変更08 5.7へAS15 Oracle MPCを採用して三条件比較

- **対象節・アンカー**：5.7、`SOL_P0304`、`SOL_P0306`、`SOL_P0307`、`SOL_T029`。5.10 `SOL_P0337`、付録F.2 `SOL_P0623`。別紙E06の参照先に一致。
- **現行文章・コードの問題**：現行はLearned planning対Randomしかなく、planning自体の効果と学習した遷移の誤りによる差を分けられない。前工程ではAS15は保留・未反映だった。
- **実装で確定した事実**：主実験はRandom、Learned-model MPC、Oracle MPC。H=10、候補128、一様random shooting、argmax同点先頭、最初の一手のみ実行、毎step再計画。候補bankはepisode/stepごと両MPCで同一。Oracleだけが `ToyWorld.transition(noise=False)` に置き換わる。CEMや手動候補追加、warm start、online再学習は使わない。
- **推奨する修正文**：「三条件を比較します。Randomは毎step一様ランダムに行動します。Learned-model MPCは学習したMLPで候補を展開します。Oracle MPCは、同じ候補列、horizon、score、再計画手順のまま、展開にToy Worldのノイズなし真遷移を使います。OracleはこのToy World内の診断用参照条件です。有限の候補と短いhorizonに制約されるため最適制御の保証や数学的な上界ではありません。また実環境の未来ノイズを先に知ることはありません。」
- **推奨するコード**：共通 `choose_action(model_or_None, env, state, candidates, planner_config, oracle=False)` の `oracle` 分岐だけを切り替える例を掲載。共有candidate bankを明示し、Learned/Oracleで同じcandidate hashを保存する。具体例は末尾「掲載用コード抜粋」。候補の一致テストを示す。実軌跡が分岐した後の現在stateまで同じになるとは説明しない。
- **推奨する図**：Basic/Challenge別に3policyのsuccess rate、successful steps、cumulative reward、collision、final distanceを表示するplanning比較図。seed別点を併記し、成功episode0ならstepsはNAと表示。
- **実測値**：IID開始：Basic Random=0/25成功、Learned=25/25成功、Oracle=13/25成功；Challenge Random=0/25成功、Learned=22/25成功、Oracle=21/25成功 と OOD開始：Basic Random=0/25成功、Learned=24/25成功、Oracle=17/25成功；Challenge Random=0/25成功、Learned=19/25成功、Oracle=19/25成功。5seed×各5episode＝各環境/分布/policy25episode。Basic/Challenge×IID/OOD×3policy＝計300episode。参照：`results/metrics.csv`、`results/metrics_summary.csv`、seed別値、paired episode差、candidate hash。
- **Q09/Q10/Q11/Q12**：Q09/Q10は共通scoreで統一済みかを確認。Q11のnoise設定を明示。Q12は3条件の実測と再現性で解消する対象。LearnedがRandomへ勝つことは合格条件にしない。
- **AS15**：**採用**。Random→Oracleの差はこのscore/有限探索下でplanningを利用する効果、Learned↔Oracleの差は計画モデルを置き換えたときの閉ループ成績差として読む。Challengeではノイズなし骨格と確率遷移の平均との差もあるので、純粋なMSE誤差だけの影響とは断定しない。失敗が大きければ教材として保存する。

## 変更09 5.8で再観測と固定モデル評価を明確にする

- **対象節・アンカー**：5.8、`SOL_P0309`、`SOL_P0310`、`SOL_P0311`、`SOL_P0312`、`SOL_P0313`、`SOL_P0314`、`SOL_P0315`、`SOL_P0316`、`SOL_P0317`。
- **現行文章・コードの問題**：`SOL_P0309` はreplay追加/周期的再学習に言及する。今回の比較は学習済みモデル固定なので、オンライン再学習を実装したと誤読させない整理が必要。
- **実装で確定した事実**：best sequenceの先頭actionだけを実環境で実行し、得たnext stateから再計画。全trace、実nextと選択actionの予測nextとの差、score内訳を保存する。主比較中は学習モデルの重みを更新しない。
- **推奨する修正文**：「選んだ列の最初の行動だけを実行し、新しい位置を観測します。次の計画はこの実位置から始めます。想像rollout中に真の位置を入力するのではなく、実際に一手動いた後に状態を更新する点が重要です。本実験ではモデルを固定して比較します。新しい経験をreplayへ加えて再学習する拡張は、別の実験として検討できます。」
- **推奨するコード**：共通episode実行関数から `plan → env.step(first_action) → trace保存 → next loop` 部分を抜粋。`SOL_P0316` は「本実験では重みを固定したまま1へ戻る。モデル更新は発展課題」とする。
- **推奨する図**：選択候補のimagined trajectoryと実行した一手の軌跡を区別する図。real interaction traceをplanning比較図へ使用。
- **実測値**：全300episode/18527実stepを再生しstate/reward/collision一致。再観測state・先頭action対応を検証。評価でoptimizer/model更新呼出なし（保存episode数、実行step/予測next差、固定checkpoint確認）。参照：planning traces、`results/metrics.csv`。
- **Q09/Q10/Q11/Q12**：Q12の閉ループ動作を確認。Q11はstep API/終了処理に準拠。Q09/Q10は変更07のscore利用。 
- **AS15**：両MPCで同一receding-horizon手順。モデル重みのオンライン更新という追加差を入れない。

## 変更10 5.9へOOD条件と今回の限界を明示

- **対象節・アンカー**：5.9、`SOL_P0319`、`SOL_P0320`、`SOL_P0321`、`SOL_P0322`、`SOL_P0323`、`SOL_P0324`、`SOL_P0325`、`SOL_P0326`、`SOL_T030`。関連5.3 `SOL_P0280`、5.10 `SOL_P0338`。
- **現行文章・コードの問題**：省略事項はあるが、既知幾何を使うscore、Oracleの制約、今回のOOD定義がない。OOD性能低下を当然の結果として要求する記述が残る。
- **実装で確定した事実**：OOD開始位置はx∈[0.05,0.20]、y∈[0.80,0.95]の独立一様分布を事前指定。IID reset=[0.05,0.35]²の外だが、全学習stateと完全にdisjointとは限らない。学習stateがOOD長方形を訪れた件数も集計する。one-step probe、20step rollout、planningを同じ分布で比較する。
- **推奨する修正文**：「OOD実験では、通常の開始分布から外れた左上の領域を事前に指定しました。これは開始分布の外であり、学習中に一度も訪れていない状態だけからなるという意味ではありません。全seedのtrain state訪問件数はBasic 59件、Challenge 62件（各42,000件中）です。20歩の平均位置誤差はIIDからOODへBasic0.00277204→0.04321598、Challenge0.02172736→0.05825204と増えました。一方Basic Oracleの成功率は52%→68%となりました。差が小さい場合もそのまま結果として扱います。既知のgoalと障害物幾何をscoreへ与えており、環境に関する全知識を学習だけで獲得した例ではありません。」
- **推奨するコード**：OOD sampler、学習stateの領域件数、probe/episodeの共通評価呼び出しを掲載。領域はconfig参照とし、結果を見て座標を変える操作を教材手順に入れない。
- **推奨する図**：IID/OODの開始長方形図と、one-step error / h20 rollout error / planning successの比較。色と軸をBasic/Challenge間で統一する。
- **実測値**：Basic IID→OOD: one-step=0.000318535→0.00261348、H20=0.00277204→0.043216、Learned成功=25/25→24/25; Challenge IID→OOD: one-step=0.00391333→0.00558866、H20=0.0217274→0.058252、Learned成功=22/25→19/25（環境/分布別one-step、h20、3policy success）、seed11/22/33/44/55順、Basic=[3, 25, 6, 18, 7]、Challenge=[1, 24, 5, 23, 9]（各8,400 train state）。参照：`results/metrics.csv`、`results/metrics_summary.csv`。
- **Q09/Q10/Q11/Q12**：Q12のOOD評価、Q11の開始分布確定へ対応。Q09/Q10の既知幾何とpath costを限界として説明。
- **AS15**：OODでもOracleは同じ有限候補/score/再計画。Oracleとの差が小さい/大きい両方を残す。

## 変更11 5.10の受け入れ条件を結果に依存しない形へ更新

- **対象節・アンカー**：5.10、`SOL_P0330`、`SOL_P0331`、`SOL_P0332`、`SOL_P0333`、`SOL_P0334`、`SOL_P0335`、`SOL_P0336`、`SOL_P0337`、`SOL_P0338`、`SOL_P0339`、`SOL_P0340`、`SOL_T031`。
- **現行文章・コードの問題**：「Randomより高い到達率」「OODで性能低下」「障害物失敗例最低一つ」が結果指定になっている。「数分以内」は未測定の目標。実装品質と望ましい実験結果を分ける必要がある。
- **実装で確定した事実**：主モデル10、split比較モデル2、5seed、固定実験300episode、共通notebook/CLI、pytest、保存seed別metrics、SPEC/config/source hash、1条件の再学習再評価照合を検証する。達成した条件と未検証条件を下表に記録した。
- **推奨する修正文**：「受け入れ条件は、仕様どおり実行され、再現可能な測定結果と失敗を保存できることです。Learned MPCの到達率がRandomより高いか、OODで性能が低下するかは実験で検証する仮説です。結果を得るために環境やseed、候補数を後から変更しません。固定条件で該当する障害物分岐例が存在した場合は保存し、存在しなければその旨を記録します。」
- **推奨するコード**：READMEの環境作成/pytest/全実験/Notebook全セル/再現照合のコマンドを短く引用。テスト群は境界、障害物、RNG、one-hot、MLP shape、model-only再帰、共通candidate、score/metricsを含む。
- **推奨する図**：training、one-step、rollout、planning、OOD、failureの全生成図へリンク。測定値をCSVと照合したことをレポートに記載。
- **実測値**：実装/5seed/300episode/39tests/7cell Notebook/再現照合は完了、Colab現地実行のみ未検証。期待と異なるOracle/分割結果を保存。参照：下記表、`IMPLEMENTATION_REPORT.md`、実行manifest、runtime記録、test結果。
- **Q09/Q10/Q11/Q12**：Q09/Q10/Q11の仕様解消と、Q12の実行/テスト/実測を分けて最終判定する。Colab上の実行をしていない場合は「CPUで実行、Colab向け手順を提供、Colab上の所要時間は未測定」と限定する。
- **AS15**：採用済みのOracle実装・実測を受け入れ項目へ追加する。既存原稿の未反映状態から更新する。

| 条件 | 原稿アンカー | 最終判定・根拠 |
|---|---|---|
| Python/PyTorch/NumPy/Matplotlib、CPU | SOL_P0332 | Python3.11.6/PyTorch2.5.1/NumPy2.2.6/Matplotlib3.10.1、macOS15.7.3 ARM CPU、torch thread1 |
| 数分以内目安 | SOL_P0333 | 主5seed全実験wall39.719秒/CPU39.019秒、seed11両環境Notebook図表示込み17.753秒。Colab時間未測定。全実験時間と読者向け単条件時間を区別。未達ならそのまま記載 |
| seed固定、loss、one-step | SOL_P0334 | Basic best epochs=[60, 58, 57, 60, 60]、best val MSE平均=5.25757e-07; Challenge best epochs=[50, 53, 60, 45, 59]、best val MSE平均=1.56465e-05 / Basic test MSE/RMSE/mean位置/median位置=1.07565e-06/0.000919815/0.000525027/0.00034713（5 seed内指標の平均、各test n=1,800）; Challenge test MSE/RMSE/mean位置/median位置=1.85118e-05/0.0042601/0.0043796/0.00368494（5 seed内指標の平均、各test n=1,800） |
| horizon1/5/10/20 | SOL_P0335 | Basic IID H1/5/10/20 mean位置誤差=0.000318535/0.00096725/0.00161509/0.00277204; Basic OOD H1/5/10/20 mean位置誤差=0.00261348/0.0102338/0.0214103/0.043216; Challenge IID H1/5/10/20 mean位置誤差=0.00391333/0.00944145/0.0142327/0.0217274; Challenge OOD H1/5/10/20 mean位置誤差=0.00558866/0.0171058/0.0312014/0.058252 |
| 障害物例 | SOL_P0336 | 事前条件に11/2560例が該当。表示例seed11/IID/probe189、H1=0.003708353、H20=0.368967138、collision時刻=[3, 5, 6, 7, 10, 14, 16, 18]。存在しないことは仕様違反ではない |
| 3policy複数seed比較 | SOL_P0337 | IID開始：Basic Random=0/25成功、Learned=25/25成功、Oracle=13/25成功；Challenge Random=0/25成功、Learned=22/25成功、Oracle=21/25成功。Learnedの優越を合格条件にしない |
| 事前指定OOD比較 | SOL_P0338 | Basic IID→OOD: one-step=0.000318535→0.00261348、H20=0.00277204→0.043216、Learned成功=25/25→24/25; Challenge IID→OOD: one-step=0.00391333→0.00558866、H20=0.0217274→0.058252、Learned成功=22/25→19/25。低下の有無を合格条件にしない |
| 共通notebook/CLI | SOL_P0339 | 共通moduleをimportし、新規kernelでコード7セル全実行/error0。seed11は主実験の256指標行と完全一致 |
| 教育用の注意書き | SOL_P0340 | READMEの実在記述を確認 |
| Basic/Challengeと失敗保存 | SOL_T031 | 実装/5seed/300episode/39tests/7cell Notebook/再現照合は完了、Colab現地実行のみ未検証。期待と異なるOracle/分割結果を保存 |

## 変更12 付録Fと別紙E02/E06の完了状況へ反映

- **対象節・アンカー**：付録F.1 `SOL_P0614`、`SOL_P0615`、`SOL_P0616`、`SOL_P0617`、`SOL_P0618`。付録F.2 `SOL_P0623`。別紙E02、E06（別紙自体にSOLブックマークはない）。
- **現行文章・コードの問題**：第5章実装、複数seed、図5-3/5-4は必須バックログ。E06ではAS15保留・未反映。現行ファイルは今回も変更しないため、次編集工程で実績へ更新する。
- **実装で確定した事実**：第5章用の共通実装、notebook、固定SPEC、seed別実測、図、README、実装レポート、改訂ガイドを成果物として用意する。作業前後のsource hash不変を確認する。公開GitHub/Colab URLは本工程の成果と混同しない。
- **推奨する修正文**：「第5章の実装・実測成果物を作成し、Q09〜Q12の確認結果をIMPLEMENTATION_REPORTに記録しました。AS15は採用し、同じ候補とscoreを用いるOracle MPCを追加しました。未達条件・実装上の問題・失敗例は同レポートに残しています。canonical masterへの反映は次の編集工程で行います。」実装・実測は完了し、Colab現地確認のみ残件として次工程へ引き継ぐ。
- **推奨するコード**：コードの再掲なし。成果物ファイル名、実行コマンド、図名、CSV、SPEC hashへの参照を置く。
- **推奨する図**：`SOL_P0618` を図5-3/5-4実測版の出力名と対応させる。新規研究図や他章の改訂は行わない。
- **実測値**：Q09解消/Q10解消/Q11解消/Q12部分解消（Colab現地実行残件）/AS15採用。本文反映は次編集工程、入力8ファイルの作業前後SHA-256一致、canonical未変更（results/source_preservation.json）。参照：`IMPLEMENTATION_REPORT.md`末尾、`source_audit.md`、hash検証記録。
- **Q09/Q10/Q11/Q12**：Q09=4項score一致、Q10=path_length_cost、Q11=全環境パラメータ、Q12=実行/実測と未達の明示。各項目を「解消/部分解消/未解消」と実証に基づいて記入し、単にコードが存在するだけでは実測完了としない。
- **AS15**：**採用**。前工程の「保留・未反映」を今回の実装方法と3条件実測へ更新。E06のその他の未採用Astro候補は採用済みにしない。

## 最終転記用の実測索引

| データ | 転記先 | 保存資料 |
|---|---|---|
| dataset件数・split・被覆 | 変更03 | datasetとsplit index、results/metrics.csv |
| seed別best epoch/loss/時間 | 変更04 | training history、checkpoint、runtime記録 |
| test四指標・領域別n/error | 変更05 | results/metrics.csv、results/metrics_summary.csv |
| h1/5/10/20 | 変更06 | results/metrics.csv、保存probe |
| failureの再現識別子 | 変更05/06 | one-step例、probe seed/分布/index/actions/true/imagined |
| 3policy全指標、seed間SD | 変更08 | results/metrics.csv、results/metrics_summary.csv、episode traces |
| IID/OOD比較・学習被覆 | 変更03/10 | results/metrics.csv、results/metrics_summary.csv |
| version/CPU/時間/テスト/再現性 | 変更01/11 | manifest、runtime、test結果、再実行照合 |
| Q09〜Q12、AS15、E02/E06 | 変更12 | IMPLEMENTATION_REPORT.md末尾 |

全数値は保存結果から転記し、図と本文に同じ分母/単位/集約方法を使います。success rateの分母は各環境/開始分布/policy25episode、steps to goalは成功episodeのみです。1条件でも成功0なら、その条件の成功step平均は0ではなくNAです。

## 図ファイルと本文アンカーの確定対応

| ファイル | 用途・本文アンカー | 読み方の注意 |
|---|---|---|
| figures/toy_world.png | 図5-1、SOL_T021、変更02 | 環境仕様の図。実測軌跡とは区別 |
| figures/dynamics_architecture.png | 図5-2、SOL_T025、変更04 | 構造の図。モデル入力整数actionは内部でone-hot化 |
| figures/training_loss.png | 5.4、SOL_P0285、変更04 | trainとvalidation、seedを区別 |
| figures/one_step_prediction.png | 図5-3左、SOL_T026、変更05 | held-out trajectory testのx/y散布図 |
| figures/one_step_error_map.png | 図5-3右、SOL_T026、変更05 | 全体平均と空間局所誤差を分ける |
| figures/rollout_error_by_horizon.png | 5.6、SOL_P0301、変更06 | model-only endpoint error。teacher forcingではない |
| figures/true_vs_imagined_rollout.png | 図5-4、SOL_T028、変更06 | 各環境のseed11・IID・probe0という事前固定表示例 |
| figures/planning_comparison.png | 5.7/5.10、SOL_P0337、変更08 | 3policy、複数seedの成績 |
| figures/ood_comparison.png | 5.9/5.10、SOL_P0338、変更10 | 事前指定IID/OOD開始条件 |
| figures/challenge_failure_example.png | SOL_P0291/SOL_P0301、変更05/06 | 事前固定の分岐条件を満たす例が存在する場合のみ |
| figures/challenge_max_error_example.png | SOL_P0301、変更06 | 分岐条件該当なしの場合の最大誤差例。分岐例と呼ばない |
| figures/challenge_one_step_failure.png | SOL_P0291/SOL_T026、変更05 | held-out true collisionで予測が障害物内へ入る例が存在する場合のみ |

最終稿では、存在するfailure画像だけを採用し、seed/分布/probe index/固定選択条件と実測値をキャプションへ記します。

## 掲載用コード抜粋

以下は共通APIの利用例です。MLPを呼ぶ第2引数は整数actionです。本文の旧 `action_onehot_batch` をそのまま渡すと新APIのshapeに合いません。`action_one_hot` はモデル内部で使うため、architectureの6入力という意味は変わりません。

### 5.4 SOL_T023とSOL_T024

```python
import torch
from torch.nn import functional as F
from mini_world_model import DynamicsModel, action_one_hot

model = DynamicsModel()
state_batch = torch.tensor([[0.2, 0.2], [0.3, 0.4]], dtype=torch.float32)
action_batch = torch.tensor([0, 3], dtype=torch.long)
assert action_one_hot(action_batch).shape == (2, 4)
pred_next = model(state_batch, action_batch)
assert pred_next.shape == (2, 2)
# 学習ではdatasetから取り出した next_state_batch を教師にする。
# loss = F.mse_loss(pred_next, next_state_batch)
```

モデル本体を掲載するなら `DynamicsModel.forward` の次の処理を元実装から抜粋します。架空の学習済み重みや教師値を教材の実測に使わないでください。

```python
one_hot = action_one_hot(actions).to(device=states.device, dtype=states.dtype)
delta = self.network(torch.cat((states, one_hot), dim=-1))
return states + delta
```

### 5.6 SOL_T027とSOL_P0301

```python
import numpy as np
from mini_world_model import learned_rollout

starts = np.asarray([[0.2, 0.2]], dtype=np.float32)
actions = np.asarray([[0, 0, 3, 3, 0]], dtype=np.int64)
imagined = learned_rollout(model, starts, actions)
assert imagined.shape == (1, 6, 2)
```

この例の `model` は上記shape確認用の未学習モデルのまま実験結果として使わず、training scriptが保存したcheckpointを `experiment.load_trained_model(root, variant, seed)` で読み込んだ学習済みモデルを使用します。主評価では保存probeの固定start/actionsを渡します。真値比較は `env.transition(..., noise=True)`、Oracle計画は `oracle_rollout(..., noise=False相当)` の違いがあります。`oracle_rollout` 自体にnoise引数はなく、内部でnoise=Falseを固定しています。

### 5.7 SOL_T029とAS15

```python
from mini_world_model import (
    ToyWorld, load_config, generate_candidates, choose_action, score_terms,
)

config = load_config()
env = ToyWorld("Challenge", config)
# seed11・IID・episode0の固定式
state = env.reset(seed=11 * 100000 + 20000)
planner = config["planner"]
candidate_rng = np.random.default_rng(11 * 100000 + 40000)
candidates = generate_candidates(
    candidate_rng, horizon=planner["horizon"], count=planner["candidates"]
)
learned_action, learned_info = choose_action(
    model, env, state, candidates, planner, oracle=False
)
oracle_action, oracle_info = choose_action(
    None, env, state, candidates, planner, oracle=True
)
```

この短いAPI例はseed11・IID・episode0の最初の候補集合を示します。全実測ではSPECのepisode/step別候補bankを保存して使います。本文の結果表に対応する実験を再現する際はplanning scriptを実行します。両呼び出しは同じ候補を比較できますが、評価episodeでは各policyを別の同seed環境で走らせ、そのpolicy自身が到達した位置から計画します。

### 5.8 SOL_P0309〜SOL_P0317

```python
# 実験ではepisode開始時に固定したcandidate bankの当該step分を使う。
action, plan_info = choose_action(
    model, env, state, candidates, planner, oracle=False
)
next_state, reward, done, info = env.step(action)
prediction_error = np.linalg.norm(next_state - plan_info["predicted_next"])
state = next_state  # 次の計画は、この新しい実観測から始める。
```

この一手を共通episode loopで繰り返し、traceを保存します。想像rolloutの途中にこの代入を挿入しないこと、主評価中はmodelの重みを更新しないことを説明します。


## 今回観測したOracle参照の限界

Basic IIDはLearned100%/Oracle52%で、Challenge IIDは88%/84%だった。OracleのBasic一歩予測誤差は全実行stepで0。保存軌跡の点検では境界の無移動と厳密goal半径のfloat32感度が確認された。scoreは途中のgoal到達でrolloutを打ち切らず、最終距離とpath lengthで有限候補を選ぶため、真の遷移でもタスク達成の上界にはならない。距離0.050000011920928955は固定半径0.05の外として扱った。成功率を上げるepsilon/score/環境変更はしていない。詳しい独立監査と未達条件はIMPLEMENTATION_REPORTの12/13節を参照し、本文で「Oracleが必ず最良」と書かない。


独立監査ではBasic Oracleの全2,894step・370,432候補に計算不一致0を確認した。即時成功actionを含む候補がある106step中76stepで別actionをscoreに従い選択した。具体例と再計算手順は `BASIC_ORACLE_AUDIT.md`。5.7 SOL_P0304/SOL_T029と5.10 SOL_P0337へ、最終状態中心のscoreと途中で終了するtaskのずれを説明する追記を推奨する。
