# Third-party dependencies

このrepositoryは第三者packageをvendorしません。`requirements.txt`から各packageを取得します。下表は2026-09-11に実測環境のinstalled metadataと同梱license fileを確認した直接依存です。正確な条文は各distributionのlicense fileを参照してください。

| Package | Version | License metadata | 用途 |
|---|---:|---|---|
| torch | 2.5.1 | BSD-3-Clause | model学習・推論 |
| numpy | 2.2.6 | BSD-3-Clause系。binary distributionの同梱ライブラリには別条件あり | 配列・保存形式 |
| matplotlib | 3.10.1 | Matplotlib License（PSF系） | figure生成 |
| pytest | 8.3.5 | MIT | tests |
| nbformat | 5.10.4 | BSD-3-Clause | Notebook I/O |
| nbclient | 0.10.2 | BSD-3-Clause | clean execution |
| ipykernel | 6.29.5 | BSD-3-Clause | Notebook kernel |

`requirements-lock.txt`は実測macOSホストのtransitive dependencyを含む環境記録です。一般Linux / Google Colabへそのまま適用する配布lockではありません。packageの再配布物をrelease ZIPへ同梱していないため、利用者のinstall時には取得された各packageのlicenseが適用されます。

この一覧はrepository licenseの選択を代替しません。また法的助言ではありません。公開主体は、公開時点のpackage配布物と利用形態に照らして最終確認してください。
