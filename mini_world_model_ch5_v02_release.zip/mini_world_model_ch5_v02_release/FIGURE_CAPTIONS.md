# 第5章へ転記できる図キャプション

図中の英語ラベルと対応する日本語案です。すべて同じ固定SPECを使います。主seedは11、22、33、44、55。距離・位置は単位正方形内の無次元値です。

| ファイル | キャプション案 |
|---|---|
| `toy_world.png` | 図5-1：事前固定したToy Worldの仕様。Basicは障害物・ノイズなし。Challengeは閉障害物[0.4,0.6]×[0.35,0.65]と各座標のGaussian遷移ノイズ（標準偏差0.003）を持つ。緑は通常の開始分布、紫は事前指定OOD開始分布、円はgoal到達半径0.05を示す。これは仕様の図で、実測軌跡ではない。 |
| `dynamics_architecture.png` | 図5-2：両環境で共通の残差MLP。位置2次元と行動one-hot4次元を連結し、64、64の中間層から移動量2次元を出力する。現在位置に移動量を足して次位置とし、rolloutではその予測位置を同じモデルへ再入力する。これはモデル構造の図。 |
| `training_loss.png` | 5.4補図：trajectory splitによる主モデルの学習曲線。各線は1 seed。青は更新中batchの平均train MSE、橙はepoch終了時のvalidation MSE。縦軸は対数で、両パネルの範囲は異なる。60epoch実行し、testを使わずvalidation最小epochを採用した。 |
| `one_step_prediction.png` | 図5-3左：真の次位置と予測次位置の比較。Basic/Challengeそれぞれ5モデルのheld-out trajectory test、計9,000遷移を表示する。破線は真値と予測が等しい位置。Challengeの真値には遷移ノイズを含む。 |
| `one_step_error_map.png` | 図5-3右：同じtest遷移の位置誤差分布。各六角形はそこに属する観測stateでのEuclidean予測誤差の平均。空白は未測定で、補間していない。両パネルの色スケールは共通。障害物近傍の局所誤差は全体平均だけでは見えにくい。 |
| `rollout_error_by_horizon.png` | 5.6補図：同じ初期位置・行動列による真の軌跡とmodel-only軌跡のendpoint誤差。各環境/分布で5 seed×256=1,280 probe。点はhorizon 1、5、10、20。帯はseed別平均の±sample SDであり信頼区間ではない。途中の真state入力は行っていない。Basic/Challengeの縦軸範囲は異なる。 |
| `true_vs_imagined_rollout.png` | 図5-4通常例：各環境seed 11・IID probe 0の20step軌跡。表示indexは結果から選んでいない。青実線が真環境、橙破線がmodel-only予測。最初の位置以外は真の状態で予測を補正しない。 |
| `planning_comparison.png` | 5.7補図：IID開始条件でのRandom、Learned MPC、Oracle MPC。各環境/policy 5 seed×5=25episodeのpool。stepsは成功episodeのみ、成功0ではNA。累積reward、blocked count、最終距離は全episode平均。両MPCはhorizon10・128候補・同一候補bank・同一scoreを使い、一手実行後に再観測する。Oracleも有限探索とscoreに制約される。 |
| `ood_comparison.png` | 5.9補図：事前指定したIID/OOD開始分布における一歩probe誤差、20歩誤差、planning成功率。probeは各条件1,280、planningはpolicyごと25episode。OODは開始分布の外であり、学習stateの完全未訪問領域ではない。開始位置によるタスク難度の違いも含むため、成功率差を予測汎化の因果効果と同一視しない。 |
| `challenge_failure_example.png` | 図5-4失敗例：Challenge seed11・IID probe189。事前条件を満たす11例のうち20歩誤差最大を表示。一歩位置誤差0.00370835に対し20歩誤差0.368967。青い真軌跡は障害物下辺に遮られるが、橙の想像軌跡は停止を再現できず分岐する。黒×は真のblocked action。全probe2,560件は評価に残している。 |
| `challenge_one_step_failure.png` | 図5-3局所例：Challenge seed44、主test index409の一歩予測。真の衝突で位置は変わらないが、予測は障害物内に入り、位置誤差は約0.0492。一歩testで同種の侵入例65件を保存し、その中の最大誤差例を表示した。拡大表示のためgoalは図外。 |

本文への転記では、test遷移上の一歩平均と、開始probe上の一歩平均を混同しないでください。異なる状態分布の測定です。詳細値とseed別SDは `results/metrics.csv`／`metrics_summary.csv`、各図の生成元は `plots.py` にあります。
