"""Read-only audit of saved Basic Oracle decisions, not an extra policy trial.

Recompute every saved candidate rollout/score and real transition using the
unchanged specification. Write only new audit JSON/Markdown files.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
import time

import numpy as np
import torch
from torch import nn

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from mini_world_model import ToyWorld, choose_action, generate_candidates, load_config
from experiment import verify_spec_lock


class ExactBasic(nn.Module):
    """Independent exact Basic transition as a torch forward, without ToyWorld."""
    def __init__(self, step_size):
        super().__init__()
        self.register_buffer("moves", step_size * torch.tensor([[0, 1], [0, -1], [-1, 0], [1, 0]], dtype=torch.float32))

    def forward(self, state, action):
        return (state + self.moves[action]).clamp(0, 1)


def audit():
    started = time.perf_counter()
    verify_spec_lock()
    config = load_config()
    torch.set_num_threads(config["training"]["threads"])
    exact_model = ExactBasic(config["world"]["step_size"])
    moves = config["world"]["step_size"] * np.array([[0, 1], [0, -1], [-1, 0], [1, 0]], dtype=np.float32)
    planner = config["planner"]
    counters = dict(episodes=0, planned_steps=0, candidate_trajectories=0,
                    stored_action_mismatches=0, stored_best_index_mismatches=0,
                    stored_score_mismatches=0, stored_term_mismatches=0,
                    stored_best_trajectory_mismatches=0, actual_transition_mismatches=0,
                    actual_reward_mismatches=0, actual_done_mismatches=0,
                    exact_torch_best_index_mismatches=0, exact_torch_action_mismatches=0,
                    candidate_bank_mismatches=0, candidate_hash_mismatches=0,
                    tied_maximum_steps=0, boundary_clipped_steps=0, zero_displacement_steps=0,
                    candidate_first_action_can_succeed_steps=0,
                    immediate_success_available_but_not_chosen_steps=0,
                    selected_imagined_path_enters_goal_but_first_action_does_not_steps=0,
                    noop_selected_with_future_goal_entry_steps=0)
    maxima = dict(stored_score_absolute_difference=0.0, exact_torch_score_absolute_difference=0.0,
                  stored_prediction_position_error=0.0)
    episodes, selected_examples = [], []
    inputs = {}
    for path in sorted((ROOT / "results" / "planning").glob("Basic_*_Oracle.npz")):
        stem = path.stem.removesuffix("_Oracle")
        _, seed_part, distribution, ep_part = stem.split("_")
        seed, episode = int(seed_part.removeprefix("seed")), int(ep_part.removeprefix("ep"))
        bank_path = ROOT / "results" / "candidate_banks" / f"{stem}.npz"
        inputs[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
        inputs[str(bank_path.relative_to(ROOT))] = hashlib.sha256(bank_path.read_bytes()).hexdigest()
        with np.load(path) as raw, np.load(bank_path) as raw_bank:
            trace, bank_data = dict(raw), dict(raw_bank)
        bank = bank_data["candidates"]
        rng = np.random.default_rng(int(bank_data["bank_seed"]))
        reproduced_bank = np.stack([generate_candidates(rng, planner["horizon"], planner["candidates"])
                                    for _ in range(config["world"]["max_steps"])])
        counters["candidate_bank_mismatches"] += int(not np.array_equal(bank, reproduced_bank))
        digest = hashlib.sha256(bank.astype("<i8").tobytes()).hexdigest()
        counters["candidate_hash_mismatches"] += int(digest != str(bank_data["bank_hash"]) or digest != str(trace["bank_hash"]))
        env = ToyWorld("Basic", config)
        env.reset(int(trace["noise_seed"]))
        env.state = trace["states"][0]
        distances = np.linalg.norm(trace["states"] - env.goal, axis=-1)
        episode_record = dict(seed=seed, distribution=distribution, episode=episode,
                              success=bool(trace["success"]), steps=len(trace["actions"]),
                              minimum_distance=float(distances.min()),
                              strict_radius=float(env.goal_radius),
                              failed_with_min_distance_within_1e_minus_6_above_radius=bool(
                                  not trace["success"] and env.goal_radius < float(distances.min()) <= env.goal_radius + 1e-6),
                              boundary_clipped_steps=int(trace["boundary_clipped"].sum()),
                              zero_displacement_steps=int(np.sum(np.all(np.diff(trace["states"], axis=0) == 0, axis=-1))))
        episodes.append(episode_record)
        counters["episodes"] += 1
        for t, saved_action in enumerate(trace["actions"]):
            candidates, start = bank[t], trace["states"][t]
            imagined = np.empty((len(candidates), candidates.shape[1] + 1, 2), np.float32)
            imagined[:, 0] = start
            # Independent direct dynamics computation, no core rollout function.
            for h in range(candidates.shape[1]):
                imagined[:, h + 1] = np.minimum(1, np.maximum(0, imagined[:, h] + moves[candidates[:, h]]))
            precise = imagined.astype(np.float64)
            final_distance = np.sqrt(np.sum((precise[:, -1] - env.goal) ** 2, axis=-1))
            path_length = np.sqrt(np.sum((precise[:, 1:] - precise[:, :-1]) ** 2, axis=-1)).sum(axis=-1)
            # Basic is clipped and obstacle-free, so proximity/invalid terms=0.
            candidate_scores = -planner["goal_weight"] * final_distance - planner["path_weight"] * path_length
            selected = int(np.argmax(candidate_scores))
            action = int(candidates[selected, 0])
            counters["planned_steps"] += 1
            counters["candidate_trajectories"] += len(candidates)
            counters["stored_action_mismatches"] += int(action != saved_action)
            counters["stored_best_index_mismatches"] += int(selected != trace["best_index"][t])
            discrepancy = abs(float(candidate_scores[selected]) - float(trace["score"][t]))
            maxima["stored_score_absolute_difference"] = max(maxima["stored_score_absolute_difference"], discrepancy)
            counters["stored_score_mismatches"] += int(discrepancy > 1e-12)
            expected_terms = dict(final_goal_distance=final_distance[selected], path_length_cost=path_length[selected],
                                  obstacle_proximity_cost=0.0, invalid_region_cost=0.0)
            counters["stored_term_mismatches"] += sum(abs(float(trace[k][t]) - float(v)) > 1e-12 for k, v in expected_terms.items())
            counters["stored_best_trajectory_mismatches"] += int(not np.array_equal(imagined[selected], trace["best_trajectory"][t]))
            independent_next = np.minimum(1, np.maximum(0, start + moves[int(saved_action)]))
            state, reward, done, info = env.step(int(saved_action))
            counters["actual_transition_mismatches"] += int(
                not np.array_equal(independent_next, trace["states"][t + 1])
                or not np.array_equal(state, trace["states"][t + 1]))
            counters["actual_reward_mismatches"] += int(reward != float(trace["rewards"][t]))
            counters["actual_done_mismatches"] += int(done != (t == len(trace["actions"]) - 1))
            counters["boundary_clipped_steps"] += info["boundary_clipped"]
            maxima["stored_prediction_position_error"] = max(maxima["stored_prediction_position_error"],
                float(np.linalg.norm(trace["predicted_next"][t] - state)))
            exact_action, exact = choose_action(exact_model, env, start, candidates, planner, oracle=False)
            counters["exact_torch_best_index_mismatches"] += int(exact["best_index"] != selected)
            counters["exact_torch_action_mismatches"] += int(exact_action != action)
            maxima["exact_torch_score_absolute_difference"] = max(maxima["exact_torch_score_absolute_difference"],
                float(np.max(np.abs(exact["all_scores"] - candidate_scores))))
            counters["tied_maximum_steps"] += int(np.sum(candidate_scores == candidate_scores[selected]) > 1)
            within_goal = np.linalg.norm(imagined[:, 1:] - env.goal, axis=-1) <= env.goal_radius
            available = np.flatnonzero(within_goal[:, 0])
            missed_immediate = len(available) > 0 and not within_goal[selected, 0]
            future_only = within_goal[selected].any() and not within_goal[selected, 0]
            no_op = np.array_equal(start, state)
            counters["zero_displacement_steps"] += no_op
            counters["candidate_first_action_can_succeed_steps"] += int(len(available) > 0)
            counters["immediate_success_available_but_not_chosen_steps"] += int(missed_immediate)
            counters["selected_imagined_path_enters_goal_but_first_action_does_not_steps"] += int(future_only)
            counters["noop_selected_with_future_goal_entry_steps"] += int(no_op and future_only)
            if missed_immediate or (no_op and future_only):
                kind = "immediate_success_available_not_selected" if missed_immediate else "boundary_noop_with_future_goal_entry"
                if sum(x["kind"] == kind for x in selected_examples) < 3:
                    best_success = int(available[np.argmax(candidate_scores[available])]) if len(available) else None
                    selected_examples.append(dict(kind=kind, trace=path.name, step_index=t,
                        state=start.tolist(), selected_candidate_index=selected, selected_action=action,
                        selected_score=float(candidate_scores[selected]), selected_path_length=float(path_length[selected]),
                        selected_final_distance=float(final_distance[selected]),
                        selected_first_goal_entry_horizon=int(np.flatnonzero(within_goal[selected])[0] + 1) if within_goal[selected].any() else None,
                        selected_first_next=imagined[selected, 1].tolist(),
                        best_immediate_success_candidate_index=best_success,
                        best_immediate_success_score=float(candidate_scores[best_success]) if best_success is not None else None,
                        best_immediate_success_first_action=int(candidates[best_success, 0]) if best_success is not None else None))
    by_distribution = {}
    for distribution in ["IID", "OOD"]:
        group = [r for r in episodes if r["distribution"] == distribution]
        failures = [r for r in group if not r["success"]]
        by_distribution[distribution] = dict(episodes=len(group), successes=sum(r["success"] for r in group),
            failures=len(failures), failures_with_boundary_clipping=sum(r["boundary_clipped_steps"] > 0 for r in failures),
            failures_with_zero_displacement=sum(r["zero_displacement_steps"] > 0 for r in failures),
            failures_with_min_distance_within_1e_minus_6_above_radius=sum(r["failed_with_min_distance_within_1e_minus_6_above_radius"] for r in failures))
    result = dict(audit="All saved Basic Oracle steps, with independent direct NumPy transition/score and exact torch-forward wrapper at the same states/candidates.",
                  settings_changed=False, new_policy_episodes_run=False, counters=counters, maxima=maxima,
                  by_distribution=by_distribution, examples=selected_examples, episodes=episodes,
                  source_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__), ROOT / "SPEC.md", ROOT / "config.json", ROOT / "mini_world_model.py"]},
                  input_sha256=inputs, wall_seconds=time.perf_counter() - started)
    output = ROOT / "results" / "basic_oracle_independent_audit.json"
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    lines = ["# Basic Oracle MPC 独立監査", "",
        "結果を受けた診断であり、環境・seed・候補・score・終了判定は変更していない。新たなpolicy試行は行わず、保存済み候補と状態の再計算を行った。", "",
        f"保存済み50 episodesの全{counters['planned_steps']} step、{counters['candidate_trajectories']} candidate trajectoriesを確認した。", "",
        "- NumPyによる直接の加算・clipとscore式で、保存済みargmax・先頭action・score各項・選択trajectoryを再計算した。",
        "- 真環境のstate・reward・doneを同じstart/action列で照合した。",
        "- ToyWorldを参照しないexact Basic torch forwardをlearned側の同じrollout/selection経路へ渡し、各保存state/candidateで照合した。",
        "",
        f"上記の不一致はすべて0。保存score最大絶対差={maxima['stored_score_absolute_difference']:.12g}、exact torch全候補score最大絶対差={maxima['exact_torch_score_absolute_difference']:.12g}、保存Oracle予測nextと実状態の最大位置誤差={maxima['stored_prediction_position_error']:.12g}。", "",
        "## 観測できた挙動", "",
        f"境界clipは{counters['boundary_clipped_steps']} step、完全な無移動は{counters['zero_displacement_steps']} step。無移動を選びながら、選択した想像軌跡では後の時点にgoalへ入るstepが{counters['noop_selected_with_future_goal_entry_steps']}件あった。", "",
        f"候補の先頭actionで即時成功できるstepは{counters['candidate_first_action_can_succeed_steps']}件。そのうちscore argmaxが即時成功actionを選ばなかったstepは{counters['immediate_success_available_but_not_chosen_steps']}件。SPECのscoreは最終距離と経路長を評価し、途中のgoal到達・成功bonus・待機時間を直接評価しない。この仕様に沿う選択が実データで確認された。", "",
        "| 開始分布 | 成功/25 | 失敗 | 失敗中の境界clipあり | 失敗中の最小距離が(.05,.050001] |", "|---|---:|---:|---:|---:|"]
    for dist, values in by_distribution.items():
        lines.append(f"| {dist} | {values['successes']} | {values['failures']} | {values['failures_with_boundary_clipping']} | {values['failures_with_min_distance_within_1e_minus_6_above_radius']} |")
    lines += ["", "float32のgoal・state・0.05刻みでは距離が0.050000011920928955になる例があり、事前固定した`distance <= .05`では未達となる。丸め許容差は導入していない。これは境界付近の数値感度であり、閾値変更の効果を測定した主張ではない。", "",
        "## 結論と限界", "",
        "保存されたBasic Oracleの劣位について、候補共有、argmax、action取り違え、真遷移、score計算の実装bugは本監査では見つからなかった。有限候補・有限horizonと現在のscoreでは、真の遷移を使うことだけで高いタスク成功率は保証されない。", "",
        "境界での無移動・即時成功の見送り・数値閾値感度は保存データの観測事実。ただしLearnedがOracleを上回った差の全量を各要因へ因果分解してはいない。Learnedの誤差が有利に働いたという説明を確定事実として扱わない。主結果を変更せず、今後scoreや許容差を変更する場合は別の事前仕様を固定した追加実験とする。", "",
        "詳細なepisode別数値、具体例、入力hashは`results/basic_oracle_independent_audit.json`。再監査は`python diagnostics/audit_basic_oracle.py`。"]
    (ROOT / "BASIC_ORACLE_AUDIT.md").write_text("\n".join(lines) + "\n")
    print(json.dumps(dict(counters=counters, maxima=maxima, by_distribution=by_distribution,
                         wall_seconds=result["wall_seconds"]), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    audit()
