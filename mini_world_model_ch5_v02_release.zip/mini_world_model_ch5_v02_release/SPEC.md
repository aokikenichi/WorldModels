# Mini World Model 事前固定仕様 v1

固定日: 2026-09-08 JST。実験コード作成・学習・評価の前に確定。canonical masterは読み取り専用。結果を理由とする仕様変更・seed選別・再学習による選別をしない。bug修正は修正理由と影響を記録し、必要な実験を同じ仕様で再実行する。実験開始前の本ファイルとconfig.jsonのSHA-256を保存する。

## 目的と合格条件

Environment → Dataset → Learned Dynamics → one-step → model-only rollout → planning → action → re-observation/replanningをCPUで再現する。Dreamer再実装ではない。合格は仕様準拠、テスト、欠測を隠さない再現可能な実測。原稿5.10の「Randomに勝つ」「OODで低下」「障害物分岐例が必ず存在」は仮説・探索対象へ変更する。成功・失敗のいずれも保存する。

## ToyWorld と独自API

- state=(x,y)、閉正方形[0,1]^2、float32。action整数0=UP (0,+.05)、1=DOWN (0,-.05)、2=LEFT (-.05,0)、3=RIGHT (+.05,0)。不正actionは例外。
- goal=(.9,.9)。移動後のEuclidean distance <= .05で成功。最大80 step。成功または80 step到達でdone。成功を優先してterminated=True、時間切れはtruncated=True（同じstepで成功ならtruncated=False）。終了後stepは例外。
- 通常resetはx,y独立Uniform(.05,.35)。初期状態は非終端。reset(seed=None)はstateのcopyを返す。整数seed指定で当該環境のNumPy Generatorを再初期化、Noneは既存stream継続。
- step(action)は(next_state, reward, done, info)の4-tuple。infoにterminated/truncated/collision/boundary_clipped/blockedを含む。blockedは障害物で元位置に留まった行動数であり、boundary clipping件数は別途記録する。
- transition(state, action, noise=True)はnext_stateのみ返す。envのstate/step counterは変えない。noise=Trueではenv専用RNGを消費、noise=Falseでは消費しない。同一seedでresetし同じ呼出順なら再現する。末尾次元2のstateと対応するaction配列にも対応し、oracleをbatch化する。
- reward = d(old,goal) - d(next,goal) - .01 - .10*I(collision) + 1.0*I(success)。診断用報酬でありplanner scoreとは別物。boundary clipping単独には追加罰なし。

### Basic

障害物なし・ノイズなし。移動を足し各座標を[0,1]へclip。Challengeと同一MLP、候補生成、planner horizon、候補数、score framework。

### Challenge

中央障害物は閉長方形[xmin=.4,xmax=.6]×[ymin=.35,ymax=.65]。処理順は (1)stateへ基本移動量を加算 (2)独立2次元Gaussian N(0,.003^2)を加算 (3)[0,1]へclip (4)clip後の終点が閉障害物内なら移動を全て取り消して元stateへ戻す。endpoint collisionであり線分交差検査ではない。外部から渡す開始stateは空間内・障害物外。モデルの予測には真のclip/collision補正を施さない。

## seedsとDataset

- 主seed=[11,22,33,44,55]。両環境とも各seed独立に収集・学習・評価。
- 各seedで200 trajectories、最大60 transitions/trajectory、成功時早期終了（最大12,000 transitions）。収集方策は各step独立一様4行動。環境reset seed=seed*100000+trajectory_id、行動RNG seed=seed+1000。
- 保存: state/action/next_state/reward/terminated/collision/boundary_clipped/trajectory_id/time。収集打切り60は環境の80-step time limitと区別する。
- 主splitはseed+2000のRNGでtrajectory_idをshuffleし140 train /30 validation /30 test。testは学習・epoch選択に使わない。各split indexを保存。
- split比較は事前指定seed=11のみ、Basic/Challenge各1回。全transitionをseed+2000でshuffleし70/15/15%（整数切捨て、残りtest）、同じ学習条件。主trajectoryモデルを再利用。test自体が異なるため差を因果的な漏洩量とは断定しない。trainとtestのtrajectory重複率と同一action最近傍state距離を併記する。

## MLPとTraining

入力state2+action one-hot4、Linear(6,64)→ReLU→Linear(64,64)→ReLU→Linear(64,2)。出力delta、next=state+delta。損失は2座標を含むnext-state MSE。学習・推論とも予測へのclipなし。PyTorch CPU float32、1 intra-op thread、deterministic algorithms。

60 epochs、batch=256、Adam lr=.001、weight_decay=0、seedで初期化、各epoch seed+3000の専用torch Generatorでshuffle。validation MSE最小epochを採用、同値なら先のepoch。全epochのtrain/validation loss・best epoch・重みを保存。testで選択しない。

## One-step / rollout評価

- test全件でMSE=mean((pred-true)^2)、RMSE=sqrt(MSE)、mean/median Euclidean error。obstacle近傍はstateから長方形まで距離<=.075、boundary近傍はmin(x,y,1-x,1-y)<=.075。排他的分類はobstacle優先→boundary→other。Basicのobstacle群は空。
- IID評価probe startは通常reset分布、OODはx∼Uniform(.05,.20), y∼Uniform(.80,.95)。各seed/環境/分布で256 starts、独立一様action20個、RNG seed+4000（IID）/seed+5000（OOD）、true noise stream seed+6000/seed+7000。OODは**開始分布の外**であり全学習stateとdisjointという主張ではない。学習stateのOOD rectangle訪問件数も集計する。領域は結果から選ばない。
- 同一start・同一action列でtrue transition(noise=True)とlearned rolloutを比較。learnedにはstart以外のtrue stateを入れない。horizon=1,5,10,20のendpoint Euclidean mean/median/RMSEを保存。probeの一歩目もone-step四指標を計算する。
- 全probeのstate/actions/true/imagined/errorを保存しhorizon全点を描画する。
- Challenge教材例は全固定probeを対象に、h1 error<=.015かつh20 error>=.10、さらにtrue collision時にimagined nextが障害物内にある軌跡を探す。存在すればh20 error最大（同値はseed・分布・index順）を表示。存在しなければ「条件該当なし」と記録し、最大誤差例は別ラベルで保存。testのtrue collisionかつpredicted nextが障害物内の一歩例も全候補保存。これは表示例の選択であり評価集計から除外しない。

## score Q09 / Q10

score最大を採用。予測軌跡s0...sHについて

`score = -1.0*final_goal_distance -0.02*path_length_cost -0.05*obstacle_proximity_cost -1.0*invalid_region_cost`

- final_goal_distance=||sH-goal||2。
- path_length_cost=Σ(t=1..H)||st-s(t-1)||2。smoothnessとは呼ばない。
- obstacle_proximity_cost=mean(t=1..H)[max(0,1-distance(st,rectangle)/.05)]（Basicは0）。障害物内部の距離は0。
- invalid_region_cost=mean(t=1..H)[I(st∈closed obstacle)+I(any coordinate outside [0,1])]（Basicは前者0）。

Challengeでは本文の三要素を保ちinvalid領域罰も明記する。障害物geometryは既知でscoreにのみ利用する。learned遷移のcollisionを真値で補正しない。ノイズも障害物もmodelが学ぶ。全係数は今回の全実験で共通。

## planning AS15

- Random: step毎独立uniform。
- Learned MPC: H=10、N=128の独立uniform random shooting、batchでmodel-only rollout、argmax（同点は先頭）、先頭actionのみenv.step、観測して再計画。CEM、候補の手動追加、warm start、online再学習は行わない。
- Oracle MPC: learnedと同じH/N/candidates/score/first-action/replanning。唯一のplanning model差はToyWorld.transition(noise=False)に置換すること。既知の決定論的遷移骨格を使用し、将来の乱数は予見しない。Challenge真環境はnoise=True。ノイズと不連続のためconditional expectationそのものとは限らない。有限候補・有限horizonなので数学的上界とは呼ばず、Toy内diagnostic referenceとする。
- 各seed×環境×開始分布(IID/OOD)で5 episodes、各最大80。各条件25 episodes/分布/環境、合計300 episodes。
- episode start/noise seed=seed*100000+20000+distribution_index*1000+episode。同一条件の3policyで同じreset/startおよび環境noise streamを使う（到達stateは行動依存）。OOD reset後は専用start samplerでstateを設定する。
- 候補bank seed=seed*100000+40000+distribution_index*1000+episode、shape=(80,128,10)。Learned/Oracleは同一episode・同一stepのbankを使う。実軌跡が分岐するので現在stateは同一とは限らない。Random行動は別RNG seed=bank_seed+10000。start・bank hash・全実軌跡・予測next差・score内訳を保存する。
- 指標: success rate、steps to goal（成功のみ、成功0ならNA）、cumulative reward、collision/blocked count、boundary clipping count、final distance。seed別値と全25episodeのpoolを保存。seed間mean/sample SDも表示し、95%CIを必須にしない。paired episode差を保存する。
- 想定計算量は最大80×128×10 model steps/episodeをbatch化。10主モデル+2split比較モデルの60epochsを含めCPU数分を目標とし実測で判断する。超過しても設定を縮小せず報告する。Colab実時間は現地で未実行なら断定しない。

## 再現性・成果物・テスト

Python3.11前後、CPUのみ。実際に利用可能なPython/PyTorch/NumPy/Matplotlib/pytest等の厳密version、OS/CPU、thread設定を実行前manifestへ記録しrequirementsをpinする。環境依存のbitwise一致は保証しない。SPEC/config/source hash、seed、data/checkpoint、CSV、全probe/episode tracesを保持する。NotebookとCLIは共通moduleをimportし隠れ状態を持たない。Notebookを新規kernelで全セル実行する。

pytestでboundary、collision、reset・transition再現性、action one-hot、MLP shape、model-only rolloutがenv.stepを呼ばない、同一candidateのLearned/Oracle、score/metricsを検査。実験終了後に主seedの再学習・再評価を1条件再実行して配列・metricsを照合（再現性検査であり結果の選別ではない）。図の値は保存データから作り、目視する。原稿hashが作業前後不変であることを確認する。

README、IMPLEMENTATION_REPORT、CH5_REVISION_GUIDEに実測・未達条件・Q09〜Q12/E02/E06/AS15を記録。「教育用であり、安全重要用途には使用しない」をREADMEへ明記する。
