"""Validate saved measurements, replay real episodes, and compare the notebook run."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from mini_world_model import ToyWorld, load_config, position_metrics
from experiment import verify_spec_lock

ROOT = Path(__file__).resolve().parent


def load_rows(path):
    with Path(path).open(newline="") as f:
        return list(csv.DictReader(f))


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+"\n")


def check_saved_results(root=ROOT):
    root = Path(root)
    verify_spec_lock()
    config = load_config()
    episodes = load_rows(root / "results/planning_episodes.csv")
    assert len(episodes) == 300
    by_key = {}
    step_count = 0
    for row in episodes:
        variant, seed, dist, ep, policy = row["variant"], int(row["seed"]), row["distribution"], int(row["episode"]), row["policy"]
        stem = f"{variant}_seed{seed}_{dist}_ep{ep}"
        with np.load(root / "results/planning" / f"{stem}_{policy}.npz") as z:
            trace = dict(z)
        with np.load(root / "results/candidate_banks" / f"{stem}.npz") as z:
            bank = dict(z)
        digest = hashlib.sha256(bank["candidates"].astype("<i8").tobytes()).hexdigest()
        assert digest == row["bank_hash"] == str(trace["bank_hash"])
        np.testing.assert_array_equal(trace["states"][0], bank["start"])
        key = variant, seed, dist, ep
        value = (row["start_x"], row["start_y"], row["noise_seed"], row["bank_hash"])
        assert key not in by_key or by_key[key] == value
        by_key[key] = value
        env = ToyWorld(variant, config)
        env.reset(seed=int(row["noise_seed"]))
        env.state = trace["states"][0]
        for t, action in enumerate(trace["actions"]):
            actual, reward, done, info = env.step(int(action))
            np.testing.assert_array_equal(actual, trace["states"][t+1])
            assert reward == trace["rewards"][t]
            assert info["collision"] == trace["collision"][t]
            assert info["boundary_clipped"] == trace["boundary_clipped"][t]
            assert not done or t == len(trace["actions"])-1
            if policy != "Random":
                idx = trace["best_index"][t]
                assert action == bank["candidates"][t, idx, 0]
                np.testing.assert_array_equal(trace["best_trajectory"][t, 0], trace["states"][t])
                np.testing.assert_array_equal(trace["best_trajectory"][t, 1], trace["predicted_next"][t])
        assert done and len(trace["actions"]) <= config["world"]["max_steps"]
        assert info["terminated"] == (row["success"] == "True")
        assert int(row["steps"]) == len(trace["actions"])
        assert int(row["collision_count"]) == trace["collision"].sum()
        assert int(row["blocked_action_count"]) == trace["collision"].sum()
        assert float(row["cumulative_reward"]) == trace["rewards"].sum()
        assert row["steps_to_goal"] == (row["steps"] if info["terminated"] else "")
        np.testing.assert_allclose(float(row["final_distance"]), np.linalg.norm(trace["states"][-1]-env.goal), rtol=0, atol=1e-12)
        step_count += len(trace["actions"])
    metrics = load_rows(root / "results/metrics.csv")
    tested = 0
    for variant in ["Basic", "Challenge"]:
        for seed in config["seeds"]:
            split_names = ["trajectory", "transition"] if seed == 11 else ["trajectory"]
            for split in split_names:
                with np.load(root / "results/test_predictions" / f"{variant}_seed{seed}_{split}.npz") as p:
                    measured = position_metrics(p["predicted"], p["true"])
                for name, value in measured.items():
                    if name == "count": continue
                    matching = [r for r in metrics if r["stage"]=="one_step" and r["variant"]==variant and int(r["seed"])==seed
                                and r["split"]==split and r["distribution"]=="test" and r["region"]=="all" and r["metric"]==name]
                    assert len(matching) == 1
                    assert float(matching[0]["value"]) == value
                    tested += 1
    for row in load_rows(root / "results/planning_pooled.csv"):
        subset = [e for e in episodes if all(e[k] == row[k] for k in ["variant", "distribution", "policy"])]
        assert len(subset) == int(row["episodes"]) == 25
        successes = sum(e["success"] == "True" for e in subset)
        assert successes == int(row["successes"])
        assert float(row["success_rate"]) == successes/len(subset)
    result = {"passed": True, "episodes_replayed": len(episodes), "real_steps_replayed": step_count,
              "paired_episode_groups": len(by_key), "one_step_metrics_recomputed": tested,
              "checks": ["spec hash", "saved candidate hash and policy pairing", "same real start/noise stream",
                         "exact real trajectory replay", "MPC first action and re-observation",
                         "reward, termination, collision and success-only metrics", "one-step metrics from arrays", "pooled denominator"]}
    write_json(root / "results/saved_results_verification.json", result)
    return result


def compare_reproduction(root=ROOT, reproduction=None):
    root = Path(root)
    reproduction = Path(reproduction) if reproduction else root / "notebook_run"
    checked_files, checked_arrays, checked_tensors = 0, 0, 0
    # ZIP timestamps and torch archive filenames are not scientific results;
    # compare uncompressed arrays/tensors, not container bytes.
    targets = []
    for top in ["data", "results"]:
        for f in sorted((reproduction / top).rglob("*.npz")):
            rel = f.relative_to(reproduction)
            if str(rel).startswith("results/selected_challenge"):
                continue  # Display selection searches different numbers of seeds.
            targets.append((f, root / rel))
    for new, original in targets:
        assert original.exists(), str(original)
        with np.load(new, allow_pickle=False) as a, np.load(original, allow_pickle=False) as b:
            assert set(a.files) == set(b.files)
            for key in a.files:
                np.testing.assert_array_equal(a[key], b[key], err_msg=f"{new.relative_to(reproduction)}:{key}")
                checked_arrays += 1
        checked_files += 1
    for f in sorted((reproduction / "checkpoints").rglob("*.pt")):
        a = torch.load(f, map_location="cpu", weights_only=True)
        b = torch.load(root / f.relative_to(reproduction), map_location="cpu", weights_only=True)
        assert a.keys() == b.keys()
        for key in a:
            if key == "state_dict":
                for tensor_name in a[key]:
                    assert torch.equal(a[key][tensor_name], b[key][tensor_name])
                    checked_tensors += 1
            else:
                assert a[key] == b[key]
        checked_files += 1
    for f in sorted((reproduction / "checkpoints").rglob("history_*.csv")):
        assert f.read_bytes() == (root / f.relative_to(reproduction)).read_bytes()
        checked_files += 1
    original_rows = [r for r in load_rows(root / "results/metrics.csv") if int(r["seed"])==11]
    new_rows = load_rows(reproduction / "results/metrics.csv")
    canonical = lambda rr: sorted(json.dumps(r, sort_keys=True) for r in rr)
    assert canonical(original_rows) == canonical(new_rows)
    result = {"passed": True, "seed": 11, "variants": ["Basic", "Challenge"],
              "separate_run": "Notebook fresh kernel from collection through planning",
              "compared_files": checked_files, "compared_npz_arrays": checked_arrays,
              "compared_checkpoint_tensors": checked_tensors, "compared_metric_rows": len(new_rows),
              "equality": "exact arrays/tensors/CSV metrics on the measured host; NaN slots aligned",
              "excluded": "timings, archive metadata, display failure selection over a different seed pool"}
    write_json(root / "results/reproducibility_check.json", result)
    return result


def check_sources(root=ROOT):
    root = Path(root)
    expected = json.loads((root / "source_hashes_before.json").read_text())
    def locate(relative_path):
        for base in (root, *root.parents):
            candidate = base / relative_path
            if candidate.is_file():
                return candidate
        raise FileNotFoundError(f"Cannot locate editorial source: {relative_path}")

    after = {p: hashlib.sha256(locate(p).read_bytes()).hexdigest() for p in expected}
    assert expected == after
    write_json(root / "source_hashes_after.json", after)
    result = {"passed": True, "unchanged_files": len(after), "sha256": after}
    write_json(root / "results/source_preservation.json", result)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reproduction", type=Path, default=None,
                        help="optional seed-11 reproduction directory; a local notebook_run is auto-detected")
    parser.add_argument("--check-editorial-sources", action="store_true",
                        help="also verify the original manuscript inputs when they are available beside this repository")
    args = parser.parse_args()
    checks = [check_saved_results()]
    reproduction = args.reproduction
    if reproduction is None and (ROOT / "notebook_run").is_dir():
        reproduction = ROOT / "notebook_run"
    if reproduction is not None:
        checks.append(compare_reproduction(reproduction=reproduction))
    else:
        print("No notebook_run found; saved results were verified. "
              "Run the Notebook or pass --reproduction to add a seed-11 comparison.")
    if args.check_editorial_sources:
        checks.append(check_sources())
    for result in checks:
        print(json.dumps(result, ensure_ascii=False, indent=2))
