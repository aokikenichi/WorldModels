# Mini World Model 第5章教材

『世界モデル入門』第5章の付属実装です。2次元の教育用Toy Worldで、観測データからdynamics modelを学習し、model-only rolloutとreceding-horizon MPCまでをCPUで体験します。

これはDreamerそのものの実装ではありません。画像encoder、確率的latent、reward/value/policy学習、online再学習を省き、「学習した遷移モデル内で候補を試し、一手だけ実環境で動いて再観測する」という核に絞っています。研究用benchmarkや安全重要用途には使用しないでください。

## 第5章と同じ学習順序

Notebookは次の順に進みます。

1. Toy Worldを見る
2. Random policyでdatasetを作る
3. dynamics modelを学習する
4. one-step predictionを見る
5. model-only rolloutを見る
6. candidate action sequenceをworld model内で試す
7. MPCで一手進む
8. Random / Learned / Nominal-dynamics MPCを比較する
9. OODを見る
10. obstacle boundary等のfailure exampleを見る

環境・model・plannerはNotebookへコピーしていません。NotebookとCLIは同じ`mini_world_model.py`、`experiment.py`、`plots.py`を使います。固定仕様は`SPEC.md`、実測の詳細は`IMPLEMENTATION_REPORT.md`を参照してください。

## 動作環境

- Python 3.11.6で実測
- CPUのみで実行可能。GPUは不要
- PyTorch 2.5.1
- NumPy 2.2.6
- Matplotlib 3.10.1
- pytest 8.3.5
- nbformat 5.10.4、nbclient 0.10.2、ipykernel 6.29.5

`requirements.txt`は一般環境・Linux・Google Colab向けの直接依存です。`requirements-lock.txt`は実測macOSホストの完全な環境記録で、macOS固有packageを含みます。一般LinuxやColabでは`requirements.txt`を使ってください。指定versionはStep 13で変更していません。

## Installation

配布ZIPを展開し、このREADMEがあるディレクトリで実行します。

```bash
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip check
```

Windowsでは仮想環境の有効化だけ`.venv\\Scripts\\activate`に読み替えてください。

## Notebook

Jupyterで`mini_world_model.ipynb`を開き、CPU kernelで上から全セルを実行します。既定は固定seed 11のBasic / Challengeを、dataset生成からfigure生成まで完走し、`notebook_run/`へ保存します。実験条件を短縮していないため、環境によっては時間がかかります。

新規kernelによる非対話実行は次のとおりです。

```bash
python execute_notebook.py --clean-output
```

別ファイルへ実行済みNotebookを保存する場合は次を使います。

```bash
python execute_notebook.py --clean-output --executed-notebook mini_world_model.executed.ipynb
```

### Google Colab

無料Google ColabではCPU runtimeを選び、release ZIPを展開したディレクトリ一式を`/content/`へ置いてNotebookを開いてください。先頭セルが配布ディレクトリを確認し、Colabのときだけ`requirements.txt`をインストールします。ローカルとColabで実験moduleは分岐しません。

GitHub repositoryは未公開で、owner・repository名・visibilityが未確定です。そのため、仮URLのclone手順や`Open in Colab` badgeは入れていません。Step 13の実行環境から無料Colabの実セッションは利用できず、現地での通し実行・時間測定は未確認です。ローカルのfresh kernel通し実行結果は`RELEASE_MANIFEST.md`に記録しています。

## CLI

固定5 seed（11、22、33、44、55）の主実験を別出力先へ再現します。

```bash
python run_experiment.py --root reproduced_run
python plots.py --root reproduced_run
```

phaseを分ける場合も共通pipelineを使います。

```bash
python train.py --root staged_run
python evaluate.py --root staged_run
python plan.py --root staged_run
python plots.py --root staged_run
```

dataset量、epoch、MPC horizon、candidate数などを短縮するCLI overrideは用意していません。確定済みの主結果と混同しないよう、再実行には別の`--root`を指定してください。

## Testsと再現確認

```bash
python -m pytest -q
python verify_results.py
```

`verify_results.py`は保存済み300 planning episodesの再生、候補bank、実軌跡、一歩指標、pooled denominatorを検証します。`notebook_run/`があればseed 11再現も自動照合します。別の場所へNotebook出力を保存した場合は、次のように明示できます。

```bash
python verify_results.py --reproduction path/to/notebook_run
```

編集工程の原稿sourceまで監査する内部オプションは、該当sourceがある場合だけ`--check-editorial-sources`で使用します。

## Random Learned Nominal-dynamics MPC

- **Random**：world modelを使わないrandom action baseline。
- **Learned MPC**：学習したdynamics model内で候補行動列をrolloutし、最良列の先頭actionだけを実環境で実行して再観測します。
- **Nominal-dynamics MPC（診断用参照）**：Toy Worldの既知の決定論的遷移則を`noise=False`で使う比較条件です。

実装内部のAPI・CSV・既存成果物には`Oracle`、`oracle=True`、`oracle_rollout`という名称が残ります。これらは書籍本文の「Nominal-dynamics MPC（診断用参照）」に対応します。完全な未来情報、将来noiseの先読み、数学的な性能上界を意味しません。有限horizon・有限候補・手作りscoreの制約を受けます。

## IIDとOOD

- **IID**：学習時と同じreset分布から開始。
- **OOD**：事前固定した異なる開始分布から開始。

OOD開始領域は学習trajectoryの全状態と完全に非重複とは限りません。開始点とgoalの距離もIIDと異なるため、成功率差だけをモデルのOOD汎化劣化と解釈しないでください。

## Saved results

- `results/metrics.csv`：seed別のtidy metrics
- `results/metrics_summary.csv` / `.json`：seed集約
- `results/planning_episodes.csv`：成功・失敗を含む全episode
- `results/planning_pooled.csv`：方策別pooled結果
- `results/test_predictions/`：one-step真値と予測
- `results/probes/`：IID / OOD rollout probe
- `results/planning/`、`results/candidate_banks/`：軌跡と候補bank
- `results/failure_cases.json`、`results/challenge_one_step_failures.csv`：事前条件で探索したfailure
- `data/`：datasetとsplit
- `checkpoints/`：model重みと全epochのloss

列名・shape・NAの意味は`results/DATA_DICTIONARY.md`を参照してください。seed平均とepisode pooled平均は同じではありません。

保存済み5-seed主結果には、Challenge one-step mean position error約0.00438、Challenge IID rollout H20約0.0217、Challenge IIDのRandom / Learned / Nominal-dynamics MPCが0/25・22/25・21/25、Basic IIDが0/25・25/25・13/25、Challenge OOD Learnedが19/25を含みます。公開用整理ではこれらを再生成・置換していません。

## Figures

`figures/`には確定5-seed結果から作った主要図があります。

- `toy_world.png`：Basic / Challengeの仕様
- `dynamics_architecture.png`：共有MLP構造
- `one_step_prediction.png`、`one_step_error_map.png`：一歩予測
- `rollout_error_by_horizon.png`、`true_vs_imagined_rollout.png`：model-only rollout
- `planning_comparison.png`、`ood_comparison.png`：閉ループ比較
- `challenge_failure_example.png`、`challenge_one_step_failure.png`：局所failure
- `training_loss.png`：学習曲線

failure exampleは固定probe内で事前条件により選ばれた局所例で、平均例・代表例ではありません。図5-1〜5-4への対応は`FIGURE_CAPTIONS.md`を参照してください。

## 再現性上の注意

- `SPEC_LOCK.sha256`が`SPEC.md`と`config.json`を固定します。hash不一致では実験を開始しません。
- CPU、float32、PyTorch intra-op thread 1、deterministic algorithmsを使います。
- 同じseedでもOS、CPU、Python、PyTorch buildが異なればbit単位一致は保証しません。完走、形式、主要指標の合理的整合を確認してください。
- 実行時間は環境依存です。既存ホストや将来のColabでの一回の測定を一般的な保証値として扱わないでください。
- 5-seedの書籍掲載値は保存済み成果物です。別環境でのわずかな差で上書きしないでください。

## 詳細資料とライセンス状態

- `SPEC.md`：固定仕様
- `IMPLEMENTATION_REPORT.md`：実測と限界
- `BASIC_ORACLE_AUDIT.md`：診断用参照の独立監査
- `results/DATA_DICTIONARY.md`：出力schema
- `RELEASE_MANIFEST.md`：release内容と検証状態
- `THIRD_PARTY_DEPENDENCIES.md`：直接依存と第三者license
- `LICENSE_STATUS.md`：自作コード・生成図・外部依存を分けた公開判断

この配布物自身のlicenseは未選択です。第三者packageのlicenseは本repository自身への利用許諾ではありません。公開前に権利者がrepository licenseと、生成図・書籍関連素材の扱いを確定する必要があります。
