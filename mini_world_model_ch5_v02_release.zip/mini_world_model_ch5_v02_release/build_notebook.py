"""Build the reader notebook; experiment logic is imported, never copied."""
from pathlib import Path

import nbformat as nbf


def build():
    nb = nbf.v4.new_notebook()
    md, code = nbf.v4.new_markdown_cell, nbf.v4.new_code_cell
    nb.cells = [
        md("""# Mini World Modelをコードで体験する

『世界モデル入門』第5章と同じ順序で、Toy World、dataset、学習、一歩予測、model-only rollout、候補行動列、MPC、方策比較、OOD、failure exampleを確認します。

この教材は2次元の教育用Toy Worldであり、Dreamerそのものの実装ではありません。環境・model・plannerはNotebook内へ複製せず、`mini_world_model.py`、`experiment.py`、`plots.py`をCLIと共用します。教育・検証用であり、安全重要用途には使用しないでください。"""),
        md("""## 実行前の準備

ローカルでは、このNotebookと`requirements.txt`があるディレクトリで`python -m pip install -r requirements.txt`を実行してから、上から順に全セルを実行してください。

Google ColabではCPU runtimeを選び、release ZIPを展開したディレクトリ一式を`/content/`へ置いてください。次のセルは既知の配布ディレクトリを探し、Colabのときだけ`requirements.txt`をインストールします。GitHub repositoryは未公開のため、仮のclone URLやColab badgeは使用していません。"""),
        code("""from pathlib import Path
import json, os, sys, time

NOTEBOOK_STARTED = time.perf_counter()
try:
    import google.colab  # type: ignore
    IN_COLAB = True
except ImportError:
    IN_COLAB = False

candidates = [Path.cwd()]
if IN_COLAB:
    candidates += [Path("/content/mini_world_model"), Path("/content/mini_world_model_ch5_v02_release")]
    candidates += sorted(p for p in Path("/content").glob("mini_world_model*") if p.is_dir())
PROJECT_ROOT = next((p for p in candidates if (p / "requirements.txt").is_file()
                     and (p / "mini_world_model.py").is_file()), None)
if PROJECT_ROOT is None:
    raise FileNotFoundError("requirements.txtとmini_world_model.pyを含む配布ディレクトリで実行してください")
os.chdir(PROJECT_ROOT)

INSTALL_SECONDS = 0.0
if IN_COLAB:
    import subprocess
    started = time.perf_counter()
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
    INSTALL_SECONDS = time.perf_counter() - started
print("Runtime:", "Google Colab CPU" if IN_COLAB else "local CPU")
print("Project directory:", Path.cwd().name)
print("Package installation seconds:", round(INSTALL_SECONDS, 3))"""),
        code("""import csv
import numpy as np
import torch
import matplotlib.pyplot as plt
from IPython.display import display, Image
from mini_world_model import ToyWorld, load_config, learned_rollout, choose_action, generate_candidates
from experiment import run_pipeline, load_trained_model, verify_spec_lock
from plots import create_figures

verify_spec_lock()
config = load_config()
SEEDS = [11]
OUTPUT = Path("notebook_run")
print("Python", sys.version.split()[0], "PyTorch", torch.__version__, "NumPy", np.__version__)
print("CPU only; output directory:", OUTPUT)
print("Fixed seeds in this notebook run:", SEEDS)"""),
        md("""## 1 Toy Worldを見る

Basicは障害物と遷移noiseなし、Challengeは中央障害物と小さなGaussian noiseありです。状態は`(x, y)`、行動は上下左右、goalは右上です。"""),
        code("""fig, axes = plt.subplots(1, 2, figsize=(8, 3.5), constrained_layout=True)
for ax, variant in zip(axes, ("Basic", "Challenge")):
    env = ToyWorld(variant, config)
    start = env.reset(seed=11)
    ax.scatter(*start, c="#1f77b4", label="reset example")
    ax.scatter(*env.goal, c="#d62728", marker="*", s=130, label="goal")
    if env.obstacle is not None:
        xmin, xmax, ymin, ymax = env.obstacle
        ax.add_patch(plt.Rectangle((xmin, ymin), xmax-xmin, ymax-ymin, color="0.35", alpha=.7))
    ax.set(xlim=(0, 1), ylim=(0, 1), aspect="equal", title=variant, xlabel="x", ylabel="y")
axes[0].legend(loc="lower right", fontsize=8)
plt.show()"""),
        md("""## 2 Random policyでdatasetを作る

固定仕様どおり各環境で200 trajectories、各trajectory最大60 transitionsを収集します。次の`train` stageはdataset生成と学習を同じ共通pipelineで行います。dataset量や条件を短縮していません。"""),
        code("""train_summary = run_pipeline(output_dir=OUTPUT, seeds=SEEDS, stages=("train",))
for variant in ("Basic", "Challenge"):
    with np.load(OUTPUT / "data" / variant / "seed_11" / "transitions.npz") as data:
        print(variant, "transitions:", len(data["action"]),
              "trajectories:", len(np.unique(data["trajectory_id"])),
              "state shape:", data["state"].shape)"""),
        md("""## 3 Dynamics modelを学習する

状態2次元とaction one-hot 4次元を入力し、6→64→64→2の残差MLPで次状態を予測します。60 epochs、Adam、next-state MSE、trajectory単位splitです。testはcheckpoint選択に使いません。"""),
        code("""for variant in ("Basic", "Challenge"):
    model = load_trained_model(OUTPUT, variant, 11)
    history_path = OUTPUT / "checkpoints" / variant / "seed_11" / "history_trajectory.csv"
    with history_path.open(newline="") as handle:
        history = list(csv.DictReader(handle))
    best = min(history, key=lambda row: float(row["val_mse"]))
    print(variant, model)
    print("  best epoch:", best["epoch"], "validation MSE:", best["val_mse"])"""),
        md("""## 4 One-step predictionを見る

一歩予測には観測したstateを毎回入力します。位置誤差は長期rolloutやtask successとは別の評価です。"""),
        code("""evaluation_summary = run_pipeline(output_dir=OUTPUT, seeds=SEEDS, stages=("evaluate",))
for row in evaluation_summary["per_seed_summary"]:
    if (row["stage"] == "one_step" and row["distribution"] == "test"
            and row["region"] == "all" and row["split"] == "trajectory"
            and row["metric"] == "mean_euclidean_error"):
        print(row["variant"], "one-step mean position error:", row["mean"])
with np.load(OUTPUT / "results" / "test_predictions" / "Challenge_seed11_trajectory.npz") as pred:
    for i in range(3):
        print("true", pred["true"][i], "predicted", pred["predicted"][i])"""),
        md("""## 5 Model-only rolloutを見る

初期state以外はmodel自身の予測を次の入力へ再帰的に渡します。途中で真のstateへ置き換えるteacher forcingや、真の境界・障害物補正は行いません。"""),
        code("""with np.load(OUTPUT / "results" / "probes" / "Challenge_seed11_IID.npz") as probe:
    print("Challenge IID mean position error by horizon:",
          {h: float(probe["error"][:, h].mean()) for h in (1, 5, 10, 20)})
    idx = 0
    plt.plot(probe["true"][idx, :, 0], probe["true"][idx, :, 1], "o-", label="true")
    plt.plot(probe["imagined"][idx, :, 0], probe["imagined"][idx, :, 1], "o--", label="model-only")
    plt.gca().set(aspect="equal", xlim=(0, 1), ylim=(0, 1), xlabel="x", ylabel="y")
    plt.legend(); plt.show()"""),
        md("""## 6 Candidate action sequenceをworld model内で試す

固定仕様のrandom shootingで128本、horizon 10の候補列を生成し、Learned modelとNominal-dynamics MPC（診断用参照）で評価します。内部APIでは後者を`oracle=True`と呼びますが、未来noiseの先読みや性能上界を意味しません。"""),
        code("""model = load_trained_model(OUTPUT, "Challenge", 11)
env = ToyWorld("Challenge", config)
state = env.reset(seed=11)
candidates = generate_candidates(np.random.default_rng(123),
                                 horizon=config["planner"]["horizon"],
                                 count=config["planner"]["candidates"])
learned_action, learned_info = choose_action(model, env, state, candidates, config["planner"])
nominal_action, nominal_info = choose_action(None, env, state, candidates, config["planner"], oracle=True)
print("Learned MPC first action:", learned_action, learned_info["score_terms"])
print("Nominal-dynamics MPC first action (internal Oracle):", nominal_action, nominal_info["score_terms"])"""),
        md("""## 7 MPCで一手進む

最良候補列の先頭actionだけを実環境で実行し、得られた観測から再計画します。"""),
        code("""next_state, reward, done, info = env.step(learned_action)
print("Observed next state:", next_state, "reward:", reward, "done:", done)
new_candidates = generate_candidates(np.random.default_rng(124),
                                     horizon=config["planner"]["horizon"],
                                     count=config["planner"]["candidates"])
replanned_action, _ = choose_action(model, env, next_state, new_candidates, config["planner"])
print("Replanned action from the real observation:", replanned_action)"""),
        md("""## 8 Random Learned Nominal-dynamics MPCを比較する

同じepisodeの候補bankとnoise streamを揃え、各方策を閉ループで評価します。内部CSVの`Oracle`は書籍本文のNominal-dynamics MPC（診断用参照）に対応します。"""),
        code("""planning_summary = run_pipeline(output_dir=OUTPUT, seeds=SEEDS, stages=("plan",))
for row in planning_summary["planning_pooled"]:
    label = "Nominal-dynamics MPC" if row["policy"] == "Oracle" else row["policy"]
    print(row["variant"], row["distribution"], label,
          f'{row["successes"]}/{row["episodes"]}')"""),
        md("""## 9 OODを見る

IIDは学習時と同じreset分布、OODは事前固定した異なる開始分布です。OOD状態が学習trajectoryの全状態と完全に非重複とは限らず、goalまでの距離も異なるため、成功率差をそのまま因果的な汎化劣化とは解釈しません。"""),
        code("""for row in planning_summary["planning_pooled"]:
    if row["distribution"] == "OOD" and row["policy"] == "Learned":
        print(row["variant"], "OOD Learned success:", f'{row["successes"]}/{row["episodes"]}')"""),
        md("""## 10 Obstacle boundary等のfailure exampleを見る

failure exampleは固定probe内で事前条件により選んだ局所例で、平均例でも代表例でもありません。該当例がない場合に条件を変えて作ることもしません。"""),
        code("""failure = create_figures(OUTPUT)
print("Failure criterion matched:", failure["qualifying_count"], "/", failure["total_fixed_probes"])
for filename in ("toy_world.png", "one_step_prediction.png", "rollout_error_by_horizon.png",
                 "planning_comparison.png", "ood_comparison.png"):
    display(Image(filename=str(OUTPUT / "figures" / filename)))
failure_figure = "challenge_failure_example.png" if failure["qualifying_count"] else "challenge_max_error_example.png"
display(Image(filename=str(OUTPUT / "figures" / failure_figure)))

TOTAL_SECONDS = time.perf_counter() - NOTEBOOK_STARTED
BODY_SECONDS = TOTAL_SECONDS - INSTALL_SECONDS
timing = {"in_google_colab": IN_COLAB, "runtime": "CPU", "package_install_seconds": INSTALL_SECONDS,
          "notebook_body_seconds": BODY_SECONDS, "total_elapsed_seconds": TOTAL_SECONDS,
          "seed": 11, "variants": ["Basic", "Challenge"]}
(OUTPUT / "results").mkdir(parents=True, exist_ok=True)
(OUTPUT / "results" / "notebook_timing.json").write_text(json.dumps(timing, indent=2) + "\\n")
print(timing)"""),
        md("""## 読み取りの限界

- 一歩のMSE、model-only rollout、閉ループtask successは別々に読みます。
- Nominal-dynamics MPCも有限horizon、有限候補、手作りscoreに制約され、数学的な性能上界ではありません。
- 画像encoder、確率的latent、reward/value/policy学習、online再学習は扱いません。
- 主実測はCLIの固定5 seedです。このNotebookのseed 11だけから一般化しません。
- 詳細仕様は`SPEC.md`、全実測は`IMPLEMENTATION_REPORT.md`、列とshapeは`results/DATA_DICTIONARY.md`を参照してください。"""),
    ]
    nb.metadata = {
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {"name": "python", "version": "3.11.6"},
    }
    path = Path(__file__).with_name("mini_world_model.ipynb")
    nbf.write(nb, path)
    print(path)


if __name__ == "__main__":
    build()
