# 実装と事後診断の記録

## 仕様の固定と挙動の確認

SPEC.md/config.jsonを実験コード作成前に固定し、SPEC_LOCK.sha256を保存した。主実験時と最終成果物のcore、runner、SPEC、configはhashが同じ。結果に基づく環境・ノイズ・seed・データ量・学習設定・horizon・候補数・score・goal判定の変更はない。

共通SPECの「noise=TrueではRNGを消費」という説明は、ノイズを持つChallengeに適用する。Basicはノイズなしのためnoise=Trueでも乱数を消費しない。実装とこの非消費テストは主実験前に完成していた。改訂ガイドでは誤読を避けてこの適用範囲を明記した。ロック済みSPECの原文は保持している。

評価probeは真のtransitionと同じ `_transition_details` を通じてnext stateとcollisionを同時に記録する。この内部関数は `transition` と `step` が共用する唯一の遷移ロジックであり、評価用の別環境を実装したものではない。Oracleは公開 `transition(noise=False)` を使う。

## 事後に追加した診断

Basic OracleがLearnedを下回ったため、保存候補と状態を独立実装で全件再計算した。2,894step/370,432候補で不一致0。元のpolicyを変更した追加実験は実施していない。詳しくはBASIC_ORACLE_AUDIT.md。

float32のgoal距離が0.050000011920928955になる例は固定半径0.05の外と判定した。epsilonによる再分類、goal判定変更、成功率再集計はしていない。即時goal到達可能な候補を、最終状態中心scoreが選ばない挙動もそのまま保存した。

## 実行・出力上の対応

- 必要なPython依存が未導入だったため、Python3.11の作業用仮想環境へversion固定で導入した。
- Notebookの初回kernel起動はsandboxのsocket制限で失敗した。失敗ログを保存し、許可されたローカルkernelで通し実行した。
- 初回Matplotlib font cacheの警告には作業フォルダ内のcache先を指定した。
- 図のNAラベル、legend、x軸余白を目視確認に基づき調整した。図の元数値と実験結果は変更していない。最終Notebookも同じ共通実装で再実行し、主実験のseed11と再照合した。
- 自動テストのfloat32期待配列、改訂ガイド生成時の置換順序を修正した。主実験ロジックの変更ではない。最終39testsは合格し、残存プレースホルダーはない。

現地Google Colab実行・時間は未検証。これは成果物に明記した残件であり、本ホストでのCPU実行結果と区別する。
