# Mini World Model 実装・実測レポート

2026-09-08。『世界モデル入門』v0.2編集・第5工程。コードを書く前にSPECとconfigを固定し、Basic/Challenge×5 seedの学習・評価、Random/Learned/Oracle計300episodeをCPUで実行した。canonical masterを含む入力8ファイルはSHA-256不変。コードとNotebookは共通実装を使う。

一歩予測、長期rollout、タスク達成は異なる評価であることを測定で確認した。Challengeのtest平均位置誤差は0.00437960だが、固定probeには一歩0.00370835→20歩0.368967の分岐例があった。一方、IIDのLearned MPC成功率は88%。Oracleは84%であり、今回は「学習モデルがOracleより大きく劣る」という仮説は支持されなかった。Basicでも有限Oracle MPCは52%に留まった。失敗、数値境界、score設計の限界も確定結果として残す。

## 1 固定した環境仕様

state=(x,y)∈[0,1]²、float32。行動0=UP、1=DOWN、2=LEFT、3=RIGHT、基本移動量0.05、goal=(0.9,0.9)。resetは各座標独立Uniform(0.05,0.35)。移動後距離≤0.05で成功、最大80step、同時なら成功優先。`reset(seed=None)`→state、`step(action)`→(next_state,reward,done,info)、`transition(state,action,noise=True)`→next_stateという独自APIで、Gymnasiumへ変更していない。

reward=d(s,goal)−d(s′,goal)−0.01−0.10I(collision)+1.0I(success)。doneは成功または時間切れ、infoでterminatedとtruncatedを区別する。blocked countは障害物による移動取消しの件数で、境界clippingは別に数える。

Basicは障害物・ノイズなし、移動後clip。Challengeは閉障害物[0.4,0.6]×[0.35,0.65]。基本移動→各座標独立N(0,0.003²)ノイズ→[0,1]clip→終点が障害物内なら元位置へ戻す。終点判定であり、移動線分との交差判定ではない。RNGは環境専用。reset整数seedで再初期化、Noneでは継続。transitionは現在state/counterを進めず、noise=FalseではRNGも消費しない。

全seed式、処理順、評価・score条件は `SPEC.md`。SPEC hashは `dc6a3366a370081f935d030c42d2c22ccbdc95ac136118dd2eee64201964f157`、config hashは `3f3a367864592e167931c23f021390be45500d45207d4f785d4831716d7958ae`。主実験後も一致した。環境を後から簡単にする変更は行っていない。

## 2 Dataset

全10環境/seed条件で各200 trajectories×60遷移=12,000件を実際に収集した（計120,000件）。収集ではgoal早期終了がなかった。主splitは140/30/30 trajectories、遷移数は8,400/1,800/1,800。60stepの収集打切りは80stepの環境time limitと区別し、collector_cutoffとして保存した。最低3項に加えてreward、terminated、collision、boundary、trajectory ID、timeを保存する。

主splitのtrain/test trajectory重複は全seedで0。主testは環境ごと全seed計9,000遷移。事前指定seed 11でのみtransitionを混ぜたsplitとの比較を行った。

| 環境 | split（seed 11） | test MSE | test RMSE | test軌跡のtrain重複率 | 同一action最近傍距離median |
|---|---|---|---|---|---|
| Basic | trajectory | 4.7086e-07 | 0.000686192 | 0 | 0.00524241 |
| Basic | transition | 1.15408e-06 | 0.00107428 | 1 | 0.0030113 |
| Challenge | trajectory | 1.81025e-05 | 0.00425471 | 0 | 0.00504693 |
| Challenge | transition | 1.50287e-05 | 0.00387669 | 1 | 0.00489366 |

ランダムtransition splitではtestに現れる軌跡の100%がtrainにも現れ、同一action最近傍の中央値は小さくなった。しかしBasicのMSEはtrajectory splitより悪化し、Challengeは改善した。両test集合の難しさも変わるため、一方向の楽観化が必ず生じるとは結論しない。1 seedの小規模比較であり、漏洩の因果効果を推定したものではない。主評価をtrajectory splitに固定する方針は維持する。

## 3 Model

state2+one-hot action4=6入力、Linear(6,64)→ReLU→Linear(64,64)→ReLU→Linear(64,2)。4,738パラメータ。delta出力を現在stateへ足す。`DynamicsModel.forward` は整数actionを受け内部でone-hot化する。出力に真のclip/collision処理を施さない。同じ構造を両環境に使い、Transformer、ensemble、大規模化は導入していない。

## 4 Training

PyTorch CPU、float32、1 intra-op thread、deterministic algorithms。各seedで初期化、60epochs、batch256、Adam lr0.001/weight_decay0。全epochのtrain/validation lossを保存し、validation MSE最小epochを選択（同値は早いepoch）。testは学習やcheckpoint選択へ使っていない。自動テストでtest部分の値をNaNに置き換えても同一重みになることを確認した。

| 環境 | seed | best epoch | epoch1 train MSE | epoch60 train MSE | best val MSE |
|---|---|---|---|---|---|
| Basic | 11 | 60 | 0.000432754 | 3.6952e-07 | 1.3174e-06 |
| Basic | 22 | 58 | 0.000776553 | 3.9718e-07 | 2.0031e-07 |
| Basic | 33 | 57 | 0.000375145 | 9.20272e-08 | 9.55543e-08 |
| Basic | 44 | 60 | 0.000832295 | 6.35968e-08 | 6.67277e-08 |
| Basic | 55 | 60 | 0.000981793 | 7.95256e-07 | 9.4879e-07 |
| Challenge | 11 | 50 | 0.000442684 | 1.53027e-05 | 1.58588e-05 |
| Challenge | 22 | 53 | 0.000795686 | 1.8377e-05 | 1.26769e-05 |
| Challenge | 33 | 60 | 0.000383954 | 1.59543e-05 | 1.7995e-05 |
| Challenge | 44 | 45 | 0.000830308 | 1.49359e-05 | 1.50185e-05 |
| Challenge | 55 | 59 | 0.000994045 | 1.6564e-05 | 1.66835e-05 |

主モデル10個に加え、seed 11のtransition splitモデル2個を保存。各checkpointにbest epoch、validation値、seed、variant、config hashがある。train MSEはそのepoch内の更新中batch lossの平均、validation MSEはepoch終了時の重みでの評価。図 `figures/training_loss.png` では両者を区別する。

## 5 One-step結果

以下は主trajectory test、5 seedの指標平均±sample SD。各seedで1,800件。MSEは2座標を含む要素平均、RMSEはその平方根。median列はseed内medianの平均であり、全9,000件のpooled medianではない。RMSEもseed内RMSEの平均なので、表の平均MSEの平方根とは一般に一致しない。

| 環境 | MSE | RMSE | mean位置誤差 | median位置誤差 |
|---|---|---|---|---|
| Basic | 1.07565e-06 ± 1.15596e-06 | 0.000919815 ± 0.00053571 | 0.000525027 ± 0.000274048 | 0.00034713 ± 0.000136678 |
| Challenge | 1.85118e-05 ± 5.94555e-06 | 0.0042601 ± 0.000673958 | 0.0043796 ± 0.000241836 | 0.00368494 ± 8.27589e-05 |

領域はstateから障害物まで距離≤0.075を優先し、次に外枠まで≤0.075、残りother。各指標はseed平均、nは全seedの合計である。

| 環境 | 領域 | test n（全seed計） | mean位置誤差 ± seed SD |
|---|---|---|---|
| Basic | obstacle | 0 | NA ± NA |
| Basic | boundary | 3288 | 0.000718048 ± 0.000534097 |
| Basic | other | 5712 | 0.00041307 ± 0.000153162 |
| Challenge | obstacle | 641 | 0.00949886 ± 0.00190741 |
| Challenge | boundary | 3308 | 0.00376152 ± 0.000248077 |
| Challenge | other | 5051 | 0.00406685 ± 0.000103533 |

Challenge障害物近傍の誤差は0.00949886で、otherの0.00406685より大きい。真のcollisionで次stateが元位置なのに、予測が障害物内部へ入るtest例は65件。全例を `results/challenge_one_step_failures.csv` に保存した。図5-3用は `one_step_prediction.png` と `one_step_error_map.png`。後者の空白は未測定で、値を補間していない。

## 6 Multi-step結果

各環境/seed/開始分布256 starts、同じ20行動列を真環境と学習モデルへ与えた。初期state以外の真値入力はない。Basic真値は決定論的、Challenge真値にはノイズを含む。以下はendpoint位置誤差で、mean±seed SD、medianとEuclidean RMSEはseed内値の平均。Euclidean RMSEはsqrt(mean(||error||²))で、一歩座標RMSEの定義と区別する。

| 環境 | 開始分布 | horizon | mean位置誤差 ± seed SD | median位置誤差 | Euclidean RMSE |
|---|---|---|---|---|---|
| Basic | IID | 1 | 0.000318535 ± 0.000129602 | 0.000291761 | 0.000367157 |
| Basic | IID | 5 | 0.00096725 ± 0.000400394 | 0.000913925 | 0.00108707 |
| Basic | IID | 10 | 0.00161509 ± 0.000663139 | 0.00157287 | 0.00180752 |
| Basic | IID | 20 | 0.00277204 ± 0.00107531 | 0.00265443 | 0.00319087 |
| Basic | OOD | 1 | 0.00261348 ± 0.00130978 | 0.0018317 | 0.00341884 |
| Basic | OOD | 5 | 0.0102338 ± 0.00398558 | 0.00695531 | 0.0163894 |
| Basic | OOD | 10 | 0.0214103 ± 0.00427519 | 0.0121711 | 0.0362063 |
| Basic | OOD | 20 | 0.043216 ± 0.00406157 | 0.0197276 | 0.0722785 |
| Challenge | IID | 1 | 0.00391333 ± 9.51843e-05 | 0.00375384 | 0.00440703 |
| Challenge | IID | 5 | 0.00944145 ± 0.000581022 | 0.00858719 | 0.011403 |
| Challenge | IID | 10 | 0.0142327 ± 0.0010142 | 0.0126791 | 0.0185137 |
| Challenge | IID | 20 | 0.0217274 ± 0.00241061 | 0.0185836 | 0.02912 |
| Challenge | OOD | 1 | 0.00558866 ± 0.000805458 | 0.00508745 | 0.00641045 |
| Challenge | OOD | 5 | 0.0171058 ± 0.00268228 | 0.0145775 | 0.0213128 |
| Challenge | OOD | 10 | 0.0312014 ± 0.00413472 | 0.0241304 | 0.0412926 |
| Challenge | OOD | 20 | 0.058252 ± 0.0126255 | 0.0410317 | 0.0807393 |

IIDではBasic 0.000318535→0.00277204、Challenge 0.00391333→0.0217274へmean誤差が増えた。図は `rollout_error_by_horizon.png`。平均の増加は観測された事実で、全軌跡で誤差が単調増加する主張ではない。表示用の通常例 `true_vs_imagined_rollout.png` は各環境のseed11/IID/probe0と、結果を見る前に選んだindexである。

## 7 Random / Learned MPC / Oracle MPC比較

H=10、候補128本、一様独立random shooting、argmax同点先頭、先頭の一手だけ実行して実観測から再計画。学習済み重みは評価中に固定した。全候補bankを保存し、同じepisode/stepのLearnedとOracleへ同じ候補を渡した。環境noise stream/startも対応させた。実軌跡が分岐すれば現在stateは当然異なる。

score = −1.0 final_goal_distance −0.02 path_length_cost −0.05 obstacle_proximity_cost −1.0 invalid_region_cost。

path_lengthは連続状態の変位ノルム和。proximityは各未来位置のmax(0,1−rectangle distance/0.05)の平均。invalidは障害物内部指示関数と正方形外部指示関数の和の時間平均。Basicの障害物項は0。既知のgeometryは両plannerのscoreにだけ同じように与える。

Oracleの違いはplanning modelを `ToyWorld.transition(noise=False)` にすることだけ。真の将来乱数を利用せず、有限探索・固定scoreの診断用参照である。ノイズなし骨格は、衝突とノイズがある場合の厳密な条件付き平均と同一とは限らない。

全episodeをpoolした結果。分母は各行25。stepsは成功episodeのみ、その他は成功/失敗を含むepisode平均。collisionとblocked countは定義により同じ値。

| 環境 | 開始 | policy | 成功/25 | 成功率 | 成功時steps | 累積reward | collision/blocked | boundary clip | 最終goal距離 |
|---|---|---|---|---|---|---|---|---|---|
| Basic | IID | Random | 0/25 | 0% | NA | -0.66938 | 0 | 2.84 | 0.85737 |
| Basic | IID | Learned | 25/25 | 100% | 46.04 | 1.4975 | 0 | 0 | 0.030125 |
| Basic | IID | Oracle | 13/25 | 52% | 45.923 | 0.80699 | 0 | 9.28 | 0.0782 |
| Basic | OOD | Random | 0/25 | 0% | NA | -0.73045 | 0 | 6.48 | 0.69664 |
| Basic | OOD | Learned | 24/25 | 96% | 38.75 | 1.2856 | 0 | 0.08 | 0.036604 |
| Basic | OOD | Oracle | 17/25 | 68% | 41 | 0.85152 | 0 | 12.08 | 0.059867 |
| Challenge | IID | Random | 0/25 | 0% | NA | -0.79267 | 0.96 | 5.28 | 0.88465 |
| Challenge | IID | Learned | 22/25 | 88% | 57.318 | 1.181 | 0.36 | 1.72 | 0.050603 |
| Challenge | IID | Oracle | 21/25 | 84% | 52.143 | 1.115 | 0.96 | 5.84 | 0.051032 |
| Challenge | OOD | Random | 0/25 | 0% | NA | -0.77906 | 0.44 | 11.8 | 0.70125 |
| Challenge | OOD | Learned | 19/25 | 76% | 41.316 | 0.96281 | 0 | 0.68 | 0.057377 |
| Challenge | OOD | Oracle | 19/25 | 76% | 42.684 | 0.95015 | 0 | 17.32 | 0.059643 |

| 環境 | 開始 | Random成功率 ± seed SD | Learned成功率 ± seed SD | Oracle成功率 ± seed SD |
|---|---|---|---|---|
| Basic | IID | 0 ± 0 | 1 ± 0 | 0.52 ± 0.178885 |
| Basic | OOD | 0 ± 0 | 0.96 ± 0.0894427 | 0.68 ± 0.178885 |
| Challenge | IID | 0 ± 0 | 0.88 ± 0.178885 | 0.84 ± 0.0894427 |
| Challenge | OOD | 0 ± 0 | 0.76 ± 0.260768 | 0.76 ± 0.328634 |

seed別成功率（各セル5episode）：

| 環境 | 開始 | seed | Random成功率 | Learned成功率 | Oracle成功率 |
|---|---|---|---|---|---|
| Basic | IID | 11 | 0% | 100% | 40% |
| Basic | IID | 22 | 0% | 100% | 60% |
| Basic | IID | 33 | 0% | 100% | 80% |
| Basic | IID | 44 | 0% | 100% | 40% |
| Basic | IID | 55 | 0% | 100% | 40% |
| Basic | OOD | 11 | 0% | 100% | 80% |
| Basic | OOD | 22 | 0% | 80% | 60% |
| Basic | OOD | 33 | 0% | 100% | 80% |
| Basic | OOD | 44 | 0% | 100% | 40% |
| Basic | OOD | 55 | 0% | 100% | 80% |
| Challenge | IID | 11 | 0% | 100% | 80% |
| Challenge | IID | 22 | 0% | 80% | 100% |
| Challenge | IID | 33 | 0% | 100% | 80% |
| Challenge | IID | 44 | 0% | 100% | 80% |
| Challenge | IID | 55 | 0% | 60% | 80% |
| Challenge | OOD | 11 | 0% | 100% | 100% |
| Challenge | OOD | 22 | 0% | 80% | 20% |
| Challenge | OOD | 33 | 0% | 40% | 100% |
| Challenge | OOD | 44 | 0% | 100% | 80% |
| Challenge | OOD | 55 | 0% | 60% | 80% |

Learnedは両環境でRandomを上回った。ただしBasicのOracleはLearnedを下回り、ChallengeもIIDで84%対88%、OODで76%対76%だった。今回は「learned modelによる大きな性能損失」は観測していない。モデルの予測誤差を減らせば、このscore/有限探索下で成功率が必ず上がるという推論もできない。25episodeと5seedの小規模実験であり、数ポイント差の一般化や有意差を主張しない。paired episode差は `planning_paired_differences.csv`、全成否は `planning_episodes.csv` にある。

## 8 OOD結果

IIDは[0.05,0.35]²、OODはx∈[0.05,0.20], y∈[0.80,0.95]。結果から領域を選んでいない。OODはreset分布の外であり、全学習stateと完全にdisjointではない。seed順11/22/33/44/55のtrain state訪問件数はBasic [3, 25, 6, 18, 7]、Challenge [1, 24, 5, 23, 9]。各seedの分母8,400、全seedではそれぞれ59/42,000、62/42,000で、薄いが非ゼロの被覆がある。

| 環境 | 開始 | one-step mean位置誤差 | H20 mean位置誤差 | Learned成功率 | Oracle成功率 |
|---|---|---|---|---|---|
| Basic | IID | 0.000318535 | 0.00277204 | 100% | 52% |
| Basic | OOD | 0.00261348 | 0.043216 | 96% | 68% |
| Challenge | IID | 0.00391333 | 0.0217274 | 88% | 84% |
| Challenge | OOD | 0.00558866 | 0.058252 | 76% | 76% |

OODでmean一歩誤差とH20誤差は両環境とも大きくなった。Learned成功率はBasic100%→96%、Challenge88%→76%となった。一方Basic Oracleは52%→68%と上昇した。OOD開始点からgoalへの距離や経路の難しさも異なるため、成功率の差だけを学習モデルの汎化劣化と同一視しない。図 `ood_comparison.png` はこの違いを併記する。

## 9 failure cases

事前条件「h1≤0.015、h20≥0.10、真collision時にimagined nextが障害物内」をChallengeの全2560固定probeへ適用し、11件が該当した。全件IIDで、OODに該当例はなかった。評価から除外せず、最大h20例を教材表示に選んだ。

- seed=11、分布=IID、probe index=189（0始まり）。start=[0.297341912984848, 0.34355929493904114]。
- actions=[3, 3, 0, 3, 0, 0, 0, 3, 2, 0, 3, 2, 3, 0, 2, 0, 3, 0, 3, 2]。
- 一歩位置誤差=0.003708353、20歩=0.368967138。真collisionの時刻（1始まり）は[3, 5, 6, 7, 10, 14, 16, 18]。
- `results/selected_challenge_rollout.npz`、`results/failure_cases.json`、`figures/challenge_failure_example.png` に真値・予測・全行動・選択条件を保存。

一度障害物の下辺付近で停止すべき位置を通過してしまうと、同じ行動列でも想像軌跡が障害物の側面から上方へ進み、真値が下辺に留まる軌跡から大きく分岐した。1歩精度と長期利用可能性の違いを示す実測例である。

一歩testの最大侵入例は `challenge_one_step_failure.png`。最大誤差の表示はfailure探索条件に沿った教材選択で、都合の悪いseedを集計から外したものではない。

## 10 実行時間

主実験（収集、12モデル学習、one-step/rollout評価、全300episode、保存・集計）はwall **39.719秒**、process CPU **39.019秒**。GPU利用なし。Python起動/import、初回依存取得、初回Matplotlib font cache、図生成、テスト、Notebook再実行はこの主実験計測に含まれない。

| 処理 | wall秒合計 | process CPU秒合計 |
|---|---|---|
| train | 21.8304 | 21.3677 |
| evaluate | 0.450194 | 0.426847 |
| plan | 17.3749 | 17.1781 |

実測ホストはmacOS-15.7.3-arm64-arm-64bit、8 logical CPUs、PyTorch intra-op 1。CPU銘柄の追加取得はsandboxで拒否され、manifestのprocessor=arm、machine=arm64を記録した。CPU数分以内という規模目安は本ホストで達成した。無料Google Colabの現地実行・所要時間は未検証。

Notebookはseed11×2環境を別出力へ再収集・再学習・再評価し、図表示まで新規kernelでwall 17.753秒、コード7セル、error output 0。主結果の一部を再現する教材版であり、5 seed主評価を置き換えるものではない。

## 11 再現性と検証

Python3.11.6、PyTorch2.5.1、NumPy2.2.6、Matplotlib3.10.1、pytest8.3.5。直接依存はrequirements.txt、ホスト全依存はrequirements-lock.txt、全seed式/設定はSPEC/config、コードhashはruntime manifestにある。

pytest **39件合格**（最終実行2.307秒）。boundary clipping、障害物衝突、処理順、reset/transition RNG、one-hot shape、MLP shape、teacher forcingのない再帰、環境呼出禁止、同一candidate、score手計算、metrics、split、test-set非関与、policyのstart/noise pairing、成功0件のNAを検査した。

保存結果の独立検査で **300episode/18527実step** を同一seedと行動から再生し、state/reward/collision/終了が完全一致。候補bank/先頭action/再観測の対応とtest指標48個の再計算も一致した。`saved_results_verification.json` を参照。

Notebookのseed11再実行と主実験は **108ファイル、1294配列、24checkpoint tensor、256metric行** が完全一致した。圧縮コンテナ日時や実時間ではなく内容を比較。異なるOS/依存版のbit一致まで保証するものではない。再現照合は `verify_results.py` と `reproducibility_check.json`。

入力8資料は作業前後のhashが一致し、canonical masterは一切編集していない。主実験のcore/runner hashも保持。図は保存配列から生成し、11枚を目視した。本文転記先のSOLアンカーは原稿bookmarkから検証した。

## 12 期待と異なった結果

1. BasicのOracleが52%だった。正しい一歩遷移だけでは、この有限horizon/候補/scoreによる成功を保証しない。これはBasic sanity checkを省略する理由にせず、保存軌跡と候補選択を追加監査した。
2. ChallengeのLearnedはOracleへ大きく劣らず、IIDでは1episode上回った。観測していない「Oracleに対する大きな損失」を本文へ書かない。
3. transition random splitは常に良い数値にならなかった。BasicではMSE悪化、Challengeでは改善。データ重複の診断と誤差の方向を分けて報告する。
4. OODの予測誤差は増えたが、全policyの成功率が一様に低下したわけではない。Basic Oracleは上昇した。

## 13 実装上判明した問題と限界

Basic Oracleの保存済み50episode・2,894step・370,432候補を独立実装で再計算した。bank/hash、argmax、先頭action、score各項、選択trajectory、実next/reward/done、exact Basic torch wrapperとの比較で不一致は全て0、最大数値差も0だった。詳細と再実行コードは `BASIC_ORACLE_AUDIT.md`、`results/basic_oracle_independent_audit.json`、`diagnostics/audit_basic_oracle.py`。

境界clipは534step、変位0は480step。即時成功する先頭actionを含む候補があった106stepのうち76stepで、scoreどおり別actionを選択していた。無移動を選ぶ一方、想像上は後でgoalへ入るstepも461件あった。scoreは最終距離と実際のpath lengthを評価し、candidate rolloutをgoal到達時に吸収・打切りしない。境界で動かない行動はpath lengthを増やさず、最終状態評価と短い再計画の組合せが停滞を許す。

具体例は `Basic_seed11_IID_ep1_Oracle.npz` のstep_index=70。state=(0.9499999881,0.8948987126)からLEFTを先頭に置く候補41は即時goal到達可能だが、10歩scoreは−0.05489875。argmaxの候補90はRIGHTを選んで現在のgoalから離れ、10歩後goal距離0、score−0.00910203を評価するため採用された。これは未来の終点scoreと途中で成功終了する実タスクのずれを示す観測例である。

さらにfloat32座標上では、見た目がgoal半径0.05の位置で距離0.050000011920928955が生じる。固定判定`distance<=0.05`では成功ではない。この数値境界への感度を記録し、結果を見てepsilonを足したり成功へ数え直す操作はしなかった。これだけで全失敗の原因を説明したとは主張しない。診断は `results/oracle_basic_trace_diagnostics.json`（および保存されている追加監査ファイル）にある。

将来の別実験なら、終端を考慮したscore、早い到達への評価、数値許容誤差を事前に規定して比較できる。しかし本工程の環境・score・成功判定・測定値は変更しない。Oracleはdiagnostic referenceであって数学的上界ではない。LearnedとOracleの差は閉ループ成績差で、純粋なone-step MSE損失の推定量ではない。

実行環境上は依存未導入を固定versionの仮想環境で解消し、Jupyterのローカルsocketをsandboxが拒否した初回実行はログに保存したうえで許可された実行へ切り替えた。初回font cacheの警告後、作業フォルダのcache先を指定した。これらは実験設定やデータの変更ではない。画像encoder、確率モデル、reward/value/policy学習、online再学習、CEMは実装対象外である。

## 最終判定 Q09 Q10 Q11 Q12 AS15

### Q09 score本文とコードの不一致

**解消（実装・改訂案）**。final goal distance、obstacle proximity、path length、invalid regionの4項を採用。係数は1.0/0.05/0.02/1.0、proximity margin0.05。全項を共通関数で計算し、両MPCのtraceへ内訳を保存した。本文へはCH5_REVISION_GUIDEの変更07を反映する。canonical本文への適用は次工程。

### Q10 smoothness_cost

**解消（実装・改訂案）**。採用名は`path_length_cost`、計算はΣ||s_t−s_(t−1)||₂。行動変化や速度変化のsmoothnessは別に追加していない。

### Q11 Toy World仕様

**解消（実装・改訂案）**。state float32/[0,1]²、4行動と向き、移動0.05、goal(0.9,0.9)/半径0.05、reset Uniform[0.05,0.35]²、最大80step、成功優先、reward差分−0.01−0.10collision+1success、Basic障害物/ノイズなし、Challenge閉障害物[0.4,0.6]×[0.35,0.65]/独立Gaussian SD0.003/移動→noise→clip→終点collision、専用RNGと全seed式を固定した。厳密な境界比較の数値感度も記録済み。OOD開始は[0.05,0.20]×[0.80,0.95]。

### Q12 コード・受け入れ条件

**部分解消**。本工程の実装・CPU実測・共通Notebook・39テスト・5seed・H1/5/10/20・split/OOD・失敗保存・Oracle比較・再現照合は達成し、CPU数分目安も本ホストで達成した。残件は無料Google Colab上での現地実行と時間測定。未実測のColab結果を作らない。

旧原稿のLearned>Randomは今回の集計では観測したが、普遍的な受け入れ条件にはしない。OOD誤差増大とLearned成功率低下は観測したものの全policyで低下したわけではない。Oracleが常に上回るという条件も達成していないし、合格条件ではない。未達・期待外の結果を残すことが本工程の受け入れ原則に合致する。

### AS15 Oracle MPC

**採用**。Learnedと同じH10/N128/候補bank/score/先頭action/再観測で、展開のみ`ToyWorld.transition(noise=False)`へ置換。主実測のBasic IIDはLearned100%/Oracle52%、Challenge IID88%/84%。未来ノイズの先読みはなく、実世界の真モデル利用可能性を主張しない。

教材として、学習誤差がなくてもplanner/score/終端/数値実装がタスク達成を制約する点まで示せた。Challengeの分岐failureと並べて、「一歩予測」「長期展開」「planningして成功」の違いを読む価値がある。E02は実装・実測成果物作成済み（Colab現地確認は残件）。E06はAS15について採用・実装・実測済みで、他の候補の採否まで変更していない。
