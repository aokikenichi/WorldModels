"""Small, shared implementation of the experiment fixed in SPEC.md.

The learned transition is deliberately an uncorrected MLP prediction. Geometry
is used by the true environment and by the planning score, never to repair a
learned rollout. All computation is suitable for a CPU.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F


def load_config(path: str | Path | None = None) -> dict[str, Any]:
    """Read configuration relative to this module, independent of the cwd."""
    source = Path(path) if path is not None else Path(__file__).with_name("config.json")
    with source.open(encoding="utf-8") as handle:
        return json.load(handle)


def _action_array(actions: Any) -> np.ndarray:
    result = np.asarray(actions)
    if result.dtype.kind not in "iu" or np.any((result < 0) | (result > 3)):
        raise ValueError("actions must be integers in {0, 1, 2, 3}")
    return result.astype(np.int64, copy=False)


class ToyWorld:
    """Independent four-tuple API; not a Gymnasium environment.

    ``transition`` changes neither current state nor the episode counter. Its
    optional noise consumes this environment's random generator. ``state`` may
    be assigned after reset to set a prespecified evaluation start.
    """

    def __init__(self, variant: str = "Basic", config: dict | None = None):
        normalized = variant.capitalize()
        if normalized not in ("Basic", "Challenge"):
            raise ValueError("variant must be Basic or Challenge")
        self.variant = normalized
        self.config = copy.deepcopy(load_config() if config is None else config)
        self.world_config = self.config["world"]
        w = self.world_config
        self.goal = np.asarray(w["goal"], dtype=np.float32)
        self.goal_radius = float(w["goal_radius"])
        self.max_steps = int(w["max_steps"])
        self.step_size = float(w["step_size"])
        self.noise_std = float(w["noise_std"]) if normalized == "Challenge" else 0.0
        self.obstacle = (
            np.asarray(w["obstacle"], dtype=np.float32)
            if normalized == "Challenge" else None
        )
        self._moves = self.step_size * np.asarray(
            [[0, 1], [0, -1], [-1, 0], [1, 0]], dtype=np.float32
        )
        self.rng = np.random.default_rng()
        self._state: np.ndarray | None = None
        self.steps = 0
        self.done = False

    def _validate_states(self, states: Any) -> np.ndarray:
        array = np.asarray(states, dtype=np.float32)
        if array.ndim < 1 or array.shape[-1] != 2:
            raise ValueError("states must have last dimension 2")
        if not np.all(np.isfinite(array)) or np.any((array < 0) | (array > 1)):
            raise ValueError("true environment states must be finite and in [0, 1]^2")
        if np.any(in_obstacle(array, self)):
            raise ValueError("true environment states must be outside the closed obstacle")
        return array

    @property
    def state(self) -> np.ndarray:
        if self._state is None:
            raise RuntimeError("call reset before reading the environment state")
        return self._state.copy()

    @state.setter
    def state(self, value: Any) -> None:
        array = self._validate_states(value)
        if array.shape != (2,):
            raise ValueError("current environment state must have shape (2,)")
        self._state = array.copy()

    def reset(self, seed: int | None = None) -> np.ndarray:
        if seed is not None:
            self.rng = np.random.default_rng(seed)
        self._state = self.rng.uniform(
            self.world_config["reset_low"], self.world_config["reset_high"]
        ).astype(np.float32)
        self.steps = 0
        self.done = False
        return self.state

    def _transition_details(
        self, state: Any, action: Any, noise: bool = True
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        states = self._validate_states(state)
        actions = _action_array(action)
        try:
            actions = np.broadcast_to(actions, states.shape[:-1])
        except ValueError as error:
            raise ValueError("action shape must broadcast to state batch dimensions") from error
        proposal = states + self._moves[actions]
        if noise and self.noise_std > 0:
            proposal = proposal + self.rng.normal(
                0.0, self.noise_std, size=proposal.shape
            ).astype(np.float32)
        clipped = np.clip(proposal, 0.0, 1.0)
        boundary_clipped = np.any(proposal != clipped, axis=-1)
        collision = in_obstacle(clipped, self)
        next_states = np.where(collision[..., None], states, clipped).astype(np.float32)
        return next_states, collision, boundary_clipped

    def transition(self, state: Any, action: Any, noise: bool = True) -> np.ndarray:
        """Apply move → Gaussian noise → clipping → endpoint collision.

        Accepts a single state or arrays with shape (..., 2), and integer actions
        broadcastable to (...). ``noise=False`` does not consume RNG state.
        """
        return self._transition_details(state, action, noise)[0]

    def step(self, action: int) -> tuple[np.ndarray, float, bool, dict[str, Any]]:
        if self._state is None:
            raise RuntimeError("call reset before step")
        if self.done:
            raise RuntimeError("episode is done; call reset before step")
        action_array = _action_array(action)
        if action_array.ndim != 0:
            raise ValueError("step requires a scalar action")
        old_state = self._state.copy()
        next_state, collision, clipped = self._transition_details(old_state, action_array)
        self.steps += 1
        distance = float(np.linalg.norm(next_state - self.goal))
        terminated = distance <= self.goal_radius
        truncated = self.steps >= self.max_steps and not terminated
        self.done = bool(terminated or truncated)
        self._state = next_state.copy()
        w = self.world_config
        reward = (
            float(np.linalg.norm(old_state - self.goal)) - distance
            - float(w["step_cost"])
            - float(w["collision_penalty"]) * bool(collision)
            + float(w["success_bonus"]) * terminated
        )
        info = {
            "terminated": bool(terminated), "truncated": bool(truncated),
            "collision": bool(collision), "boundary_clipped": bool(clipped),
            "blocked": bool(collision), "distance_to_goal": distance,
        }
        return self.state, float(reward), self.done, info


def in_obstacle(states: Any, env: ToyWorld) -> np.ndarray:
    states = np.asarray(states)
    if env.obstacle is None:
        return np.zeros(states.shape[:-1], dtype=bool)
    xmin, xmax, ymin, ymax = env.obstacle
    return (
        (states[..., 0] >= xmin) & (states[..., 0] <= xmax)
        & (states[..., 1] >= ymin) & (states[..., 1] <= ymax)
    )


def obstacle_distance(states: Any, env: ToyWorld) -> np.ndarray:
    """Euclidean distance to the closed rectangle; infinity in Basic."""
    states = np.asarray(states)
    if env.obstacle is None:
        return np.full(states.shape[:-1], np.inf)
    xmin, xmax, ymin, ymax = env.obstacle
    dx = np.maximum(np.maximum(xmin - states[..., 0], states[..., 0] - xmax), 0)
    dy = np.maximum(np.maximum(ymin - states[..., 1], states[..., 1] - ymax), 0)
    return np.hypot(dx, dy)


def region_labels(states: Any, env: ToyWorld, near_threshold: float = .075) -> np.ndarray:
    states = np.asarray(states)
    labels = np.full(states.shape[:-1], "other", dtype="<U8")
    near_boundary = np.min(np.concatenate((states, 1 - states), axis=-1), axis=-1)
    labels[near_boundary <= near_threshold] = "boundary"
    labels[obstacle_distance(states, env) <= near_threshold] = "obstacle"
    return labels


def action_one_hot(actions: Any) -> torch.Tensor:
    """Integer action indices → float32 one-hot vectors of last dimension 4."""
    if isinstance(actions, torch.Tensor):
        if actions.dtype not in (torch.uint8, torch.int8, torch.int16, torch.int32, torch.int64):
            raise ValueError("actions must be integer tensors")
        if torch.any((actions < 0) | (actions > 3)):
            raise ValueError("actions must be in {0, 1, 2, 3}")
        values = actions.to(dtype=torch.long)
    else:
        values = torch.as_tensor(_action_array(actions), dtype=torch.long)
    return F.one_hot(values, num_classes=4).to(dtype=torch.float32)


class DynamicsModel(nn.Module):
    """6 → 64 → 64 → 2 delta-state MLP, with uncorrected next-state output."""

    def __init__(self):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(6, 64), nn.ReLU(), nn.Linear(64, 64), nn.ReLU(), nn.Linear(64, 2)
        )

    def forward(self, states: torch.Tensor, actions: torch.Tensor) -> torch.Tensor:
        if states.shape[-1] != 2 or actions.shape != states.shape[:-1]:
            raise ValueError("states (..., 2) and actions (...) must have matching batch dimensions")
        one_hot = action_one_hot(actions).to(device=states.device, dtype=states.dtype)
        delta = self.network(torch.cat((states, one_hot), dim=-1))
        return states + delta


def _rollout_inputs(starts: Any, actions: Any) -> tuple[np.ndarray, np.ndarray]:
    starts = np.asarray(starts, dtype=np.float32)
    actions = _action_array(actions)
    if starts.ndim != 2 or starts.shape[1] != 2:
        raise ValueError("rollout starts must have shape (N, 2)")
    if actions.ndim != 2 or actions.shape[0] != starts.shape[0]:
        raise ValueError("rollout actions must have shape (N, H)")
    if actions.shape[1] < 1 or starts.shape[0] < 1:
        raise ValueError("rollouts require at least one candidate and one action")
    return starts, actions


def learned_rollout(model: nn.Module, starts: Any, actions: Any) -> np.ndarray:
    """Recursive model-only rollout; no environment object is accepted.

    Every state after t=0 comes from the model's previous prediction. No clipping,
    obstacle correction, or intermediate observation is applied.
    """
    starts, actions = _rollout_inputs(starts, actions)
    parameter = next(model.parameters(), None)
    device = parameter.device if parameter is not None else torch.device("cpu")
    state = torch.as_tensor(starts, dtype=torch.float32, device=device)
    action_tensor = torch.as_tensor(actions, dtype=torch.long, device=device)
    trajectory = [state]
    with torch.no_grad():
        for t in range(actions.shape[1]):
            state = model(state, action_tensor[:, t])
            trajectory.append(state)
        return torch.stack(trajectory, dim=1).cpu().numpy()


def oracle_rollout(env: ToyWorld, starts: Any, actions: Any) -> np.ndarray:
    """True deterministic transition skeleton, without future-noise knowledge."""
    starts, actions = _rollout_inputs(starts, actions)
    trajectory = np.empty((len(starts), actions.shape[1] + 1, 2), dtype=np.float32)
    trajectory[:, 0] = starts
    for t in range(actions.shape[1]):
        trajectory[:, t + 1] = env.transition(trajectory[:, t], actions[:, t], noise=False)
    return trajectory


def score_terms(trajectories: Any, env: ToyWorld, planner_config: dict) -> dict[str, np.ndarray]:
    trajectories = np.asarray(trajectories, dtype=np.float64)
    if trajectories.ndim != 3 or trajectories.shape[2] != 2 or trajectories.shape[1] < 2:
        raise ValueError("trajectories must have shape (N, H+1, 2), H >= 1")
    future = trajectories[:, 1:]
    outside = np.any((future < 0) | (future > 1), axis=-1)
    obstacle_invalid = in_obstacle(future, env)
    proximity = np.maximum(0.0, 1.0 - obstacle_distance(future, env) / planner_config["proximity_margin"])
    return {
        "final_goal_distance": np.linalg.norm(trajectories[:, -1] - env.goal, axis=-1),
        "path_length_cost": np.linalg.norm(np.diff(trajectories, axis=1), axis=-1).sum(axis=1),
        "obstacle_proximity_cost": proximity.mean(axis=1),
        "invalid_region_cost": (outside.astype(float) + obstacle_invalid.astype(float)).mean(axis=1),
    }


def score(trajectories: Any, env: ToyWorld, planner_config: dict) -> np.ndarray:
    terms = score_terms(trajectories, env, planner_config)
    return (
        -planner_config["goal_weight"] * terms["final_goal_distance"]
        -planner_config["path_weight"] * terms["path_length_cost"]
        -planner_config["proximity_weight"] * terms["obstacle_proximity_cost"]
        -planner_config["invalid_weight"] * terms["invalid_region_cost"]
    )


def generate_candidates(rng: np.random.Generator, horizon: int, count: int) -> np.ndarray:
    """Unmodified independent uniform random shooting; no seeded good paths."""
    if horizon < 1 or count < 1:
        raise ValueError("horizon and count must be positive")
    return rng.integers(0, 4, size=(count, horizon), dtype=np.int64)


def choose_action(
    model_or_None: nn.Module | None, env: ToyWorld, state: Any,
    candidates: Any, planner_config: dict, oracle: bool = False,
) -> tuple[int, dict[str, Any]]:
    """Score an explicit candidate set and return only its best first action.

    External orchestration executes this action, observes the next state, and
    calls again using the next fixed candidate bank. This function never steps
    the real environment, nor generates its own candidates.
    """
    candidates = _action_array(candidates)
    if candidates.ndim != 2 or candidates.shape[0] < 1 or candidates.shape[1] < 1:
        raise ValueError("candidates must have shape (N, H) with N,H >= 1")
    state = np.asarray(state, dtype=np.float32)
    if state.shape != (2,):
        raise ValueError("planning state must have shape (2,)")
    starts = np.repeat(state[None, :], len(candidates), axis=0)
    if oracle:
        trajectories = oracle_rollout(env, starts, candidates)
    else:
        if model_or_None is None:
            raise ValueError("learned planning requires a dynamics model")
        trajectories = learned_rollout(model_or_None, starts, candidates)
    all_scores = score(trajectories, env, planner_config)
    if not np.all(np.isfinite(all_scores)):
        raise ValueError("non-finite planning score; inspect model predictions")
    best_index = int(np.argmax(all_scores))
    terms = score_terms(trajectories, env, planner_config)
    return int(candidates[best_index, 0]), {
        "best_index": best_index,
        "score": float(all_scores[best_index]),
        "score_terms": {name: float(values[best_index]) for name, values in terms.items()},
        "predicted_next": trajectories[best_index, 1].copy(),
        "best_trajectory": trajectories[best_index].copy(),
        "all_scores": all_scores.copy(),
    }


def position_metrics(pred: Any, true: Any) -> dict[str, float | int]:
    """Coordinate MSE/RMSE plus mean/median Euclidean position error."""
    pred, true = np.asarray(pred, dtype=np.float64), np.asarray(true, dtype=np.float64)
    if pred.shape != true.shape or pred.ndim < 1 or pred.shape[-1] != 2:
        raise ValueError("pred and true must have identical shapes ending in 2")
    errors = pred - true
    count = int(errors.size // 2)
    if count == 0:
        return {"mse": float("nan"), "rmse": float("nan"),
                "mean_euclidean_error": float("nan"), "median_euclidean_error": float("nan"), "count": 0}
    mse = float(np.mean(errors ** 2))
    distances = np.linalg.norm(errors, axis=-1)
    return {"mse": mse, "rmse": float(np.sqrt(mse)),
            "mean_euclidean_error": float(np.mean(distances)),
            "median_euclidean_error": float(np.median(distances)), "count": count}


compute_metrics = position_metrics
score_trajectories = score
one_hot = action_one_hot
