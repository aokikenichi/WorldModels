# Mini World Model Chapter 5 v0.2 release manifest

Release date: 2026-09-11 (Asia/Tokyo)

## Release state

This directory is a reader-ready, repository-formatted release of the Chapter 5 Mini World Model teaching materials. The source implementation archive remains separately preserved as `mini_world_model_ch5_v02_implementation.zip`; it has not been overwritten.

The release includes the reader README, shared Python modules, Notebook, CLI entry points, frozen specification and configuration, tests, diagnostics, saved 5-seed data/results/checkpoints, and principal figures. `SHA256SUMS` records every packaged file except itself.

## Tested environment

- macOS 15.7.3, arm64, CPU
- Python 3.11.6
- torch 2.5.1
- numpy 2.2.6
- matplotlib 3.10.1
- pytest 8.3.5
- nbformat 5.10.4
- nbclient 0.10.2
- ipykernel 6.29.5
- `python -m pip check`: no broken requirements

`requirements.txt` is the portable direct-dependency list for ordinary Linux and Google Colab. `requirements-lock.txt` is the complete measured macOS environment record and is not presented as a portable Linux lockfile.

## Test and reproduction results

- `pytest`: 44 passed in 2.38 seconds. The original 39 tests remain; 5 publication-path checks were added without weakening existing tests.
- Saved-result verification: 300 planning episodes and 18,527 real steps replayed; 48 one-step metrics recomputed.
- Seed-11 Notebook reproduction: 108 files, 1,294 NPZ arrays, 24 checkpoint tensors, and 256 metric rows compared exactly with the saved measured-host baseline.
- Protected baseline artifacts: 515 files under `data/`, `checkpoints/`, `figures/`, plus results CSV/NPZ files, are byte-identical to the implementation archive.
- `SPEC.md`, `SPEC_LOCK.sha256`, `config.json`, `requirements.txt`, and `requirements-lock.txt` are byte-identical to the implementation archive.

`results/runtime_manifest.json` is preserved as measurement-time provenance and therefore intentionally records the original implementation source hashes. Current publication-release hashes are recorded in this manifest and `SHA256SUMS`.

## Notebook execution

`mini_world_model.ipynb` imports the same `mini_world_model.py`, `experiment.py`, and `plots.py` modules used by the CLI; it contains no duplicate environment, model, or planner implementation.

A fresh local kernel executed all 12 code cells from the beginning through seed 11 Basic/Challenge dataset generation, training, evaluation, planning, figures, and metrics with 0 error outputs. One measured run took 15.986285 seconds wall time, including kernel startup; the Notebook's internal body timer recorded 15.326834 seconds. Package installation was not repeated because the exact dependency environment already existed, so local install time is not reported.

The generated `notebook_run/` was used for exact comparison and then excluded from the reader package as duplicate execution output. Running the distributed Notebook recreates it.

## External publication status

- Google Colab: compatibility path, dependency installation cell, CPU path, and clean local execution checked. A real free Google Colab session was not available, so Colab execution and its install/Notebook/total timings are unverified.
- GitHub: repository structure is ready, but no repository was created or pushed. Owner, repository name, visibility, URL, default branch, commit, tag/release, and Colab URL are not determined.
- License: no repository license was supplied or selected. No MIT/Apache/GPL or other license was inferred. See `LICENSE_STATUS.md` and `THIRD_PARTY_DEPENDENCIES.md`.

No placeholder repository/Colab URL is included.

## Principal SHA-256 values

| File | SHA-256 |
|---|---|
| `README.md` | `035dde5692338cb0279bb0f0579bd17d05171b3d6157dc98febd5161e6f66941` |
| `mini_world_model.ipynb` | `69f7a277f3972d33d9ae5bb6e54887fe13dccffe405805a16164eb6ef009d98f` |
| `mini_world_model.py` | `35227c497fb455c0490bc3b0ddbabe2de2bb51740711599bb2d1a39c9efa6792` |
| `experiment.py` | `74f16b636598081e158bafcf2760ffe25705151095d1682c438292bce4930063` |
| `plots.py` | `62c81755038d34b10798fcc90edf188a4967e3f1607fe8fd8a667d6ef9b07fb6` |
| `verify_results.py` | `7c39136733ff480a4c5af719d2361f36d206cbac271ebd0518580b47cac65ee2` |
| `config.json` | `3f3a367864592e167931c23f021390be45500d45207d4f785d4831716d7958ae` |
| `SPEC.md` | `dc6a3366a370081f935d030c42d2c22ccbdc95ac136118dd2eee64201964f157` |
| `SPEC_LOCK.sha256` | `15461aab3bcb82d9eac9ff015f255e8e77d1eef15765db6f237824ed1ac8644e` |
| `requirements.txt` | `a08381bb0825cd90e38356aa52843d0b5c154e164b64332966f3764396f17f4b` |
| `requirements-lock.txt` | `b5a92b0c7f5d4f4934593222d046b06089d09bf074a8f0505b99951c3c01d894` |
| `results/metrics_summary.csv` | `776bc5ec3838ece45f9092da850ba503a7f61f770a3e7ccd7204ec0d41bbea54` |
| `results/planning_pooled.csv` | `e77ea70241c816091c066e5485cf51084111f3698519a27a41fedd93e7fd7e54` |
| `results/failure_cases.json` | `57c303b70a7c3daefb7206e009e25255cb9c056118cc897e8428b0d8441e9491` |
| `figures/challenge_failure_example.png` | `b8d7030d4e224a870a9a88d6f32ead3f68b6a5bfcf196720cb979c07a245f4b2` |

The release ZIP's SHA-256 is recorded outside the ZIP in the Step 13 report and change log to avoid a circular self-hash.
