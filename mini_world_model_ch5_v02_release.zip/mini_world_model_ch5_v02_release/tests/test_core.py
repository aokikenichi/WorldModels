"""Semantic checks for the fixed ToyWorld / model / MPC contracts."""

import copy
from pathlib import Path
import sys

import numpy as np
import pytest
import torch
from torch import nn

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mini_world_model import (
    DynamicsModel, ToyWorld, action_one_hot, choose_action, generate_candidates,
    in_obstacle, learned_rollout, load_config, oracle_rollout, position_metrics,
    region_labels, score, score_terms,
)


class FixedNoise:
    def __init__(self, values):
        self.values = np.asarray(values, dtype=np.float32)

    def normal(self, loc, scale, size):
        assert loc == 0 and scale == .003
        return np.broadcast_to(self.values, size).copy()


def test_boundary_clipping_and_action_mapping():
    env = ToyWorld("Basic")
    starts = np.array([[.5, .99], [.5, .01], [.01, .5], [.99, .5]], dtype=np.float32)
    actual = env.transition(starts, np.arange(4), noise=False)
    np.testing.assert_allclose(actual, [[.5, 1], [.5, 0], [0, .5], [1, .5]], atol=1e-7)
    assert actual.dtype == np.float32


def test_closed_obstacle_endpoint_collision():
    env = ToyWorld("Challenge")
    starts = np.array([[.38, .5], [.62, .5], [.5, .32], [.5, .68]], dtype=np.float32)
    np.testing.assert_array_equal(env.transition(starts, [3, 2, 0, 1], noise=False), starts)
    assert in_obstacle(np.array([[.4, .35], [.6, .65]], dtype=np.float32), env).all()


def test_noise_precedes_clipping_and_collision():
    env = ToyWorld("Challenge")
    env.rng = FixedNoise([.02, 0])
    # The noiseless .39 endpoint is legal; adding noise first makes it collide.
    start = np.array([.34, .5], dtype=np.float32)
    np.testing.assert_array_equal(env.transition(start, 3), start)
    env.rng = FixedNoise([-.02, 0])
    # Move gives 1.02, then noise returns it to 1.0; clipping first would yield .98.
    np.testing.assert_allclose(env.transition([.97, .1], 3), [1, .1], atol=1e-7)


def test_collision_is_endpoint_based_not_segment_based():
    env = ToyWorld("Challenge")
    env.rng = FixedNoise([.2, 0])
    # A diagnostic fixed noise draw crosses the obstacle but ends outside it.
    np.testing.assert_allclose(env.transition([.39, .5], 3), [.64, .5], atol=1e-7)


@pytest.mark.parametrize("variant", ["Basic", "Challenge"])
def test_reset_reproducibility_and_return_copy(variant):
    env = ToyWorld(variant)
    first = env.reset(123)
    for _ in range(3):
        env.step(3)
    np.testing.assert_array_equal(env.reset(123), first)
    returned = env.reset(456)
    returned[:] = 0
    assert np.all(env.state >= .05) and np.all(env.state <= .35)
    other = ToyWorld(variant)
    other.reset(456)
    np.testing.assert_array_equal(env.reset(None), other.reset(None))


def test_transition_seed_reproducibility_and_no_environment_mutation():
    env = ToyWorld("Challenge")
    env.reset(321)
    old_state = env.state
    first = [env.transition([.1, .8], 0) for _ in range(4)]
    np.testing.assert_array_equal(env.state, old_state)
    assert env.steps == 0 and not env.done
    env.reset(321)
    second = [env.transition([.1, .8], 0) for _ in range(4)]
    np.testing.assert_array_equal(first, second)


def test_noise_false_and_basic_do_not_consume_rng():
    for variant in ["Basic", "Challenge"]:
        env = ToyWorld(variant)
        env.reset(321)
        before = copy.deepcopy(env.rng.bit_generator.state)
        env.transition([[.1, .8], [.2, .8]], [0, 3], noise=False)
        assert before == env.rng.bit_generator.state
        if variant == "Basic":
            env.transition([.1, .8], 0, noise=True)
            assert before == env.rng.bit_generator.state


def test_transition_batch_noise_matches_scalar_order():
    a, b = ToyWorld("Challenge"), ToyWorld("Challenge")
    a.reset(777)
    b.reset(777)
    starts = np.array([[.1, .8], [.2, .9], [.35, .5]], dtype=np.float32)
    actions = np.array([0, 3, 3])
    np.testing.assert_array_equal(
        a.transition(starts, actions),
        np.stack([b.transition(s, action) for s, action in zip(starts, actions)]),
    )


def test_reward_collision_and_blocked_are_identical():
    env = ToyWorld("Challenge")
    env.reset(123)
    env.state = [.38, .5]
    env.rng = FixedNoise([0, 0])
    state, reward, done, info = env.step(3)
    np.testing.assert_array_equal(state, np.float32([.38, .5]))
    assert reward == pytest.approx(-.11)
    assert info["collision"] and info["blocked"] and not info["boundary_clipped"]
    assert not done and not info["terminated"] and not info["truncated"]


def test_boundary_is_not_obstacle_blocked():
    env = ToyWorld("Basic")
    env.reset(1)
    env.state = [1, .1]
    _, reward, _, info = env.step(3)
    assert reward == pytest.approx(-.01)
    assert info["boundary_clipped"] and not info["blocked"]


def test_success_and_time_limit_success_precedence():
    env = ToyWorld("Basic")
    env.reset(1)
    env.state = [.85, .9]
    env.steps = 79
    _, reward, done, info = env.step(3)
    assert done and info["terminated"] and not info["truncated"]
    assert reward == pytest.approx(1.04, abs=1e-6)
    with pytest.raises(RuntimeError):
        env.step(0)
    env.reset(1)
    env.steps = 79
    _, _, done, info = env.step(1)
    assert done and info["truncated"] and not info["terminated"]


@pytest.mark.parametrize("action", [-1, 4, 1.0, True, [0, 1]])
def test_step_rejects_invalid_actions(action):
    env = ToyWorld()
    env.reset(1)
    with pytest.raises(ValueError):
        env.step(action)


@pytest.mark.parametrize("state", [[-.1, .1], [.1, 1.1], [.5, .5], [.4, .35], [np.nan, 0]])
def test_external_states_must_be_legal(state):
    env = ToyWorld("Challenge")
    with pytest.raises(ValueError):
        env.state = state


def test_action_one_hot_shape_and_values():
    result = action_one_hot(torch.tensor([[0, 1], [2, 3]]))
    assert result.shape == (2, 2, 4) and result.dtype == torch.float32
    torch.testing.assert_close(result.reshape(4, 4), torch.eye(4))
    with pytest.raises(ValueError):
        action_one_hot(torch.tensor([1.0]))


def test_model_architecture_and_residual_output():
    model = DynamicsModel()
    linears = [layer for layer in model.network if isinstance(layer, nn.Linear)]
    assert [(layer.in_features, layer.out_features) for layer in linears] == [(6, 64), (64, 64), (64, 2)]
    states, actions = torch.rand(7, 2), torch.arange(7) % 4
    assert model(states, actions).shape == (7, 2)
    for parameter in model.parameters():
        nn.init.zeros_(parameter)
    torch.testing.assert_close(model(states, actions), states)
    with pytest.raises(ValueError):
        model(states, torch.zeros(6, dtype=torch.long))


def test_learned_rollout_is_recursive_and_never_calls_environment(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("model-only rollout accessed the true environment")
    monkeypatch.setattr(ToyWorld, "step", forbidden)
    monkeypatch.setattr(ToyWorld, "transition", forbidden)
    seen = []

    class AddPointOne(nn.Module):
        def forward(self, state, action):
            seen.append(state.detach().numpy().copy())
            return state + .1

    trajectory = learned_rollout(AddPointOne(), [[.95, .95]], [[0, 1, 2]])
    assert trajectory.shape == (1, 4, 2)
    np.testing.assert_allclose(trajectory[0, :, 0], [.95, 1.05, 1.15, 1.25], atol=1e-6)
    np.testing.assert_array_equal(seen[1], trajectory[:, 1])
    np.testing.assert_array_equal(seen[2], trajectory[:, 2])
    assert np.max(trajectory) > 1  # There is deliberately no true boundary repair.


def test_oracle_rollout_uses_transition_without_noise_or_step(monkeypatch):
    env = ToyWorld("Challenge")
    env.reset(3)
    before_state = env.state
    before_rng = copy.deepcopy(env.rng.bit_generator.state)
    original = env.transition
    noise_arguments = []
    def tracked(state, action, noise=True):
        noise_arguments.append(noise)
        return original(state, action, noise=noise)
    monkeypatch.setattr(env, "transition", tracked)
    monkeypatch.setattr(env, "step", lambda *args: pytest.fail("oracle planning called step"))
    output = oracle_rollout(env, [[.38, .5]], [[3, 3, 0]])
    assert noise_arguments == [False, False, False]
    np.testing.assert_array_equal(output[0, 1], np.array([.38, .5], dtype=np.float32))
    np.testing.assert_array_equal(env.state, before_state)
    assert before_rng == env.rng.bit_generator.state and env.steps == 0


def test_same_candidates_used_by_both_planners():
    class ExactBasic(nn.Module):
        def forward(self, state, action):
            moves = .05 * torch.tensor([[0, 1], [0, -1], [-1, 0], [1, 0]], dtype=state.dtype)
            return torch.clamp(state + moves[action], 0, 1)
    env = ToyWorld("Basic")
    env.reset(5)
    candidates = np.array([[0, 3], [2, 1], [1, 2], [3, 3]], dtype=np.int64)
    original_candidates = candidates.copy()
    config = load_config()["planner"]
    learned_action, learned = choose_action(ExactBasic(), env, [.2, .3], candidates, config)
    oracle_action, oracle = choose_action(None, env, [.2, .3], candidates, config, oracle=True)
    assert learned_action == oracle_action
    assert learned["best_index"] == oracle["best_index"]
    np.testing.assert_array_equal(candidates, original_candidates)
    np.testing.assert_allclose(learned["all_scores"], oracle["all_scores"], atol=1e-7)
    np.testing.assert_allclose(learned["best_trajectory"], oracle["best_trajectory"], atol=1e-7)
    assert env.steps == 0


def test_argmax_tie_uses_first_candidate():
    class Stay(nn.Module):
        def forward(self, state, action):
            return state
    action, info = choose_action(Stay(), ToyWorld(), [.1, .1], [[2], [3]], load_config()["planner"])
    assert action == 2 and info["best_index"] == 0


def test_candidate_generation_reproducibility_and_shape():
    a = generate_candidates(np.random.default_rng(12), horizon=10, count=128)
    b = generate_candidates(np.random.default_rng(12), horizon=10, count=128)
    np.testing.assert_array_equal(a, b)
    assert a.shape == (128, 10) and set(np.unique(a)) == {0, 1, 2, 3}


def test_score_terms_match_hand_calculation_and_exclude_start():
    env = ToyWorld("Challenge")
    planner = load_config()["planner"]
    trajectory = np.array([[[.3, .5], [.4, .5], [1.1, .5]]], dtype=np.float32)
    terms = score_terms(trajectory, env, planner)
    assert terms["final_goal_distance"][0] == pytest.approx(np.sqrt(.2**2 + .4**2), abs=1e-7)
    assert terms["path_length_cost"][0] == pytest.approx(.8, abs=1e-7)
    assert terms["obstacle_proximity_cost"][0] == pytest.approx(.5)
    assert terms["invalid_region_cost"][0] == pytest.approx(1.0)
    assert score(trajectory, env, planner)[0] == pytest.approx(-np.sqrt(.2**2 + .4**2) - .02*.8 - .05*.5 - 1, abs=1e-7)
    basic_terms = score_terms(trajectory, ToyWorld("Basic"), planner)
    assert basic_terms["obstacle_proximity_cost"][0] == 0
    assert basic_terms["invalid_region_cost"][0] == .5


def test_position_metrics_coordinate_mse_differs_from_euclidean_rmse():
    metrics = position_metrics([[3, 4], [0, 0]], [[0, 0], [0, 0]])
    assert metrics == {"mse": 6.25, "rmse": 2.5, "mean_euclidean_error": 2.5,
                       "median_euclidean_error": 2.5, "count": 2}
    empty = position_metrics(np.empty((0, 2)), np.empty((0, 2)))
    assert empty["count"] == 0 and np.isnan(empty["mse"])


def test_region_labels_are_exclusive_and_geometry_specific():
    starts = np.array([[.38, .5], [.03, .5], [.2, .2]])
    assert region_labels(starts, ToyWorld("Challenge")).tolist() == ["obstacle", "boundary", "other"]
    assert region_labels(starts, ToyWorld("Basic")).tolist() == ["other", "boundary", "other"]
