"""Public-release checks that do not relax the frozen experiment tests."""
from pathlib import Path
import json

import nbformat


ROOT = Path(__file__).resolve().parents[1]
DIRECT_REQUIREMENTS = [
    "torch==2.5.1",
    "numpy==2.2.6",
    "matplotlib==3.10.1",
    "pytest==8.3.5",
    "nbformat==5.10.4",
    "nbclient==0.10.2",
    "ipykernel==6.29.5",
]


def test_release_required_files_exist():
    required = [
        "README.md", "mini_world_model.ipynb", "mini_world_model.py", "experiment.py",
        "config.json", "SPEC.md", "SPEC_LOCK.sha256", "requirements.txt", "tests",
        "diagnostics", "results", "figures", "run_experiment.py", "LICENSE_STATUS.md",
        "THIRD_PARTY_DEPENDENCIES.md", "RELEASE_MANIFEST.md", "SHA256SUMS",
    ]
    assert all((ROOT / name).exists() for name in required)


def test_direct_requirements_are_frozen():
    actual = [line.strip() for line in (ROOT / "requirements.txt").read_text().splitlines() if line.strip()]
    assert actual == DIRECT_REQUIREMENTS


def test_reader_notebook_uses_shared_modules_without_duplicate_implementations():
    notebook = nbformat.read(ROOT / "mini_world_model.ipynb", as_version=4)
    source = "\n".join(cell.source for cell in notebook.cells if cell.cell_type == "code")
    for module in ["mini_world_model", "experiment", "plots"]:
        assert f"from {module} import" in source
    for duplicated_definition in ["class ToyWorld", "class DynamicsModel", "def choose_action", "def learned_rollout"]:
        assert duplicated_definition not in source


def test_readme_has_chapter_order_and_no_placeholder_urls():
    readme = (ROOT / "README.md").read_text()
    markers = [
        "Toy Worldを見る", "Random policyでdatasetを作る", "dynamics modelを学習する",
        "one-step predictionを見る", "model-only rolloutを見る",
        "candidate action sequenceをworld model内で試す", "MPCで一手進む",
        "Random / Learned / Nominal-dynamics MPCを比較する", "OODを見る",
        "failure exampleを見る",
    ]
    positions = [readme.index(marker) for marker in markers]
    assert positions == sorted(positions)
    for placeholder in ["OWNER" + "/REPO", "USER" + "NAME", "example" + ".com"]:
        assert placeholder not in readme


def test_saved_values_required_by_the_book_are_present():
    rows = (ROOT / "results" / "planning_pooled.csv").read_text().splitlines()
    assert any("Basic,IID,Random,25,0" in row for row in rows)
    assert any("Basic,IID,Learned,25,25" in row for row in rows)
    assert any("Basic,IID,Oracle,25,13" in row for row in rows)
    assert any("Challenge,IID,Random,25,0" in row for row in rows)
    assert any("Challenge,IID,Learned,25,22" in row for row in rows)
    assert any("Challenge,IID,Oracle,25,21" in row for row in rows)
    assert any("Challenge,OOD,Learned,25,19" in row for row in rows)
    failure = json.loads((ROOT / "results" / "failure_cases.json").read_text())
    assert failure["selected"]["index"] == 189
