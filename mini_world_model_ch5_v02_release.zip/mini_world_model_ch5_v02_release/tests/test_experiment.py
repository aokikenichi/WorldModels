"""Pipeline audit with tiny synthetic fixtures; these are not experiment results.

Small local config copies keep tests fast and never edit the frozen config or
write to the measured results directory.
"""

import csv
import json
from pathlib import Path
import sys

import numpy as np
import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import experiment as exp
from mini_world_model import DynamicsModel, load_config, oracle_rollout, score, score_terms


def fixture_config():
    config = load_config()
    config["dataset"].update(trajectories=10, trajectory_steps=12, train_trajectories=6, val_trajectories=2)
    config["training"].update(epochs=3, batch_size=8)
    return config


def test_frozen_spec_lock_matches():
    exp.verify_spec_lock()


def test_trajectory_split_is_exhaustive_disjoint_and_reproducible(tmp_path):
    config = fixture_config()
    data, splits = exp.collect_dataset(config, "Challenge", 11, tmp_path / "first")
    second, second_splits = exp.collect_dataset(config, "Challenge", 11, tmp_path / "second")
    for field in data:
        np.testing.assert_array_equal(data[field], second[field])
    for kind, partitions in splits.items():
        flat = np.concatenate(list(partitions.values()))
        np.testing.assert_array_equal(np.sort(flat), np.arange(len(data["action"])))
        assert len(flat) == len(np.unique(flat))
        for name, indices in partitions.items():
            np.testing.assert_array_equal(indices, second_splits[kind][name])
    group_ids = {k: set(data["trajectory_id"][v]) for k, v in splits["trajectory"].items()}
    assert [len(group_ids[k]) for k in ["train", "val", "test"]] == [6, 2, 2]
    assert group_ids["train"].isdisjoint(group_ids["val"])
    assert group_ids["train"].isdisjoint(group_ids["test"])
    assert group_ids["val"].isdisjoint(group_ids["test"])
    mixed = splits["transition"]
    train_ids = set(data["trajectory_id"][mixed["train"]])
    test_ids = set(data["trajectory_id"][mixed["test"]])
    assert len(train_ids & test_ids) > 0
    for trajectory in range(config["dataset"]["trajectories"]):
        mask = data["trajectory_id"] == trajectory
        np.testing.assert_array_equal(data["time"][mask], np.arange(mask.sum()))
        np.testing.assert_array_equal(data["state"][mask][1:], data["next_state"][mask][:-1])
        assert data["collector_cutoff"][mask][-1]
        assert not data["terminated"][mask].any()


def test_training_uses_only_train_and_validation_and_test_cannot_change_result(tmp_path, monkeypatch):
    config = fixture_config()
    exp.configure_runtime(config)
    data, splits = exp.collect_dataset(config, "Basic", 11, tmp_path / "data")
    indices = splits["trajectory"]
    calls = []

    class AuditedModel(DynamicsModel):
        def forward(self, state, action):
            calls.append((self.training, torch.is_grad_enabled(), state.detach().numpy().copy()))
            return super().forward(state, action)

    monkeypatch.setattr(exp, "DynamicsModel", AuditedModel)
    first, first_epoch, first_val = exp.train_model(config, "Basic", 11, tmp_path / "first", data, indices)
    allowed_train = {row.tobytes() for row in data["state"][indices["train"]]}
    allowed_val = {row.tobytes() for row in data["state"][indices["val"]]}
    for training, gradients_enabled, states in calls:
        assert training == gradients_enabled
        allowed = allowed_train if training else allowed_val
        assert all(row.tobytes() in allowed for row in states)
    # Replacing every test input and target by NaN must have no effect on any
    # training operation, validation score, or selected model weights.
    corrupted = {name: value.copy() for name, value in data.items()}
    corrupted["state"][indices["test"]] = np.nan
    corrupted["next_state"][indices["test"]] = np.nan
    second, second_epoch, second_val = exp.train_model(config, "Basic", 11, tmp_path / "second", corrupted, indices)
    assert first_epoch == second_epoch and first_val == second_val
    for key, value in first.state_dict().items():
        torch.testing.assert_close(value, second.state_dict()[key], rtol=0, atol=0)
    history_path = tmp_path / "first" / "checkpoints" / "Basic" / "seed_11" / "history_trajectory.csv"
    with history_path.open() as handle:
        history = list(csv.DictReader(handle))
    minimum = min(history, key=lambda row: float(row["val_mse"]))
    assert int(minimum["epoch"]) == first_epoch
    assert float(minimum["val_mse"]) == first_val


def test_same_action_nearest_neighbor_does_not_use_wrong_action():
    data = {"state": np.array([[.5, .5], [.2, .2], [.5, .5]], dtype=np.float32),
            "action": np.array([0, 1, 1])}
    distance = exp._nearest_same_action(data, np.array([0, 1]), np.array([2]))
    assert distance[0] == pytest.approx(np.sqrt(.3**2 + .3**2), abs=1e-7)


def test_planning_pairs_start_candidate_bank_and_true_noise_stream(tmp_path, monkeypatch):
    config = fixture_config()
    config["world"]["max_steps"] = 4
    config["planner"].update(episodes_per_seed=1, horizon=3, candidates=5)
    monkeypatch.setattr(exp, "load_trained_model", lambda *args, **kwargs: None)
    observed = []

    def first_candidate(model, env, state, candidates, planner, oracle=False):
        observed.append((oracle, candidates.copy(), state.copy()))
        # A controlled same-action policy isolates pairing/noise logic. The
        # actual learned/oracle argmax equivalence is tested in test_core.py.
        trajectory = oracle_rollout(env, np.asarray(state)[None], candidates[:1])
        terms = score_terms(trajectory, env, planner)
        return int(candidates[0, 0]), {
            "predicted_next": trajectory[0, 1], "score": float(score(trajectory, env, planner)[0]),
            "best_index": 0, "best_trajectory": trajectory[0],
            "score_terms": {k: float(v[0]) for k, v in terms.items()},
        }

    monkeypatch.setattr(exp, "choose_action", first_candidate)
    exp.planning_stage(config, "Challenge", 11, tmp_path)
    episodes = json.loads((tmp_path / "results" / "episode_parts" / "Challenge_seed11.json").read_text())
    for distribution in ["IID", "OOD"]:
        group = [row for row in episodes if row["distribution"] == distribution]
        assert len({(r["start_x"], r["start_y"], r["noise_seed"], r["bank_seed"], r["bank_hash"]) for r in group}) == 1
        base = tmp_path / "results" / "planning"
        with np.load(base / f"Challenge_seed11_{distribution}_ep0_Learned.npz") as a, np.load(base / f"Challenge_seed11_{distribution}_ep0_Oracle.npz") as b:
            for key in ["states", "actions", "rewards", "collision", "boundary_clipped", "bank_hash"]:
                np.testing.assert_array_equal(a[key], b[key])
        with np.load(tmp_path / "results" / "candidate_banks" / f"Challenge_seed11_{distribution}_ep0.npz") as bank:
            assert bank["candidates"].shape == (4, 5, 3)
    # Per distribution, all four learned calls precede the four oracle calls.
    for offset in [0, 8]:
        for t in range(4):
            learned, oracle = observed[offset + t], observed[offset + 4 + t]
            assert not learned[0] and oracle[0]
            np.testing.assert_array_equal(learned[1], oracle[1])
            np.testing.assert_array_equal(learned[2], oracle[2])


def episode(success, steps, seed, policy="Learned"):
    return dict(variant="Basic", seed=seed, distribution="IID", episode=0, policy=policy,
                start_x=.1, start_y=.2, noise_seed=1, bank_seed=2, bank_hash="same",
                success=success, steps=steps, steps_to_goal=steps if success else None,
                cumulative_reward=float(success), collision_count=0, blocked_action_count=0,
                boundary_clipped_count=0, final_distance=0 if success else 1)


def test_episode_metric_denominators_and_zero_success_na():
    mixed = exp._episode_metrics([episode(True, 10, 11), episode(False, 80, 11)])
    assert mixed["success_rate"] == (.5, 2)
    assert mixed["steps_to_goal"] == (10, 1)
    failed = exp._episode_metrics([episode(False, 80, 11)])
    assert failed["steps_to_goal"] == (None, 0)


def test_aggregation_keeps_failed_seed_and_distinguishes_pooled_steps(tmp_path):
    parts = tmp_path / "results" / "metric_parts"
    parts.mkdir(parents=True)
    episode_parts = tmp_path / "results" / "episode_parts"
    episode_parts.mkdir()
    # Seed 11: one success at 10. Seed 22: two successes at 20 and 30.
    # Seed 33: zero successes. Pooled steps=20; across-successful-seed mean=17.5.
    fixtures = {
        11: [episode(True, 10, 11), episode(False, 80, 11)],
        22: [episode(True, 20, 22), episode(True, 30, 22)],
        33: [episode(False, 80, 33), episode(False, 80, 33)],
    }
    for seed, episodes in fixtures.items():
        for index, row in enumerate(episodes):
            row["episode"] = index
        rows = []
        for metric, (value, n) in exp._episode_metrics(episodes).items():
            exp._record(rows, stage="planning", variant="Basic", seed=seed,
                        distribution="IID", policy="Learned", metric=metric, value=value, n=n)
        (parts / f"seed{seed}.json").write_text(json.dumps(rows))
        (episode_parts / f"seed{seed}.json").write_text(json.dumps(episodes))
    result = exp.aggregate_results(tmp_path)
    pooled = result["planning_pooled"][0]
    assert pooled["success_rate"] == .5 and pooled["episodes"] == 6
    assert pooled["steps_to_goal"] == 20
    summary = next(r for r in result["per_seed_summary"] if r["metric"] == "steps_to_goal")
    assert summary["mean"] == 17.5
    assert summary["n_seeds"] == 2 and summary["n_seeds_total"] == 3
    assert summary["n_observations"] == 3
